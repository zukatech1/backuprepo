#include <future>
#include <objbase.h>

#include "worker.hpp"
#include "server/server.h"
#include "utils/ntdll.h"

extern std::vector<std::shared_ptr<RBXClient>> Clients;
std::mutex clientsMtx;

std::unordered_set<DWORD> closedClients;
std::unordered_set<DWORD> initializingClients;

static void newClient(DWORD pid) {
    // Check again inside the thread - the process may have died while we were starting up
    {
        std::lock_guard<std::mutex> lock(clientsMtx);
        if (closedClients.count(pid)) {
            initializingClients.erase(pid);
            return;
        }
    }

    std::shared_ptr<RBXClient> client = std::make_shared<RBXClient>(pid);

    std::lock_guard<std::mutex> lock(clientsMtx);
    initializingClients.erase(pid);

    // Don't add if the process already closed while we were attaching
    if (closedClients.count(pid)) return;
    if (!client->isProcessAlive()) {
        closedClients.insert(pid);
        return;
    }

    Clients.push_back(std::move(client));
}

static void init() {
    DWORD CurrentPID = GetCurrentProcessId();
    wchar_t path[MAX_PATH];
    GetModuleFileNameW(0, path, MAX_PATH);

    std::vector<DWORD> xenoPIDs = GetProcessIDsByName(wcsrchr(path, L'\\') + 1);
    for (const DWORD& pid : xenoPIDs) {
        if (pid == CurrentPID) continue;
        HANDLE hXeno = OpenProcess(PROCESS_TERMINATE, 0, pid);
        if (hXeno) { TerminateProcess(hXeno, 0); CloseHandle(hXeno); }
    }

    while (true) {
        std::vector<DWORD> client_pids = GetProcessIDsByName(L"RobloxPlayerBeta.exe");
        std::vector<DWORD> shader_pids = GetProcessIDsByName(L"eurotrucks2.exe");
        client_pids.insert(client_pids.end(), shader_pids.begin(), shader_pids.end());

        std::unordered_set<DWORD> current_pids(client_pids.begin(), client_pids.end());
        {
            std::lock_guard<std::mutex> lock(clientsMtx);

            // Remove clients that have exited
            Clients.erase(std::remove_if(Clients.begin(), Clients.end(),
                [&](const std::shared_ptr<RBXClient>& c) {
                    if (!current_pids.count(c->PID) || !c->isProcessAlive()) {
                        closedClients.insert(c->PID);
                        return true;
                    }
                    return false;
                }), Clients.end());

            // Prune closedClients: remove any PID that no longer exists at the OS level
            // so the set doesn't grow unboundedly across long sessions
            for (auto it = closedClients.begin(); it != closedClients.end(); ) {
                HANDLE hCheck = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, *it);
                if (!hCheck) {
                    it = closedClients.erase(it); // process truly gone, safe to forget
                } else {
                    DWORD code = 0;
                    GetExitCodeProcess(hCheck, &code);
                    CloseHandle(hCheck);
                    if (code != STILL_ACTIVE)
                        it = closedClients.erase(it);
                    else
                        ++it;
                }
            }

            // Spawn attach threads for new Roblox processes
            for (const DWORD& pid : client_pids) {
                bool known = std::any_of(Clients.begin(), Clients.end(),
                    [&](const std::shared_ptr<RBXClient>& c) { return c->PID == pid; });
                if (!known && !initializingClients.count(pid) && !closedClients.count(pid)) {
                    initializingClients.insert(pid);
                    std::thread(newClient, pid).detach();
                }
            }
        }
        Sleep(250);
    }
}

extern "C" {
    __declspec(dllexport) ClientInfo* GetClients() {
        static std::vector<ClientInfo> simpleClients;
        {
            std::lock_guard<std::mutex> lock(clientsMtx);
            simpleClients.clear();
            for (const auto& client : Clients) {
                simpleClients.push_back({
                    client->Version.c_str(),
                    client->Username.c_str(),
                    static_cast<int>(client->PID)
                });
            }
            simpleClients.push_back({ nullptr, nullptr, 0 });
        }
        return simpleClients.data();
    }

    // Returns the attach status for a given PID as a null-terminated C string:
    //   "attaching" - still in progress
    //   "ready"     - successfully attached
    //   "failed"    - attach failed
    //   "unknown"   - PID not found
    // Caller must NOT free this pointer — it points to a string literal.
    __declspec(dllexport) const char* GetAttachStatus(int pid) {
        std::lock_guard<std::mutex> lock(clientsMtx);
        for (const auto& client : Clients) {
            if (static_cast<int>(client->PID) == pid) {
                switch (client->AttachStatus.load(std::memory_order_acquire)) {
                    case RBXClient::Status::Attaching: return "attaching";
                    case RBXClient::Status::Ready:     return "ready";
                    case RBXClient::Status::Failed:    return "failed";
                }
            }
        }
        // Also check initializing clients
        if (initializingClients.count(static_cast<DWORD>(pid)))
            return "attaching";
        return "unknown";
    }

    __declspec(dllexport) void Initialize() {
        /*
        FILE* conOut;
        AllocConsole();
        SetConsoleTitleA("Xeno");
        freopen_s(&conOut, "CONOUT$", "w", stdout);
        freopen_s(&conOut, "CONOUT$", "w", stderr);
        */
        
        HMODULE ntdll = LoadLibraryA("ntdll.dll");
        if (!ntdll) {
            std::cerr << "Could not load ntdll.dll\n";
            return;
        }
        NTDLL_INIT_FCNS(ntdll);

        std::thread(init).detach();
        std::thread(setup_connection).detach();
    }

    // Execute receives a UTF-8 byte array from C# (no null terminator).
    // The P/Invoke signature passes byte[] which marshals as const char* without \0.
    // We need the length - pass it explicitly to avoid reading past the buffer.
    __declspec(dllexport) void Execute(const char* script_source, int script_len, const char** client_users, int num_users) {
        if (!script_source || script_len <= 0) return;
        std::string source(script_source, static_cast<size_t>(script_len));
        std::lock_guard<std::mutex> lock(clientsMtx);
        for (int i = 0; i < num_users; ++i) {
            for (const auto& client : Clients) {
                if (client_users[i] && strcmp(client_users[i], client->Username.c_str()) == 0) {
                    client->execute(source);
                    break;
                }
            }
        }
    }

    // Compilable also receives a byte array without null terminator.
    // Use CoTaskMemAlloc so C# can safely free with Marshal.FreeCoTaskMem.
    __declspec(dllexport) const char* Compilable(const char* script_source, int script_len) {
        if (!script_source || script_len <= 0) {
            const char* empty = "success";
            char* buf = static_cast<char*>(CoTaskMemAlloc(8));
            if (buf) strcpy_s(buf, 8, empty);
            return buf;
        }
        std::string source(script_source, static_cast<size_t>(script_len));
        std::string result = compilable(source);
        char* result_cstr = static_cast<char*>(CoTaskMemAlloc(result.length() + 1));
        if (!result_cstr) return nullptr;
        strcpy_s(result_cstr, result.length() + 1, result.c_str());
        return result_cstr;
    }
}