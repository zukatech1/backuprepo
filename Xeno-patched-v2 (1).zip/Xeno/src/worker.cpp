#include <windows.h>
#include <objbase.h>

#include <psapi.h>
#include <regex>
#include <TlHelp32.h>
#include <fstream>
#include <mutex>

#include <xxhash.h>
#include <zstd.h>

#include "worker.hpp"

#include "utils/resource.h"

std::vector<std::uintptr_t> functions::GetChildrenAddresses(std::uintptr_t address, HANDLE handle) {
    std::vector<std::uintptr_t> children;
    {
        std::uintptr_t childrenPtr = read_memory<std::uintptr_t>(address + offsets::Children, handle);
        if (childrenPtr == 0)
            return children;

        std::uintptr_t childrenStart = read_memory<std::uintptr_t>(childrenPtr, handle);
        std::uintptr_t childrenEnd = read_memory<std::uintptr_t>(childrenPtr + 0x8, handle) + 1;

        for (std::uintptr_t childAddress = childrenStart; childAddress < childrenEnd; childAddress += 0x10) {
            std::uintptr_t childPtr = read_memory<std::uintptr_t>(childAddress, handle);
            if (childPtr != 0)
                children.push_back(childPtr);
        }
    }
    return children;
}

std::string functions::ReadRobloxString(std::uintptr_t address, HANDLE handle) {
    std::uint64_t stringCount = read_memory<std::uint64_t>(address + 0x10, handle);

    if (stringCount > 15000 || stringCount <= 0)
        return "";

    if (stringCount > 15)
        address = read_memory<std::uintptr_t>(address, handle);

    std::string buffer;
    buffer.resize(stringCount);

    MEMORY_BASIC_INFORMATION bi;
    VirtualQueryEx(handle, reinterpret_cast<LPCVOID>(address), &bi, sizeof(bi));

    NtReadVirtualMemory(handle, reinterpret_cast<LPCVOID>(address), buffer.data(), (ULONG)stringCount, nullptr);

    PVOID baddr = bi.AllocationBase;
    SIZE_T size = bi.RegionSize;
    NtUnlockVirtualMemory(handle, &baddr, &size, 1);

    return buffer;
}

std::string Instance::GetBytecode() const {
    if (ClassName() != "LocalScript" && ClassName() != "ModuleScript")
        return "";

    std::uintptr_t embeddedSourceOffset = (ClassName() == "LocalScript") ? offsets::LocalScriptEmbedded : offsets::ModuleScriptEmbedded;
    std::uintptr_t embeddedPtr = read_memory<std::uintptr_t>(_Self + embeddedSourceOffset, handle);

    std::uintptr_t bytecodePtr = read_memory<std::uintptr_t>(embeddedPtr + offsets::Bytecode, handle);
    std::uint64_t bytecodeSize = read_memory<std::uint64_t>(embeddedPtr + offsets::BytecodeSize, handle);

    std::string bytecodeBuffer;
    bytecodeBuffer.resize(bytecodeSize);

    MEMORY_BASIC_INFORMATION bi;
    VirtualQueryEx(handle, reinterpret_cast<LPCVOID>(bytecodePtr), &bi, sizeof(bi));

    NtReadVirtualMemory(handle, reinterpret_cast<LPCVOID>(bytecodePtr), bytecodeBuffer.data(), (ULONG)bytecodeSize, nullptr);

    PVOID baddr = bi.AllocationBase;
    SIZE_T size = bi.RegionSize;
    NtUnlockVirtualMemory(handle, &baddr, &size, 1);

    return decompress(bytecodeBuffer);
}

static HMODULE getModule() {
    HMODULE hModule;
    GetModuleHandleEx(
        GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS,
        (LPCTSTR)getModule,
        &hModule);
    return hModule;
}

static std::filesystem::path GetHandlePath(HANDLE processHandle) {
    char buffer[MAX_PATH];
    DWORD bufferSize = sizeof(buffer);

    if (QueryFullProcessImageNameA(processHandle, 0, buffer, &bufferSize)) {
        return std::filesystem::path(buffer);
    }

    return {};
}

static std::string generateGUID() {
    GUID guid;
    HRESULT result = CoCreateGuid(&guid);

    if (result != S_OK) {
        throw std::runtime_error("Failed to generate GUID");
    }

    char guidStr[39];
    snprintf(guidStr, sizeof(guidStr), "%08lX-%04X-%04X-%04X-%012llX", guid.Data1,
        guid.Data2, guid.Data3, (guid.Data4[0] << 8) | guid.Data4[1],
        ((static_cast<unsigned long long>(guid.Data4[2]) << 40) |
         (static_cast<unsigned long long>(guid.Data4[3]) << 32) |
         (static_cast<unsigned long long>(guid.Data4[4]) << 24) |
         (static_cast<unsigned long long>(guid.Data4[5]) << 16) |
         (static_cast<unsigned long long>(guid.Data4[6]) << 8)  |
          static_cast<unsigned long long>(guid.Data4[7])));

    return std::string(guidStr);
}

static void replaceString(std::string& source, const std::string_view toReplace, const std::string_view replacement) {
    size_t pos = source.find(toReplace);

    if (pos != std::string::npos) {
        source.replace(pos, toReplace.length(), replacement);
    }
}

RBXClient::RBXClient(DWORD processID) :
    handle(OpenProcess(PROCESS_ALL_ACCESS, TRUE, processID)),
    PID(processID)
{
    if (handle == NULL) {
        std::cerr << "[!] Failed to open process " << processID << ": " << GetLastError() << "\n";
        return;
    }

    ClientDir = GetHandlePath(handle).parent_path();
    GUID = generateGUID();
    Version = ClientDir.filename().string();

    // Scope guard: marks AttachStatus = Failed if we return early for any reason.
    // Only cleared when we explicitly set Ready at the bottom.
    struct AttachGuard {
        RBXClient* self;
        bool success = false;
        ~AttachGuard() {
            if (!success) {
                self->AttachStatus.store(RBXClient::Status::Failed,
                                        std::memory_order_release);
            }
        }
    } guard{this};

    // ----------------------------------------------------------------
    // 1. Wait for the process to have a visible window AND enough memory.
    //    Using both guards is more reliable than memory size alone.
    // ----------------------------------------------------------------
    HWND clientHWND = nullptr;
    {
        auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(60);
        while (std::chrono::steady_clock::now() < deadline) {
            clientHWND = GetHWNDFromPID(GetProcessId(handle));
            PROCESS_MEMORY_COUNTERS pmc{};
            K32GetProcessMemoryInfo(handle, &pmc, sizeof(pmc));
            if (clientHWND && pmc.WorkingSetSize > 200 * 1024 * 1024)
                break;
            Sleep(150);
        }
        if (!clientHWND) {
            std::cerr << "[!] Timed out waiting for Roblox window\n";
            return;
        }
        // Give the engine a moment to finish initialising after the window appears
        Sleep(500);
    }

    // ----------------------------------------------------------------
    // 2. Find the RenderView address from the log file (non-destructive)
    // ----------------------------------------------------------------
    RenderView = GetRV(handle);
    if (RenderView == 0) {
        std::cerr << "[!] Failed to get RenderView\n";
        return;
    }

    std::uintptr_t dataModelAddress = FetchDataModel();
    if (dataModelAddress == 0) {
        std::cerr << "[!] Failed to fetch DataModel\n";
        return;
    }

    Instance DataModel(dataModelAddress, handle);

    // ----------------------------------------------------------------
    // 3. Wait for LocalPlayer to have a real username
    // ----------------------------------------------------------------
    {
        auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(60);
        while (std::chrono::steady_clock::now() < deadline) {
            std::uintptr_t playersAddr = DataModel.FindFirstChildOfClassAddress("Players");
            if (playersAddr) {
                std::uintptr_t lpAddr = read_memory<std::uintptr_t>(playersAddr + offsets::LocalPlayer, handle);
                if (lpAddr) {
                    Instance lp(lpAddr, handle);
                    std::string name = lp.Name();
                    if (!name.empty() && name != "Player") {
                        Username = name;
                        break;
                    }
                }
            }
            Sleep(50);
        }
        if (Username.empty()) Username = "Unknown";
        std::cout << "[+] Attaching to: " << Username << "\n";
    }

    // ----------------------------------------------------------------
    // 4. Locate CoreGui tree and PatchScript (the Url module in Common)
    // ----------------------------------------------------------------
    auto CoreGui = DataModel.FindFirstChild("CoreGui");
    if (!CoreGui) { std::cerr << "[!] CoreGui not found\n"; return; }

    auto RobloxGui = CoreGui->FindFirstChild("RobloxGui");
    if (!RobloxGui) { std::cerr << "[!] RobloxGui not found\n"; return; }

    auto Modules = RobloxGui->FindFirstChild("Modules");
    if (!Modules) { std::cerr << "[!] Modules not found\n"; return; }

    std::unique_ptr<Instance> PatchScript;
    {
        auto Common = Modules->FindFirstChild("Common");
        if (Common) PatchScript = Common->FindFirstChild("Url");
    }
    if (!PatchScript) { std::cerr << "[!] PatchScript (Url) not found\n"; return; }

    // ----------------------------------------------------------------
    // 5. Load and personalise the client script from embedded resource
    // ----------------------------------------------------------------
    std::string clientScript;
    {
        HMODULE module = getModule();
        if (!module) { std::cerr << "[!] getModule() failed\n"; return; }

        HRSRC resource = FindResource(module, MAKEINTRESOURCE(SCRIPT), MAKEINTRESOURCE(LUAFILE));
        if (!resource) { std::cerr << "[!] client.lua resource not found\n"; return; }

        HGLOBAL data = LoadResource(module, resource);
        if (!data) { std::cerr << "[!] LoadResource failed\n"; return; }

        DWORD size = SizeofResource(module, resource);
        char* finalData = static_cast<char*>(LockResource(data));
        clientScript.assign(finalData, size);
    }

    replaceString(clientScript, "%XENO_UNIQUE_ID%", GUID);
    replaceString(clientScript, "%XENO_VERSION%", Xeno_Version);

    const std::string PatchScriptSource =
        "--!native\n--!optimize 1\n--!nonstrict\n"
        "local a={}local b=game:GetService(\"ContentProvider\")"
        "local function c(d)local e,f=d:find(\"%.\")local g=d:sub(f+1)"
        "if g:sub(-1)~=\"/\"then g=g..\"/\"end;return g end;"
        "local d=b.BaseUrl;local g=c(d)"
        "local h=string.format(\"https://games.%s\",g)"
        "local i=string.format(\"https://apis.rcs.%s\",g)"
        "local j=string.format(\"https://apis.%s\",g)"
        "local k=string.format(\"https://accountsettings.%s\",g)"
        "local l=string.format(\"https://gameinternationalization.%s\",g)"
        "local m=string.format(\"https://locale.%s\",g)"
        "local n=string.format(\"https://users.%s\",g)"
        "local o={GAME_URL=h,RCS_URL=i,APIS_URL=j,ACCOUNT_SETTINGS_URL=k,"
        "GAME_INTERNATIONALIZATION_URL=l,LOCALE_URL=m,ROLES_URL=n}"
        "setmetatable(a,{__newindex=function(p,q,r)end,__index=function(p,r)return o[r]end})"
        "return a";

    // ----------------------------------------------------------------
    // 6. Home-page path (not in a game yet) — just patch the Url module
    // ----------------------------------------------------------------
    if (DataModel.Name() == "LuaApp" || DataModel.Name() == "App") {
        PatchScript->SetBytecode(Compile(
            "coroutine.wrap(function(...)" + clientScript + "\nend)();" + PatchScriptSource));
        std::cout << "[+] Home-page attach done for " << Username << "\n";
        AttachStatus.store(Status::Ready, std::memory_order_release);
        guard.success = true;
        return;
    }

    // ----------------------------------------------------------------
    // 7. In-game path
    // ----------------------------------------------------------------
    auto RobloxReplicatedStorage = DataModel.FindFirstChildOfClass("RobloxReplicatedStorage");

    // Already attached (e.g. server-hop) — just refresh the GUID
    if (RobloxReplicatedStorage && RobloxReplicatedStorage->FindFirstChild("Xeno")) {
        std::cout << "[+] " << Username << " already attached — refreshing\n";
        AttachStatus.store(Status::Ready, std::memory_order_release);
        guard.success = true;
        PatchScript->SetBytecode(Compile(
            "coroutine.wrap(function(...)" + clientScript + "\nend)();" + PatchScriptSource));
        return;
    }

    std::lock_guard<std::mutex> lock(clientsMtx);

    // Wait for the player to actually be in-game if they're still on the join screen
    if (!RobloxGui->FindFirstChild("DropDownFullscreenFrame")) {
        std::cout << "[*] Waiting for " << Username << " to finish loading into game...\n";
        auto addr = RobloxGui->WaitForChildAddress("DropDownFullscreenFrame", 120);
        if (addr == 0 || DataModel.Name() == "App") {
            // Left the join screen — fall back to home-page method
            PatchScript->SetBytecode(Compile(
                "coroutine.wrap(function(...)" + clientScript + "\nend)();" + PatchScriptSource));
            return;
        }
        Sleep(2000); // Let scripts finish initialising
    }

    // ----------------------------------------------------------------
    // 8. Find a suitable injection target module.
    //    Try a prioritised list so we degrade gracefully if any one is gone.
    // ----------------------------------------------------------------
    struct InjectCandidate {
        std::string path[5]; // up to 5 path segments from StarterPlayer down
        int         depth;
    };

    // Each candidate: path from StarterPlayer -> ... -> target ModuleScript
    const InjectCandidate candidates[] = {
        { {"StarterPlayerScripts", "PlayerModule", "ControlModule", "VRNavigation", ""}, 4 },
        { {"StarterPlayerScripts", "PlayerModule", "ControlModule", "Keyboard",     ""}, 4 },
        { {"StarterPlayerScripts", "PlayerModule", "ControlModule", "Gamepad",      ""}, 4 },
        { {"StarterPlayerScripts", "PlayerModule", "CameraModule",  "MouseLock",    ""}, 4 },
    };

    std::unique_ptr<Instance> InjectTarget;
    auto StarterPlayer = DataModel.FindFirstChildOfClass("StarterPlayer");
    if (!StarterPlayer) { std::cerr << "[!] StarterPlayer not found\n"; return; }

    for (const auto& cand : candidates) {
        std::unique_ptr<Instance> cur = StarterPlayer->FindFirstChild(cand.path[0]);
        for (int d = 1; d < cand.depth && cur; ++d)
            cur = cur->FindFirstChild(cand.path[d]);
        if (cur) {
            InjectTarget = std::move(cur);
            std::cout << "[+] Injection target: " << cand.path[cand.depth - 1] << "\n";
            break;
        }
    }

    if (!InjectTarget) {
        std::cerr << "[!] No suitable injection target found — falling back to PatchScript method\n";
        PatchScript->SetBytecode(Compile(
            "coroutine.wrap(function(...)" + clientScript + "\nend)();" + PatchScriptSource));
        return;
    }

    // ----------------------------------------------------------------
    // 9. Find PlayerListManager to use as the pointer-swap pivot
    // ----------------------------------------------------------------
    std::unique_ptr<Instance> PlayerListManager;
    {
        auto PlayerList = Modules->FindFirstChild("PlayerList");
        if (PlayerList) PlayerListManager = PlayerList->FindFirstChild("PlayerListManager");
    }
    if (!PlayerListManager) {
        std::cerr << "[!] PlayerListManager not found — falling back\n";
        PatchScript->SetBytecode(Compile(
            "coroutine.wrap(function(...)" + clientScript + "\nend)();" + PatchScriptSource));
        return;
    }

    // ----------------------------------------------------------------
    // 10. Inject: swap pointer, write bytecode, trigger via WM_KEYDOWN
    //     instead of keybd_event so we don't steal focus from the user.
    // ----------------------------------------------------------------
    InjectTarget->UnlockModule();
    write_memory<std::uintptr_t>(PlayerListManager->Self() + offsets::This, InjectTarget->Self(), handle);

    InjectTarget->SetBytecode(Compile(
        "script.Parent=nil;"
        "coroutine.wrap(function(...)" + clientScript + "\nend)();"
        "while task.wait(9e9) do end"),
        true); // revert after 900ms

    // Also update PatchScript for teleport/rejoin scenarios
    PatchScript->SetBytecode(Compile(
        "coroutine.wrap(function(...)" + clientScript + "\nend)();" + PatchScriptSource));

    // Send Escape via PostMessage — asynchronous, no focus steal, no user disruption.
    // PostMessage queues the message in Roblox's own message pump without activating its window.
    PostMessage(clientHWND, WM_KEYDOWN, VK_ESCAPE, 0);
    Sleep(50);
    PostMessage(clientHWND, WM_KEYUP, VK_ESCAPE, 0);

    // Wait for the revert window to close before restoring the pointer swap
    Sleep(950);
    write_memory<std::uintptr_t>(PlayerListManager->Self() + offsets::This, PlayerListManager->Self(), handle);

    // Try to recover real username if it was "Unknown" initially
    if (Username == "Unknown") {
        std::uintptr_t lpAddr = read_memory<std::uintptr_t>(
            DataModel.FindFirstChildOfClassAddress("Players") + offsets::LocalPlayer, handle);
        if (lpAddr) {
            Instance lp(lpAddr, handle);
            std::string name = lp.Name();
            if (!name.empty()) Username = name;
        }
    }

    std::cout << "[+] In-game attach complete for " << Username << "\n";
    AttachStatus.store(Status::Ready, std::memory_order_release);
    guard.success = true;
}

void RBXClient::execute(const std::string& source) const {
    std::uintptr_t dataModel_Address = FetchDataModel();
    if (!dataModel_Address) return;

    Instance DataModel(dataModel_Address, handle);
    auto RobloxReplicatedStorage = DataModel.FindFirstChildOfClass("RobloxReplicatedStorage");
    if (!RobloxReplicatedStorage) {
        std::cerr << "[!] execute: RobloxReplicatedStorage not found — is client attached?\n";
        return;
    }

    auto xenoFolder = RobloxReplicatedStorage->FindFirstChild("Xeno");
    if (!xenoFolder) {
        std::cerr << "[!] execute: Xeno folder not found — attach may have failed\n";
        return;
    }

    auto xenoModules = xenoFolder->FindFirstChild("Scripts");
    if (!xenoModules) {
        std::cerr << "[!] execute: Scripts container not found\n";
        return;
    }

    // Lua execution handler keeps modules alive 5s. Retry for up to 6s to
    // guarantee we find a live module even under scheduler jitter.
    const std::string payload = Compile(
        "return {['x e n o']=function(...)\n" + source + "\nend}");

    auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(6);
    bool written  = false;

    while (std::chrono::steady_clock::now() < deadline) {
        auto xenoModule = xenoModules->FindFirstChildOfClass("ModuleScript");
        if (xenoModule && xenoModule->SetBytecode(payload)) {
            written = true;
            break;
        }
        Sleep(20);
    }

    if (!written)
        std::cerr << "[!] execute: timed out waiting for a live execution module\n";
}

bool RBXClient::loadstring(const std::string& source, const std::string& script_name, const std::string& chunk_name) const {
    std::uintptr_t dataModel_Address = FetchDataModel();
    if (!dataModel_Address) return false;

    Instance DataModel(dataModel_Address, handle);
    auto RobloxReplicatedStorage = DataModel.FindFirstChildOfClass("RobloxReplicatedStorage");
    if (!RobloxReplicatedStorage) return false;

    auto xenoFolder = RobloxReplicatedStorage->FindFirstChild("Xeno");
    if (!xenoFolder) return false;

    auto cloned_module = xenoFolder->FindFirstChild(script_name);
    if (!cloned_module) return false;

    const std::string payload = Compile(
        "return{[ [[" + chunk_name + "]] ]=function(...)\n" + source + "\nend}");

    return cloned_module->SetBytecode(payload);
}

std::uintptr_t RBXClient::GetObjectValuePtr(const std::string_view objectval_name) const
{
    std::uintptr_t dataModel_Address = FetchDataModel();

    Instance DataModel(dataModel_Address, handle);
    auto RobloxReplicatedStorage = DataModel.FindFirstChildOfClass("RobloxReplicatedStorage");

    auto xenoFolder = RobloxReplicatedStorage->FindFirstChild("Xeno");
    if (!xenoFolder)
        return 0;

    auto objectValContainer = xenoFolder->FindFirstChild("Instance Pointers");
    if (!objectValContainer)
        return 0;

    std::uintptr_t objectValue = objectValContainer->FindFirstChildAddress(objectval_name);
    if (objectValue == 0)
        return 0;

    return read_memory<std::uintptr_t>(objectValue + offsets::ObjectValue, handle);
}

std::vector<DWORD> GetProcessIDsByName(const std::wstring_view processName) {
    std::vector<DWORD> processIDs;

    HANDLE snapShot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);
    if (snapShot == INVALID_HANDLE_VALUE)
        return processIDs;

    PROCESSENTRY32W entry = { sizeof(PROCESSENTRY32W) };

    if (Process32FirstW(snapShot, &entry)) {
        if (_wcsicmp(processName.data(), entry.szExeFile) == 0) {
            processIDs.push_back(entry.th32ProcessID);
        }
        while (Process32NextW(snapShot, &entry)) {
            if (_wcsicmp(processName.data(), entry.szExeFile) == 0) {
                processIDs.push_back(entry.th32ProcessID);
            }
        }
    }

    CloseHandle(snapShot);
    return processIDs;
}

std::uintptr_t GetRV(HANDLE handle)
{
    std::filesystem::path localAppData = std::filesystem::temp_directory_path().parent_path().parent_path();
    std::filesystem::path logs = localAppData / "Roblox" / "logs";

    if (!std::filesystem::is_directory(logs)) {
        std::cerr << "[!] Roblox logs directory not found\n";
        return 0;
    }

    int tries = 10;
    while (tries-- > 0) {
        std::vector<std::filesystem::path> logFiles;

        for (const auto& entry : std::filesystem::directory_iterator(logs)) {
            if (entry.is_regular_file() && entry.path().extension() == ".log")
                logFiles.push_back(entry.path());
        }

        if (logFiles.empty()) {
            Sleep(1000);
            continue;
        }

        // Sort newest first
        std::sort(logFiles.begin(), logFiles.end(), [](const auto& a, const auto& b) {
            return std::filesystem::last_write_time(a) > std::filesystem::last_write_time(b);
        });

        // Find which log files are locked (held open by a running Roblox process)
        // Instead of deleting, try to open with exclusive access briefly
        std::vector<std::filesystem::path> lockedFiles;
        for (const auto& logPath : logFiles) {
            // Try to open for exclusive write — will fail if another process holds it
            HANDLE hTest = CreateFileW(
                logPath.wstring().c_str(),
                GENERIC_READ,
                0, // no sharing = exclusive
                nullptr,
                OPEN_EXISTING,
                FILE_ATTRIBUTE_NORMAL,
                nullptr);

            if (hTest == INVALID_HANDLE_VALUE) {
                // File is locked by another process — likely the live Roblox log
                lockedFiles.push_back(logPath);
            } else {
                CloseHandle(hTest);
            }
        }

        if (lockedFiles.empty()) {
            // No locked files yet — Roblox might still be starting up
            Sleep(500);
            continue;
        }

        static const std::regex rgx(R"(\bSurfaceController\[_:1\]::initialize view\((.*?)\))");

        for (const auto& logPath : lockedFiles) {
            // Open with shared read access (the log is held by Roblox for writing)
            HANDLE hLog = CreateFileW(
                logPath.wstring().c_str(),
                GENERIC_READ,
                FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                nullptr,
                OPEN_EXISTING,
                FILE_ATTRIBUTE_NORMAL,
                nullptr);

            if (hLog == INVALID_HANDLE_VALUE) continue;

            // Read the log content
            LARGE_INTEGER fileSize{};
            GetFileSizeEx(hLog, &fileSize);
            if (fileSize.QuadPart == 0 || fileSize.QuadPart > 64 * 1024 * 1024) {
                CloseHandle(hLog);
                continue;
            }

            std::string content(static_cast<size_t>(fileSize.QuadPart), '\0');
            DWORD bytesRead = 0;
            ReadFile(hLog, content.data(), static_cast<DWORD>(fileSize.QuadPart), &bytesRead, nullptr);
            CloseHandle(hLog);
            content.resize(bytesRead);

            std::smatch match;
            if (!std::regex_search(content, match, rgx) || match.size() <= 1)
                continue;

            std::uintptr_t renderviewAddress = std::strtoull(match[1].str().c_str(), nullptr, 16);
            if (renderviewAddress == 0) continue;

            std::uintptr_t fakeDataModel = read_memory<std::uintptr_t>(renderviewAddress + 0x118, handle);
            if (fakeDataModel != 0)
                return renderviewAddress;
        }

        Sleep(1000);
    }

    std::cerr << "[!] GetRV: exhausted retries finding RenderView\n";
    return 0;
}

static std::string compress(const std::string_view bytecode)
{
    const auto data_size = bytecode.size();
    const auto max_size = ZSTD_compressBound(data_size);
    auto buffer = std::vector<char>(max_size + 8);

    strcpy_s(&buffer[0], buffer.capacity(), "RSB1");
    memcpy_s(&buffer[4], buffer.capacity(), &data_size, sizeof(data_size));

    const auto compressed_size = ZSTD_compress(&buffer[8], max_size, bytecode.data(), data_size, ZSTD_maxCLevel());
    if (ZSTD_isError(compressed_size))
        return "";

    const auto size = compressed_size + 8;
    const auto key = XXH32(buffer.data(), size, 42u);
    const auto bytes = reinterpret_cast<const uint8_t*>(&key);

    for (auto i = 0u; i < size; ++i)
        buffer[i] ^= bytes[i % 4] + i * 41u;

    return std::string(buffer.data(), size);
}

std::string decompress(const std::string_view compressed) {
    const uint8_t bytecodeSignature[4] = { 'R', 'S', 'B', '1' };
    const int bytecodeHashMultiplier = 41;
    const int bytecodeHashSeed = 42;

    if (compressed.size() < 8)
        return "Compressed data too short";

    std::vector<uint8_t> compressedData(compressed.begin(), compressed.end());
    std::vector<uint8_t> headerBuffer(4);

    for (size_t i = 0; i < 4; ++i) {
        headerBuffer[i] = compressedData[i] ^ bytecodeSignature[i];
        headerBuffer[i] = (headerBuffer[i] - i * bytecodeHashMultiplier) % 256;
    }

    for (size_t i = 0; i < compressedData.size(); ++i) {
        compressedData[i] ^= (headerBuffer[i % 4] + i * bytecodeHashMultiplier) % 256;
    }

    uint32_t hashValue = 0;
    for (size_t i = 0; i < 4; ++i) {
        hashValue |= headerBuffer[i] << (i * 8);
    }

    uint32_t rehash = XXH32(compressedData.data(), compressedData.size(), bytecodeHashSeed);
    if (rehash != hashValue)
        return "Hash mismatch during decompression";

    uint32_t decompressedSize = 0;
    for (size_t i = 4; i < 8; ++i) {
        decompressedSize |= compressedData[i] << ((i - 4) * 8);
    }

    compressedData = std::vector<uint8_t>(compressedData.begin() + 8, compressedData.end());
    std::vector<uint8_t> decompressed(decompressedSize);

    size_t const actualDecompressedSize = ZSTD_decompress(decompressed.data(), decompressedSize, compressedData.data(), compressedData.size());
    if (ZSTD_isError(actualDecompressedSize))
        return "ZSTD decompression error: " + std::string(ZSTD_getErrorName(actualDecompressedSize));

    decompressed.resize(actualDecompressedSize);
    return std::string(decompressed.begin(), decompressed.end());
}

std::string compilable(const std::string& source, bool returnBytecode) {
    static bytecode_encoder_t encoder = bytecode_encoder_t();
    std::string bytecode = Luau::compile(source, {}, {}, &encoder);
    if (bytecode[0] == '\0') {
        bytecode.erase(std::remove(bytecode.begin(), bytecode.end(), '\0'), bytecode.end());
        return bytecode;
    }
    if (returnBytecode) {
        return bytecode;
    }
    return "success";
}

std::string Compile(const std::string& source)
{
    static bytecode_encoder_t encoder = bytecode_encoder_t();
    const std::string bytecode = Luau::compile(source, {}, {}, &encoder);

    if (bytecode[0] == '\0') {
        std::string bytecodeP = bytecode;
        bytecodeP.erase(std::remove(bytecodeP.begin(), bytecodeP.end(), '\0'), bytecodeP.end());
        std::cerr << "Byecode compile failed: " << bytecodeP << std::endl;
    }

    return compress(bytecode);
}

static BOOL CALLBACK EnumWindowsProcMy(HWND hwnd, LPARAM lParam)
{
    DWORD lpdwProcessId;
    GetWindowThreadProcessId(hwnd, &lpdwProcessId);

    std::pair<DWORD, HWND*>* params = reinterpret_cast<std::pair<DWORD, HWND*>*>(lParam);
    DWORD targetProcessId = params->first;
    HWND* resultHWND = params->second;

    if (lpdwProcessId == targetProcessId)
    {
        *resultHWND = hwnd;
        return FALSE;
    }

    return TRUE;
}

HWND GetHWNDFromPID(DWORD process_id) {
    HWND hwnd = nullptr;
    std::pair<DWORD, HWND*> params(process_id, &hwnd);

    EnumWindows(EnumWindowsProcMy, reinterpret_cast<LPARAM>(&params));

    return hwnd;
}

template<typename T>
T read_memory(std::uintptr_t address, HANDLE handle)
{
    T value = 0;
    MEMORY_BASIC_INFORMATION bi;

    VirtualQueryEx(handle, reinterpret_cast<LPCVOID>(address), &bi, sizeof(bi));

    NtReadVirtualMemory(handle, reinterpret_cast<LPCVOID>(address), &value, sizeof(value), nullptr);

    PVOID baddr = bi.AllocationBase;
    SIZE_T size = bi.RegionSize;
    NtUnlockVirtualMemory(handle, &baddr, &size, 1);

    return value;
}

template <typename T>
bool write_memory(std::uintptr_t address, const T& value, HANDLE handle)
{
    SIZE_T bytesWritten;
    DWORD oldProtection;

    if (!VirtualProtectEx(handle, reinterpret_cast<LPVOID>(address), sizeof(value), PAGE_READWRITE, &oldProtection)) {
        return false;
    }

    if (NtWriteVirtualMemory(handle, reinterpret_cast<PVOID>(address), (PVOID)&value, sizeof(value), &bytesWritten) || bytesWritten != sizeof(value)) {
        return false;
    }

    DWORD d;
    if (!VirtualProtectEx(handle, reinterpret_cast<LPVOID>(address), sizeof(value), oldProtection, &d)) {
        return false;
    }

    return true;
}