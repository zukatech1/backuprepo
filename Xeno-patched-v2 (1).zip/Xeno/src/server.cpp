#include <regex>
#include <filesystem>
#include <fstream>
#include <unordered_map>
#include <queue>
#include <atomic>
#include <sstream>
#include <random>
#include <algorithm>
#include <chrono>

// Winsock for raw WebSocket connections
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib")

#define CPPHTTPLIB_OPENSSL_SUPPORT
#include "server/httplib.h"
using namespace httplib;

#include "server/nlohmann/json.hpp"
using json = nlohmann::json;

#include "server/server.h"
#include "utils/base64.hpp"
#include "worker.hpp"

std::vector<std::shared_ptr<RBXClient>> Clients;
std::unordered_map<std::string, json> Globals;

// ============================================================
//  WebSocket Session Manager
// ============================================================

struct WsSession {
    SOCKET              sock        = INVALID_SOCKET;
    std::atomic<bool>   open        { false };
    std::mutex          recvMtx;
    std::queue<std::string> recvQueue;  // messages received from remote
    std::mutex          sendMtx;
    std::thread         recvThread;
    std::string         id;
};

static std::mutex                                           wsSessMtx;
static std::unordered_map<std::string, std::shared_ptr<WsSession>> wsSessions;

// ---- helpers ----

static std::string wsGenerateId() {
    static std::mt19937 rng(std::random_device{}());
    static std::uniform_int_distribution<uint32_t> dist;
    char buf[33];
    snprintf(buf, sizeof(buf), "%08X%08X%08X%08X",
             dist(rng), dist(rng), dist(rng), dist(rng));
    return std::string(buf);
}

// Build the Sec-WebSocket-Accept value per RFC 6455
static std::string wsAcceptKey(const std::string& clientKey) {
    const std::string magic = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
    std::string combined = clientKey + magic;

    // SHA-1 via WinCrypt
    HCRYPTPROV hProv = 0;
    HCRYPTHASH hHash = 0;
    CryptAcquireContext(&hProv, nullptr, nullptr, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT);
    CryptCreateHash(hProv, CALG_SHA1, 0, 0, &hHash);
    CryptHashData(hHash, reinterpret_cast<const BYTE*>(combined.data()),
                  static_cast<DWORD>(combined.size()), 0);

    DWORD hashLen = 20;
    BYTE hashBuf[20];
    CryptGetHashParam(hHash, HP_HASHVAL, hashBuf, &hashLen, 0);
    CryptDestroyHash(hHash);
    CryptReleaseContext(hProv, 0);

    return base64::to_base64(std::string(reinterpret_cast<char*>(hashBuf), hashLen));
}

// Generate a random 4-byte masking key
static uint32_t wsMaskKey() {
    static std::mt19937 rng(std::random_device{}());
    return rng();
}

// Encode a WebSocket text frame (client→server, always masked per RFC 6455)
static std::string wsEncodeFrame(const std::string& payload) {
    std::string frame;
    uint8_t opcode = 0x81; // FIN + text frame
    frame += static_cast<char>(opcode);

    size_t len = payload.size();
    uint32_t maskKey = wsMaskKey();
    const uint8_t* mk = reinterpret_cast<const uint8_t*>(&maskKey);

    if (len <= 125) {
        frame += static_cast<char>(0x80 | len); // masked bit + len
    } else if (len <= 65535) {
        frame += static_cast<char>(0x80 | 126);
        frame += static_cast<char>((len >> 8) & 0xFF);
        frame += static_cast<char>(len & 0xFF);
    } else {
        frame += static_cast<char>(0x80 | 127);
        for (int i = 7; i >= 0; --i)
            frame += static_cast<char>((len >> (8 * i)) & 0xFF);
    }

    // Mask key (4 bytes)
    frame.append(reinterpret_cast<const char*>(&maskKey), 4);

    // Masked payload
    for (size_t i = 0; i < len; ++i)
        frame += static_cast<char>(payload[i] ^ mk[i % 4]);

    return frame;
}

// Decode a WebSocket frame from the server (unmasked from server side)
// Returns the payload string, or empty on error/non-text/close
static std::string wsDecodeFrame(SOCKET sock, bool& closed) {
    closed = false;

    auto recvByte = [&](uint8_t& b) -> bool {
        int r = recv(sock, reinterpret_cast<char*>(&b), 1, 0);
        return r == 1;
    };

    uint8_t b0, b1;
    if (!recvByte(b0) || !recvByte(b1)) { closed = true; return ""; }

    uint8_t opcode  = b0 & 0x0F;
    bool    masked  = (b1 & 0x80) != 0;
    uint64_t payLen = b1 & 0x7F;

    if (opcode == 0x8) { closed = true; return ""; } // close frame
    if (opcode == 0x9) {                              // ping — send pong
        std::string pong;
        pong += static_cast<char>(0x8A); pong += static_cast<char>(0x00);
        send(sock, pong.c_str(), static_cast<int>(pong.size()), 0);
        return "";
    }
    if (opcode != 0x1 && opcode != 0x2 && opcode != 0x0)
        return ""; // ignore non-data frames

    if (payLen == 126) {
        uint8_t ex[2];
        if (recv(sock, reinterpret_cast<char*>(ex), 2, MSG_WAITALL) != 2)
            { closed = true; return ""; }
        payLen = (static_cast<uint64_t>(ex[0]) << 8) | ex[1];
    } else if (payLen == 127) {
        uint8_t ex[8];
        if (recv(sock, reinterpret_cast<char*>(ex), 8, MSG_WAITALL) != 8)
            { closed = true; return ""; }
        payLen = 0;
        for (int i = 0; i < 8; ++i)
            payLen = (payLen << 8) | ex[i];
    }

    uint8_t maskBytes[4] = {};
    if (masked) {
        if (recv(sock, reinterpret_cast<char*>(maskBytes), 4, MSG_WAITALL) != 4)
            { closed = true; return ""; }
    }

    if (payLen == 0) return "";
    if (payLen > 16 * 1024 * 1024) { closed = true; return ""; } // 16 MB sanity cap

    std::string payload(static_cast<size_t>(payLen), '\0');
    size_t received = 0;
    while (received < payLen) {
        int r = recv(sock, &payload[received],
                     static_cast<int>(payLen - received), 0);
        if (r <= 0) { closed = true; return ""; }
        received += r;
    }

    if (masked) {
        for (size_t i = 0; i < payload.size(); ++i)
            payload[i] ^= maskBytes[i % 4];
    }

    return payload;
}

// Send a close frame and shutdown the socket
static void wsCloseSocket(SOCKET sock) {
    if (sock == INVALID_SOCKET) return;
    char closeFrame[2] = { static_cast<char>(0x88), 0x00 };
    send(sock, closeFrame, 2, 0);
    shutdown(sock, SD_BOTH);
    closesocket(sock);
}

// Open a WebSocket connection: parse URL, TCP connect, HTTP upgrade handshake
static std::shared_ptr<WsSession> wsOpen(const std::string& url) {
    // Parse ws:// or wss:// URL
    std::regex urlRe(R"(^(wss?):\/\/([^\/:\s]+)(?::(\d+))?(\/[^\s]*)?$)",
                     std::regex::icase);
    std::smatch m;
    if (!std::regex_match(url, m, urlRe)) return nullptr;

    bool        isTls = _stricmp(m[1].str().c_str(), "wss") == 0;
    std::string host  = m[2].str();
    int         port  = m[3].matched ? std::stoi(m[3].str()) : (isTls ? 443 : 80);
    std::string path  = m[4].matched ? m[4].str() : "/";

    // Resolve host
    addrinfo hints{};
    hints.ai_family   = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    addrinfo* addrs   = nullptr;
    if (getaddrinfo(host.c_str(), std::to_string(port).c_str(), &hints, &addrs) != 0)
        return nullptr;

    SOCKET sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (sock == INVALID_SOCKET) { freeaddrinfo(addrs); return nullptr; }

    // Set a 10s timeout on the socket
    DWORD tv = 10000;
    setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char*>(&tv), sizeof(tv));
    setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO, reinterpret_cast<const char*>(&tv), sizeof(tv));

    if (connect(sock, addrs->ai_addr, static_cast<int>(addrs->ai_addrlen)) != 0) {
        freeaddrinfo(addrs); closesocket(sock); return nullptr;
    }
    freeaddrinfo(addrs);

    // NOTE: wss:// would need an SSL wrap here (omitted; use ws:// or a plain proxy)

    // Build WebSocket upgrade request
    std::string nonce = wsGenerateId() + wsGenerateId(); // 32 hex chars, close enough
    nonce = base64::to_base64(nonce.substr(0, 16));      // 16-byte key → base64

    std::ostringstream req;
    req << "GET " << path << " HTTP/1.1\r\n"
        << "Host: " << host << ":" << port << "\r\n"
        << "Upgrade: websocket\r\n"
        << "Connection: Upgrade\r\n"
        << "Sec-WebSocket-Key: " << nonce << "\r\n"
        << "Sec-WebSocket-Version: 13\r\n"
        << "\r\n";
    std::string reqStr = req.str();
    send(sock, reqStr.c_str(), static_cast<int>(reqStr.size()), 0);

    // Read HTTP response headers (until \r\n\r\n)
    std::string respBuf;
    respBuf.reserve(512);
    while (respBuf.find("\r\n\r\n") == std::string::npos) {
        char tmp[256];
        int r = recv(sock, tmp, sizeof(tmp) - 1, 0);
        if (r <= 0) { closesocket(sock); return nullptr; }
        tmp[r] = '\0';
        respBuf += tmp;
        if (respBuf.size() > 8192) { closesocket(sock); return nullptr; }
    }

    // Must be 101 Switching Protocols
    if (respBuf.find("101") == std::string::npos) {
        closesocket(sock); return nullptr;
    }

    // Build and return session
    auto sess       = std::make_shared<WsSession>();
    sess->sock      = sock;
    sess->open      = true;
    sess->id        = wsGenerateId();

    // Start background recv thread
    sess->recvThread = std::thread([sess]() {
        while (sess->open) {
            bool closed = false;
            std::string msg = wsDecodeFrame(sess->sock, closed);
            if (closed) {
                sess->open = false;
                break;
            }
            if (!msg.empty()) {
                std::lock_guard<std::mutex> lk(sess->recvMtx);
                sess->recvQueue.push(std::move(msg));
            }
        }
    });
    sess->recvThread.detach();

    return sess;
}

// ---- "ws" command handler (called from serve()) ----

static void handleWsCommand(const json& body, Response& res) {
    if (!body.contains("t")) {
        res.status = 400;
        res.set_content(R"({"error":"Missing 't' field"})", "application/json");
        return;
    }
    const std::string type = body["t"];

    // --- open ---
    if (type == "open") {
        if (!body.contains("l")) {
            res.status = 400;
            res.set_content(R"({"error":"Missing 'l' (url) field"})", "application/json");
            return;
        }
        const std::string url = body["l"];
        auto sess = wsOpen(url);
        if (!sess) {
            res.status = 502;
            res.set_content(R"({"error":"Failed to connect to WebSocket server"})", "application/json");
            return;
        }
        {
            std::lock_guard<std::mutex> lk(wsSessMtx);
            wsSessions[sess->id] = sess;
        }
        res.status = 200;
        res.set_content(sess->id, "text/plain");
        return;
    }

    // All other sub-commands need a session id
    if (!body.contains("sid")) {
        res.status = 400;
        res.set_content(R"({"error":"Missing 'sid' field"})", "application/json");
        return;
    }
    const std::string sid = body["sid"];

    std::shared_ptr<WsSession> sess;
    {
        std::lock_guard<std::mutex> lk(wsSessMtx);
        auto it = wsSessions.find(sid);
        if (it == wsSessions.end()) {
            res.status = 404;
            res.set_content(R"({"error":"WebSocket session not found"})", "application/json");
            return;
        }
        sess = it->second;
    }

    // --- send ---
    if (type == "send") {
        if (!body.contains("ct")) {
            res.status = 400;
            res.set_content(R"({"error":"Missing 'ct' field"})", "application/json");
            return;
        }
        if (!sess->open) {
            res.status = 410;
            res.set_content(R"({"error":"WebSocket session is closed"})", "application/json");
            return;
        }
        const std::string payload = body["ct"];
        std::string frame = wsEncodeFrame(payload);
        {
            std::lock_guard<std::mutex> lk(sess->sendMtx);
            int sent = send(sess->sock, frame.c_str(), static_cast<int>(frame.size()), 0);
            if (sent <= 0) {
                sess->open = false;
                res.status = 500;
                res.set_content(R"({"error":"Failed to send WebSocket frame"})", "application/json");
                return;
            }
        }
        res.status = 200;
        return;
    }

    // --- recv (poll for next queued message) ---
    if (type == "recv") {
        std::lock_guard<std::mutex> lk(sess->recvMtx);
        if (!sess->recvQueue.empty()) {
            std::string msg = sess->recvQueue.front();
            sess->recvQueue.pop();
            res.status = 200;
            res.set_content(msg, "text/plain");
        } else {
            res.status = 200;
            res.set_content("", "text/plain"); // empty = no message yet
        }
        return;
    }

    // --- close ---
    if (type == "close") {
        sess->open = false;
        wsCloseSocket(sess->sock);
        sess->sock = INVALID_SOCKET;
        {
            std::lock_guard<std::mutex> lk(wsSessMtx);
            wsSessions.erase(sid);
        }
        res.status = 200;
        return;
    }

    res.status = 400;
    res.set_content(R"({"error":"Unknown WebSocket sub-command"})", "application/json");
}

static bool withinDirectory(const std::filesystem::path& base, const std::filesystem::path& path) {
	std::filesystem::path baseAbs = std::filesystem::absolute(base).lexically_normal();
	std::filesystem::path resolvedPath = baseAbs;

	for (const std::filesystem::path& part : path) {
		if (part == "..") {
			if (resolvedPath.has_parent_path()) {
				resolvedPath = resolvedPath.parent_path();
			}
		} else if (part != ".") {
			resolvedPath /= part;
		}
	}

	resolvedPath = resolvedPath.lexically_normal();

	return std::mismatch(baseAbs.begin(), baseAbs.end(), resolvedPath.begin()).first == baseAbs.end();
}

bool console_active = false;
std::mutex rconsoleMtx;
static void activate_console() {
	// using mutex will be a bit slower but it will fix some console issues
	std::lock_guard<std::mutex> lock(rconsoleMtx);
	if (console_active)
		return;

	console_active = true;

	AllocConsole();
	SetConsoleTitleA("Xeno");
	FILE* pCout;
	freopen_s(&pCout, "CONOUT$", "w", stdout);
	freopen_s(&pCout, "CONIN$", "r", stdin);
}

static void serve(Response& res, const json& body) {
	const std::string_view cType = body["c"];

	if (cType == "rf") { // read file
		if (!body.contains("p") /*path*/) {
			res.status = 400;
			res.set_content(R"({"error":"Missing required fields"})", "application/json");
			return;
		}

		const std::string path = body["p"];
		if (!withinDirectory(std::filesystem::current_path(), path)) {
			res.status = 400;
			res.set_content(R"({"error":"Attempt to escape directory"})", "application/json");
			return;
		}

		if (!std::filesystem::is_regular_file(path)) {
			res.status = 400;
			res.set_content(R"({"error":"Given path is not a normal file"})", "application/json");
			return;
		}

		std::ifstream file(path);
		if (!file) {
			res.status = 500;
			res.set_content(R"({"error":"Could not open the given file"})", "application/json");
			return;
		}

		std::stringstream buffer;
		buffer << file.rdbuf();

		res.status = 200;
		res.set_content(buffer.str(), "text/plain");
		return;
	}

	if (cType == "lf") { // list files
		if (!body.contains("p") /*path*/) {
			res.status = 400;
			res.set_content(R"({"error":"Missing required fields"})", "application/json");
			return;
		}

		const std::string path = body["p"];
		if (!withinDirectory(std::filesystem::current_path(), path)) {
			res.status = 400;
			res.set_content(R"({"error":"Attempt to escape directory"})", "application/json");
			return;
		}
		if (!std::filesystem::is_directory(path)) {
			res.status = 400;
			res.set_content(R"({"error":"Given path is not a directory"})", "application/json");
			return;
		}

		json responseJ;
		for (const std::filesystem::directory_entry& entry : std::filesystem::directory_iterator(path)) {
			responseJ.push_back(entry.path().string());
		}

		res.status = 200;
		res.set_content(responseJ.dump(), "application/json");
		return;
	}

	if (cType == "if") { // is folder
		if (!body.contains("p") /*path*/) {
			res.status = 400;
			res.set_content(R"({"error":"Missing required fields"})", "application/json");
			return;
		}

		const std::string path = body["p"];
		if (!withinDirectory(std::filesystem::current_path(), path)) {
			res.status = 400;
			res.set_content(R"({"error":"Attempt to escape directory"})", "application/json");
			return;
		}

		res.status = 200;
		if (std::filesystem::is_directory(path)) {
			res.set_content("dir", "text/plain");
			return;
		}
		if (std::filesystem::is_regular_file(path)) {
			res.set_content("file", "text/plain");
			return;
		}
		return;
	}

	if (cType == "mf") { // make folder
		if (!body.contains("p") /*path*/) {
			res.status = 400;
			res.set_content(R"({"error":"Missing required fields"})", "application/json");
			return;
		}

		const std::string path = body["p"];
		if (!withinDirectory(std::filesystem::current_path(), path)) {
			res.status = 400;
			res.set_content(R"({"error":"Attempt to escape directory"})", "application/json");
			return;
		}

		if (std::filesystem::is_directory(path)) {
			res.status = 400;
			res.set_content(R"({"error":"Provided directory already exists"})", "application/json");
			return;
		}

		if (std::filesystem::is_regular_file(path)) {
			res.status = 400;
			res.set_content(R"({"error":"A file with the provided directory name already exists"})", "application/json");
			return;
		}

		try {
			if (std::filesystem::create_directory(path)) {
				res.status = 201;
			} else {
				res.status = 500;
				res.set_content(R"({"error":"Could not create a new directory"})", "application/json");
			}
		}
		catch (const std::filesystem::filesystem_error& e) {
			res.status = 500;
			res.set_content("{\"error\":\"Could not create a new directory: " + std::string(e.what()) + "\"})", "application/json");
		}
		return;
	}

	if (cType == "dfl") { // delete folder
		if (!body.contains("p") /*path*/) {
			res.status = 400;
			res.set_content(R"({"error":"Missing required fields"})", "application/json");
			return;
		}

		const std::string path = body["p"];
		if (!withinDirectory(std::filesystem::current_path(), path)) {
			res.status = 400;
			res.set_content(R"({"error":"Attempt to escape directory"})", "application/json");
			return;
		}

		if (!std::filesystem::is_directory(path)) {
			res.status = 400;
			res.set_content(R"({"error":"Given path is not a directory"})", "application/json");
			return;
		}

		try {
			if (std::filesystem::remove_all(path)) {
				res.status = 200;
			} else {
				res.status = 500;
				res.set_content(R"({"error":"Could not delete directory"})", "application/json");
			}
		} catch (const std::filesystem::filesystem_error& e) {
			res.status = 500;
			res.set_content("{\"error\":\"Could not delete directory: " + std::string(e.what()) + "\"})", "application/json");
		}

		return;
	}

	if (cType == "df") { // delete file
		if (!body.contains("p") /*path*/) {
			res.status = 400;
			res.set_content(R"({"error":"Missing required fields"})", "application/json");
			return;
		}

		const std::string path = body["p"];
		if (!withinDirectory(std::filesystem::current_path(), path)) {
			res.status = 400;
			res.set_content(R"({"error":"Attempt to escape directory"})", "application/json");
			return;
		}

		if (!std::filesystem::is_regular_file(path)) {
			res.status = 400;
			res.set_content(R"({"error":"Given path is not a normal file"})", "application/json");
			return;
		}

		try {
			if (std::filesystem::remove(path)) {
				res.status = 200;
			} else {
				res.status = 500;
				res.set_content(R"({"error":"Could not delete file"})", "application/json");
			}
		}
		catch (const std::filesystem::filesystem_error& e) {
			res.status = 500;
			res.set_content("{\"error\":\"Could not delete file: " + std::string(e.what()) + "\"})", "application/json");
		}
		return;
	}

	if (cType == "cas") { // get custom asset
		if (!body.contains("p") /*path*/ || !body.contains("pid") /*process id*/) {
			res.status = 400;
			res.set_content(R"({"error":"Missing required fields"})", "application/json");
			return;
		}

		const std::string path = body["p"];
		if (!withinDirectory(std::filesystem::current_path(), path)) {
			res.status = 400;
			res.set_content(R"({"error":"Attempt to escape directory"})", "application/json");
			return;
		}

		const std::filesystem::path sourcePath = std::filesystem::current_path() / path;

		if (!std::filesystem::is_regular_file(sourcePath)) {
			res.status = 400;
			res.set_content(R"({"error":"Given path is not a normal file"})", "application/json");
			return;
		}

		const std::string pid = body["pid"];
		std::lock_guard<std::mutex> lock(clientsMtx);
		for (const auto& client : Clients) {
			if (std::to_string(client->PID) == pid) {
				std::filesystem::path contentDir = client->ClientDir / "content";

				if (!std::filesystem::is_directory(contentDir)) {
					res.status = 400;
					res.set_content(R"({"error":"directory 'content' does not exist or is not a directory"})", "application/json");
					return;
				}

				std::filesystem::path destinationPath = contentDir / sourcePath.filename();
				std::filesystem::copy_file(sourcePath, destinationPath, std::filesystem::copy_options::overwrite_existing);

				res.status = 200;
				res.set_content("rbxasset://" + destinationPath.filename().string(), "text/plain");
				return;
			}
		}

		res.status = 400;
		res.set_content(R"({"error":"Client with the given PID was not found"})", "application/json");
		return;
	}

	if (cType == "rq") { // request
		if (!body.contains("l") /*url*/ || !body.contains("m") /*method*/ || !body.contains("b") /*body*/ || !body.contains("h") /*headers*/) {
			res.status = 400;
			res.set_content(R"({"error":"Missing required fields"})", "application/json");
			return;
		}

		const std::string url = body["l"];
		const std::string method = body["m"];
		const std::string rBody = base64::from_base64(body["b"]);
		const json headersJ = body["h"];

		const std::regex urlR(R"(^(http[s]?:\/\/)?([^\/]+)(\/.*)?$)");
		std::smatch urlM;
		std::string host;
		std::string path;
		if (std::regex_match(url, urlM, urlR)) {
			host = urlM[2];
			path = urlM[3].str();
		} else {
			res.status = 400;
			res.set_content(R"({"error":"Invalid URL"})", "application/json");
			return;
		}

		Client client(host.c_str());
		client.set_follow_location(true);

		Headers headers;
		for (auto it = headersJ.begin(); it != headersJ.end(); ++it) {
			headers.insert({ it.key(), it.value() });
		}

		Result proxiedRes;
		if (method == "GET") {
			proxiedRes = client.Get(path, headers);
		} else if (method == "POST") {
			proxiedRes = client.Post(path, headers, rBody, "application/json");
		} else if (method == "PUT") {
			proxiedRes = client.Put(path, headers, rBody, "application/json");
		} else if (method == "DELETE") {
			proxiedRes = client.Delete(path, headers, rBody, "application/json");
		} else if (method == "PATCH") {
			proxiedRes = client.Patch(path, headers, rBody, "application/json");
		} else {
			res.status = 400;
			res.set_content(R"({"error":"Unsupported HTTP method"})", "application/json");
			return;
		}

		if (proxiedRes) {
			json responseJ;
			responseJ["c"] = proxiedRes->status;
			responseJ["r"] = proxiedRes->reason;
			responseJ["v"] = proxiedRes->version;

			json rHeadersJ;
			for (const auto& header : proxiedRes->headers) {
				rHeadersJ[header.first] = header.second;
			}
			responseJ["h"] = rHeadersJ;

			const auto contentType = proxiedRes->get_header_value("Content-Type");
			if (contentType.find("application/json") == std::string::npos &&
				contentType.find("text/") == std::string::npos) { // convert binary files to base 64
				responseJ["b"] = base64::to_base64(proxiedRes->body);
				responseJ["b64"] = true;
			} else {
				responseJ["b"] = proxiedRes->body;
			}

			res.status = 200;
			res.set_content(responseJ.dump(), "application/json");
		} else {
			res.status = 200;
			res.set_content("x", "text/plain");
		}
		return;
	}

	if (cType == "qtp") { // queue on teleport
		if (!body.contains("pid") /*username*/ || !body.contains("t") /*type*/) {
			res.status = 400;
			res.set_content(R"({"error":"Missing required fields"})", "application/json");
			return;
		}
		const std::string pid = body["pid"];
		const std::string type = body["t"];

		std::lock_guard<std::mutex> lock(clientsMtx);
		for (const auto& client : Clients) {
			if (std::to_string(client->PID) == pid) {
				if (type == "g") { // get
					res.status = 200;
					res.set_content(client->TeleportQueue, "text/plain");
					return;
				} else if (type == "s") { // set

					if (!body.contains("ct")) {
						res.status = 400;
						res.set_content(R"({"error":"Missing required fields"})", "application/json");
						return;
					}
					const std::string source = body["ct"];

					res.status = 200;
					client->TeleportQueue = source;
					return;
				}
				res.status = 400;
				res.set_content(R"({"error":"Invalid queue on teleport request"})", "application/json");
			}
		}

		res.status = 400;
		res.set_content(R"({"error":"Client with the given PID was not found"})", "application/json");
		return;
	}

	if (cType == "btc") { // get script bytecode
		if (!body.contains("pid") /*process id*/ || !body.contains("cn") /*container name*/) {
			res.status = 400;
			res.set_content(R"({"error":"Missing required fields"})", "application/json");
			return;
		}
		const std::string pid = body["pid"];
		const std::string containerName = body["cn"];

		std::lock_guard<std::mutex> lock(clientsMtx);
		for (const auto& client : Clients) {
			if (std::to_string(client->PID) == pid) {
				const std::string bytecode = client->GetBytecode(containerName);

				res.status = 200;
				res.set_content(bytecode, "text/plain");
				return;
			}
		}

		res.status = 400;
		res.set_content(R"({"error":"Client with the given PID was not found"})", "application/json");
		return;
	}

	if (cType == "rc") { // rconsole
		if (!body.contains("t") /*console type*/) {
			res.status = 400;
			res.set_content(R"({"error":"Missing required fields"})", "application/json");
			return;
		}
		const std::string type = body["t"];

		if (type == "cls") { // clear
			if (console_active) {
				system("cls");
			}
			return;
		}

		if (type == "crt") { // create
			activate_console();
			return;
		}

		if (type == "dst") { // destroy
			if (console_active) {
				console_active = false;
				FreeConsole();
			}
			return;
		}

		if (!body.contains("ct") /*content*/) {
			res.status = 400;
			res.set_content(R"({"error":"Missing required fields"})", "application/json");
			return;
		}

		if (type == "prt") { // print
			activate_console();
			std::string text = body["ct"];
			text = base64::from_base64(text); // use base64 so the entire text can be shown without null termination
			std::cout << text << std::endl;
		}

		if (type == "ttl") { // title
			const std::string title = body["ct"];
			SetConsoleTitleA(title.c_str());
		}

		res.status = 200;
		return;
	}

	if (cType == "ax") { // get autoexec contents
		std::string content;
		std::filesystem::path xenoDir = std::filesystem::current_path().parent_path();
		std::filesystem::path autoexecDir = xenoDir / "autoexec";
		if (!std::filesystem::exists(autoexecDir)) {
			std::filesystem::create_directory(autoexecDir);
		}
		if (!std::filesystem::is_directory(autoexecDir)) {
			std::filesystem::remove(autoexecDir);
			std::filesystem::create_directory(autoexecDir);
		}

		for (const std::filesystem::directory_entry& entry : std::filesystem::directory_iterator(autoexecDir)) {
			if (!entry.is_regular_file())
				continue;

			std::ifstream file(entry.path());
			if (file.is_open()) {
				std::string file_contents((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
				if (compilable(file_contents) == "success") {
					content += "task.spawn(function(...)" + file_contents + "\nend)\n";
				}
				file.close();
			}
		}

		res.status = 200;
		res.set_content(content, "text/plain");
		return;
	}

	if (cType == "hw") { // get hwid
		std::string hwid;
		HW_PROFILE_INFO hwProfileInfo;

		if (GetCurrentHwProfile(&hwProfileInfo)) {
			std::wstring wHWID = hwProfileInfo.szHwProfileGuid;
			hwid = std::string(wHWID.begin(), wHWID.end());
		}

		res.status = 200;
		res.set_content(hwid, "text/plain");
		return;
	}

	if (cType == "adr") { // get instance container value ptr
		if (!body.contains("cn") /*instance container name*/ || !body.contains("pid") /*process id*/) {
			res.status = 400;
			res.set_content(R"({"error":"Missing required fields"})", "application/json");
			return;
		}

		const std::string containerName = body["cn"];
		const std::string pid = body["pid"];

		std::lock_guard<std::mutex> lock(clientsMtx);
		for (const auto& client : Clients) {
			if (std::to_string(client->PID) == pid) {
				const std::uintptr_t address = client->GetObjectValuePtr(containerName);

				res.status = 200;
				res.set_content(std::to_string(address), "text/plain");
				return;
			}
		}

		res.status = 400;
		res.set_content(R"({"error":"Client with the given PID was not found"})", "application/json");
		return;
	}

	if (cType == "spf") { // spoof instance
		if (!body.contains("cn") /*instance container name*/ || !body.contains("pid") /*process id*/ || !body.contains("adr") /*new address*/) {
			res.status = 400;
			res.set_content(R"({"error":"Missing required fields"})", "application/json");
			return;
		}

		const std::string containerName = body["cn"];
		const std::string pid = body["pid"];
		const std::string newAddressStr = body["adr"];
		const std::uintptr_t newAddress = static_cast<std::uintptr_t>(std::stoull(newAddressStr));

		std::lock_guard<std::mutex> lock(clientsMtx);
		for (const auto& client : Clients) {
			if (std::to_string(client->PID) == pid) {
				client->SpoofInstance(containerName, newAddress);

				res.status = 200;
				return;
			}
		}

		res.status = 400;
		res.set_content(R"({"error":"Client with the given PID was not found"})", "application/json");
		return;
	}

	if (cType == "clt") { // is client loaded
		if (!body.contains("gd") /*guid*/) {
			res.status = 400;
			res.set_content(R"({"error":"Missing required fields"})", "application/json");
			return;
		}

		const std::string guid = body["gd"];
		const std::string username = body["n"];

		std::lock_guard<std::mutex> lock(clientsMtx);
		for (const auto& client : Clients) {
			if (client->GUID == guid || client->Username == username) {
				res.status = 200;
				res.set_content(std::to_string(client->PID), "text/plain");
				return;
			}
		}

		res.status = 400;
		return;
	}

	if (cType == "gb") { // globals
		if (!body.contains("t") /*type*/ || !body.contains("n") /*global name*/) {
			res.status = 400;
			res.set_content(R"({"error":"Missing required fields"})", "application/json");
			return;
		}

		const std::string type = body["t"];
		const std::string gName = body["n"];
		if (type == "s") { // set
			if (!body.contains("v") /*value*/ || !body.contains("vt") /*value type*/) {
				res.status = 400;
				res.set_content(R"({"error":"Missing required fields"})", "application/json");
				return;
			}

			const std::string val = body["v"];
			const std::string valType = body["vt"];

			Globals[gName] = { {"d", val}, {"t", valType} };

			res.status = 200;
			return;
		} else if (type == "g") { // get
			res.status = 200;
			if (Globals.find(gName) != Globals.end()) {
				res.set_content(Globals[gName].dump(), "application/json");
				return;
			} else {
				res.set_content(R"({"d":null,"t":null})", "application/json");
				return;
			}
		}

		res.status = 400;
		res.set_content(R"({"error":"Invalid globals request"})", "application/json");
		return;
	}

	if (cType == "um") { // unlock module
		if (!body.contains("cn") /*instance container name*/ || !body.contains("pid") /*process id*/) {
			res.status = 400;
			res.set_content(R"({"error":"Missing required fields"})", "application/json");
			return;
		}

		const std::string containerName = body["cn"];
		const std::string pid = body["pid"];

		std::lock_guard<std::mutex> lock(clientsMtx);
		for (const auto& client : Clients) {
			if (std::to_string(client->PID) == pid) {
				client->UnlockModule(containerName);

				res.status = 200;
				return;
			}
		}

		res.status = 400;
		res.set_content(R"({"error":"Client with the given PID was not found"})", "application/json");
		return;
	}

	if (cType == "prp") { // get properties
		if (!body.contains("cn") /*instance container name*/ || !body.contains("pid") /*process id*/) {
			res.status = 400;
			res.set_content(R"({"error":"Missing required fields"})", "application/json");
			return;
		}

		const std::string containerName = body["cn"];
		const std::string pid = body["pid"];

		std::lock_guard<std::mutex> lock(clientsMtx);
		for (const auto& client : Clients) {
			if (std::to_string(client->PID) == pid) {
				json Properties = client->GetProperties(containerName);

				res.status = 200;
				res.set_content(Properties.dump(), "application/json");
				return;
			}
		}

		res.status = 400;
		res.set_content(R"({"error":"Client with the given PID was not found"})", "application/json");
		return;
	}

	if (cType == "ws") { // WebSocket proxy
		handleWsCommand(body, res);
		return;
	}

	res.status = 400;
	res.set_content(R"({"error":"Invalid value for the field 'c'"})", "application/json");
};

void setup_connection()
{
	// Init Winsock for WebSocket proxy support
	WSADATA wsaData;
	WSAStartup(MAKEWORD(2, 2), &wsaData);

	Server svr;
	if (!svr.is_valid()) {
		std::cerr << "Server could not be started\n";
		return;
	}

	std::filesystem::path mainDir;
	std::filesystem::path workspaceDir;

	char mainPath[MAX_PATH];
	GetModuleFileNameA(NULL, mainPath, MAX_PATH);

	mainDir = std::filesystem::path(mainPath).parent_path();
	workspaceDir = mainDir / "workspace";
	if (!std::filesystem::exists(workspaceDir)) {
		std::filesystem::create_directory(workspaceDir);
	}
	if (!std::filesystem::is_directory(workspaceDir)) {
		std::filesystem::remove(workspaceDir);
		std::filesystem::create_directory(workspaceDir);
	}

	std::filesystem::current_path(workspaceDir);

	svr.Post("/send", [](const Request& req, Response& res) {
		json body;
		try {
			body = json::parse(req.body);
		} catch (json::parse_error&) {
			res.status = 400;
			res.set_content(R"({"error":"Invalid JSON"})", "application/json");
			return;
		}

		if (body.empty()) {
			res.status = 400;
			res.set_content(R"({"error":"Empty JSON"})", "application/json");
			return;
		}

		if (!body.contains("c")) {
			res.status = 400;
			res.set_content(R"({"error":"Missing 'c' field"})", "application/json");
		}
		serve(res, body);
	});

	svr.Post("/writefile", [](const Request& req, Response& res) {
		if (!req.has_param("p") /*path*/ || req.body.empty() /*content*/) {
			res.status = 400;
			res.set_content(R"({"error":"Missing required fields"})", "application/json");
			return;
		}
		const std::string path = req.get_param_value("p");
		const std::string_view content = req.body;

		if (!withinDirectory(std::filesystem::current_path(), path)) {
			res.status = 400;
			res.set_content(R"({"error":"Attempt to escape directory"})", "application/json");
			return;
		}

		if (std::filesystem::is_directory(path)) {
			res.status = 400;
			res.set_content(R"({"error":"Given path is a directory and not a file"})", "application/json");
			return;
		}

		std::ofstream file(path, std::ios::trunc | std::ios::binary);
		if (!file) {
			res.status = 500;
			res.set_content(R"({"error":"Could not open the given file"})", "application/json");
			return;
		}

		file.write(content.data(), content.size());
		file.close();

		res.status = 200;
		return;
	});

	svr.Post("/compilable", [](const Request& req, Response& res) {
		if (req.body.empty() /*source*/) {
			res.status = 400;
			res.set_content(R"({"error":"Missing required fields"})", "application/json");
			return;
		}
		const std::string source = req.body;
		bool returnBytecode = false;

		if (req.has_param("btc"))
			returnBytecode = true;

		res.status = 200;
		res.set_content(compilable(source, returnBytecode), "text/plain");
	});

	svr.Post("/loadstring", [](const Request& req, Response& res) {
		if (!req.has_param("n") /*script name*/ || !req.has_param("pid") /*process id*/ || !req.has_param("cn") /*chunk name*/ || req.body.empty() /*source*/) {
			res.status = 400;
			res.set_content(R"({"error":"Missing required fields"})", "application/json");
			return;
		}
		const std::string source = req.body;
		const std::string scriptName = req.get_param_value("n");
		const std::string pid = req.get_param_value("pid");
		const std::string chunkName = req.get_param_value("cn");

		std::lock_guard<std::mutex> lock(clientsMtx);
		for (const auto& client : Clients) {
			if (std::to_string(client->PID) == pid) {
				bool success = client->loadstring(source, scriptName, chunkName);
				if (!success) {
					res.status = 400;
					res.set_content(R"({"error":"An error occurred with loadstring"})", "application/json");
				}

				res.status = 200;
				return;
			}
		}

		res.status = 400;
		res.set_content(R"({"error":"Client with the given PID was not found"})", "application/json");
		return;
	});

	svr.Post("/setclipboard", [](const Request& req, Response& res) {
		if (req.body.empty() /*content*/) {
			res.status = 400;
			res.set_content(R"({"error":"Missing required fields"})", "application/json");
			return;
		}
		const std::string content = req.body;

		if (!OpenClipboard(nullptr)) {
			res.status = 400;
			res.set_content(R"({"error":"Failed to open clipboard"})", "application/json");
			return;
		}

		EmptyClipboard();
		HGLOBAL hMem = GlobalAlloc(GMEM_MOVEABLE, content.size() + 1);

		if (!hMem) {
			res.status = 400;
			res.set_content(R"({"error":"Failed to set clipboard | 1"})", "application/json");
			return;
		}

		char* pMem = static_cast<char*>(GlobalLock(hMem));
		if (!pMem) {
			GlobalFree(hMem);
			CloseClipboard();

			res.status = 400;
			res.set_content(R"({"error":"Failed to set clipboard | 2"})", "application/json");
			return;
		}

		std::copy(content.begin(), content.end(), pMem);
		pMem[content.size()] = '\0';
		GlobalUnlock(hMem);
		SetClipboardData(CF_TEXT, hMem);
		CloseClipboard();

		res.status = 200;
		return;
	});

	svr.set_exception_handler([](const Request& req, Response& res, std::exception_ptr ep) {
		std::string errorMessage;
		try {
			std::rethrow_exception(ep);
		} catch (std::exception& e) {
			errorMessage = e.what();
		} catch (...) {
			errorMessage = "Unknown Exception";
		}
		res.set_content("{\"error\":\"" + errorMessage + "\"}", "application/json");
		res.status = 500;
	});

	svr.listen("localhost", 19283);
	WSACleanup();
}