#pragma once

#include <Windows.h>
#include <vector>
#include <string>
#include <thread>
#include <mutex>
#include <atomic>
#include <chrono>
#include <unordered_set>

#include <iostream>
#include <filesystem>

#include "Luau/Compiler.h"
#include "Luau/BytecodeBuilder.h"
#include "Luau/BytecodeUtils.h"

#include "utils/ntdll.h"

namespace offsets {
    // Instance
    constexpr std::uint64_t This = 0x8;
    constexpr std::uint64_t Name = 0x50; // 0x48
    constexpr std::uint64_t Children = 0x58; // 0x50
    constexpr std::uint64_t Parent = 0x28; // 0x60

    constexpr std::uint64_t ClassDescriptor = 0x18;
    constexpr std::uint64_t ClassName = 0x8;

    // Scripts
    constexpr std::uint64_t ModuleScriptEmbedded = 0x160;
    constexpr std::uint64_t IsCoreScript = 0x1a8;
    constexpr std::uint64_t ModuleFlags = IsCoreScript - 0x4;
    constexpr std::uint64_t LocalScriptEmbedded = 0x1c0;

    constexpr std::uint64_t Bytecode = 0x10;
    constexpr std::uint64_t BytecodeSize = 0x20;

    // Other
    constexpr std::uint64_t LocalPlayer = 0x110; // 0x100
    constexpr std::uint64_t ObjectValue = 0xc0;
}

const std::string_view Xeno_Version = "1.0.8";

template<typename T>
T read_memory(std::uintptr_t address, HANDLE handle);

template <typename T>
bool write_memory(std::uintptr_t address, const T& value, HANDLE handle);

extern std::mutex clientsMtx;

namespace functions { // functions for rbx
    std::vector<std::uintptr_t> GetChildrenAddresses(std::uintptr_t address, HANDLE handle);
    std::string ReadRobloxString(std::uintptr_t address, HANDLE handle);
}

/*
struct ClassDescriptor {
    const std::uintptr_t Self;
    const std::string Name; // ClassName
    const std::uint64_t Capabilities;

    ClassDescriptor(std::uintptr_t& address, HANDLE& handle) :
        Self(read_memory<std::uintptr_t>(address + offsets::ClassDescriptor, handle)),
        Name(functions::ReadRobloxString(read_memory<std::uintptr_t>(Self + offsets::ClassName, handle), handle)),
        Capabilities(read_memory<std::uint64_t>(Self + 0x370, handle))
    {}
};
*/

class Instance {
private:
    const std::uintptr_t _Self;
    HANDLE handle;
public:
    Instance(std::uintptr_t address, HANDLE handle) :
        handle(handle),
        _Self(address)
    {}

    // Instance functions
    std::vector<std::uintptr_t> GetChildrenAddresses() const {
        return functions::GetChildrenAddresses(_Self, handle);
    }

    std::vector<std::unique_ptr<Instance>> GetChildren() const {
        std::vector<std::uintptr_t> childAddresses = GetChildrenAddresses();
        std::vector<std::unique_ptr<Instance>> children;
        for (std::uintptr_t address : childAddresses) {
            children.push_back(std::make_unique<Instance>(address, handle));
        }
        return children;
    }

    std::uintptr_t FindFirstChildAddress(const std::string_view name) const {
        std::vector<std::uintptr_t> childAddresses = GetChildrenAddresses();
        for (std::uintptr_t address : childAddresses) {
            if (functions::ReadRobloxString(read_memory<std::uintptr_t>(address + offsets::Name, handle), handle) == name)
                return address;
        }
        return 0;
    }

    std::unique_ptr<Instance> FindFirstChild(const std::string_view name) const {
        std::uintptr_t childAddress = FindFirstChildAddress(name);
        if (childAddress != 0)
            return std::make_unique<Instance>(childAddress, handle);
        return nullptr;
    }

    std::uintptr_t WaitForChildAddress(const std::string_view name, int timeoutSeconds = 120) const {
        std::uintptr_t existing = FindFirstChildAddress(name);
        if (existing != 0) return existing;

        auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(timeoutSeconds);
        while (std::chrono::steady_clock::now() < deadline) {
            Sleep(100);
            std::uintptr_t found = FindFirstChildAddress(name);
            if (found != 0) return found;
        }
        return 0;
    }

    std::unique_ptr<Instance> WaitForChild(const std::string_view name, int timeoutSeconds = 120) const {
        std::uintptr_t childAddress = WaitForChildAddress(name, timeoutSeconds);
        if (childAddress != 0)
            return std::make_unique<Instance>(childAddress, handle);
        return nullptr;
    }

    std::uintptr_t FindFirstChildOfClassAddress(const std::string_view className) const {
        std::vector<std::uintptr_t> childAddresses = GetChildrenAddresses();
        for (std::uintptr_t address : childAddresses) {
            if (functions::ReadRobloxString(read_memory<std::uintptr_t>(read_memory<std::uintptr_t>(address + offsets::ClassDescriptor, handle) + offsets::ClassName, handle), handle) == className)
                return address;
        }
        return 0;
    }

    std::unique_ptr<Instance> FindFirstChildOfClass(const std::string_view className) const {
        std::uintptr_t childAddress = FindFirstChildOfClassAddress(className);
        if (childAddress != 0)
            return std::make_unique<Instance>(childAddress, handle);
        return nullptr;
    }

    // Miscellaneous
    bool SetBytecode(const std::string& compressedBytecode, bool revertBytecode = false) const {
        const std::string cls = ClassName();
        if (cls != "LocalScript" && cls != "ModuleScript")
            return false;

        // Unlock BEFORE writing so any concurrent require() sees it as a core script immediately
        if (cls == "ModuleScript") {
            write_memory<std::uintptr_t>(_Self + offsets::ModuleFlags, 0x100000000, handle);
            write_memory<std::uintptr_t>(_Self + offsets::IsCoreScript, 0x1, handle);
        }

        std::uintptr_t embeddedSourceOffset = (cls == "LocalScript") ? offsets::LocalScriptEmbedded : offsets::ModuleScriptEmbedded;
        std::uintptr_t embeddedPtr = read_memory<std::uintptr_t>(_Self + embeddedSourceOffset, handle);

        // Read the current bytecode pointer so we can free it after replacing,
        // preventing an unbounded leak in the target process address space.
        std::uintptr_t oldBytecodePtr  = read_memory<std::uintptr_t>(embeddedPtr + offsets::Bytecode, handle);
        std::uint64_t  oldBytecodeSize = read_memory<std::uint64_t>(embeddedPtr + offsets::BytecodeSize, handle);

        const SIZE_T bytecodeLen = compressedBytecode.size();
        LPVOID allocatedAddress = VirtualAllocEx(handle, nullptr, bytecodeLen,
                                                  MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
        if (!allocatedAddress)
            return false;

        SIZE_T bytesWritten = 0;
        NTSTATUS writeStatus = NtWriteVirtualMemory(
            handle, allocatedAddress,
            (PVOID)compressedBytecode.c_str(),
            (ULONG)bytecodeLen,
            &bytesWritten);

        if (writeStatus != 0 || bytesWritten != bytecodeLen) {
            VirtualFreeEx(handle, allocatedAddress, 0, MEM_RELEASE);
            return false;
        }

        // Make the region read-only so Roblox's integrity checks don't trip
        DWORD oldProt;
        VirtualProtectEx(handle, allocatedAddress, bytecodeLen, PAGE_READONLY, &oldProt);

        bool ok = write_memory<std::uintptr_t>(embeddedPtr + offsets::Bytecode,
                                                reinterpret_cast<std::uintptr_t>(allocatedAddress), handle)
               && write_memory<std::uint64_t>(embeddedPtr + offsets::BytecodeSize, bytecodeLen, handle);

        if (!ok) {
            VirtualFreeEx(handle, allocatedAddress, 0, MEM_RELEASE);
            return false;
        }

        // Free the previous allocation now that we've successfully swapped the pointer.
        // Only free if it looks like a heap address (non-zero, not the original Roblox allocation
        // which lives in a different region we didn't allocate). We identify ours by checking
        // whether VirtualQueryEx reports MEM_PRIVATE — Roblox's own bytecode is MEM_MAPPED.
        if (oldBytecodePtr != 0 && oldBytecodeSize > 0) {
            MEMORY_BASIC_INFORMATION mbi{};
            if (VirtualQueryEx(handle, reinterpret_cast<LPCVOID>(oldBytecodePtr), &mbi, sizeof(mbi))) {
                if (mbi.Type == MEM_PRIVATE) {
                    // This was one of our VirtualAllocEx allocations — safe to free
                    VirtualFreeEx(handle, reinterpret_cast<LPVOID>(oldBytecodePtr), 0, MEM_RELEASE);
                }
            }
        }

        // For the injection trigger: restore the ORIGINAL Roblox bytecode pointer after a delay
        // so the module goes back to its normal state after firing.
        if (revertBytecode) {
            // We need the real original, not the one we just freed above.
            // oldBytecodePtr here IS the original (we read it before writing).
            // But we just potentially freed it if it was MEM_PRIVATE — that would be wrong
            // for the revert case (VRNavigation's real bytecode is MEM_MAPPED, so it won't
            // have been freed above). Store it explicitly.
            std::uintptr_t revertTo   = oldBytecodePtr;
            std::uint64_t  revertSize = oldBytecodeSize;
            std::thread([embeddedPtr, revertTo, revertSize, newAlloc = allocatedAddress, h = this->handle]() {
                Sleep(900);
                write_memory<std::uintptr_t>(embeddedPtr + offsets::Bytecode, revertTo, h);
                write_memory<std::uint64_t>(embeddedPtr + offsets::BytecodeSize, revertSize, h);
                // Now free the allocation we injected, since we've restored the original
                VirtualFreeEx(h, newAlloc, 0, MEM_RELEASE);
            }).detach();
        }

        return true;
    }

    std::string GetBytecode() const;

    void UnlockModule() const {
        if (ClassName() == "ModuleScript") {
            write_memory<std::uintptr_t>(_Self + offsets::ModuleFlags, 0x100000000, handle);
            write_memory<std::uintptr_t>(_Self + offsets::IsCoreScript, 0x1, handle);
        }
    }

    std::vector<std::string> GetProperties() const {
        std::vector<std::string> Properties;
        {
            std::uintptr_t ClassDescriptor = read_memory<std::uintptr_t>(_Self + offsets::ClassDescriptor, handle);

            std::uintptr_t PropertiesStart = read_memory<std::uintptr_t>(ClassDescriptor + 0x28, handle);
            std::uintptr_t PropertiesEnd = read_memory<std::uintptr_t>(ClassDescriptor + 0x30, handle);

            for (std::uintptr_t PropertyAddress = PropertiesStart; PropertyAddress < PropertiesEnd; PropertyAddress += 0x8) {
                std::uintptr_t PropertyPtr = read_memory<std::uintptr_t>(PropertyAddress, handle);
                if (PropertyPtr != 0)
                    Properties.push_back(functions::ReadRobloxString(read_memory<std::uintptr_t>(PropertyPtr + 0x8, handle), handle));
            }
        }
        return Properties;
    }

    // Variables
    inline std::uintptr_t Self() const {
        return _Self;
    }

    inline std::string Name() const {
        return functions::ReadRobloxString(read_memory<std::uintptr_t>(_Self + offsets::Name, handle), handle);
    }

    inline std::string ClassName() const {
        return functions::ReadRobloxString(read_memory<std::uintptr_t>(read_memory<std::uintptr_t>(_Self + offsets::ClassDescriptor, handle) + offsets::ClassName, handle), handle);
    }

    inline std::uintptr_t ParentAddress() const {
        return read_memory<std::uintptr_t>(_Self + offsets::Parent, handle);
    }

    inline std::unique_ptr<Instance> Parent() const {
        return std::make_unique<Instance>(ParentAddress(), handle);
    }
};

class RBXClient {
private:
    HANDLE handle;
    std::uintptr_t RenderView{};
public:
    std::string Username = "N/A";
    std::string Version  = "";
    std::string GUID;
    DWORD PID;

    // Attach status - read by the UI to show progress without blocking
    enum class Status { Attaching, Ready, Failed };
    std::atomic<Status> AttachStatus { Status::Attaching };
    std::string AttachError; // set on failure, read under clientsMtx

    std::string TeleportQueue;
    std::filesystem::path ClientDir;

    RBXClient(DWORD processID);

    inline bool isProcessAlive() const {
        DWORD exitCode;
        if (GetExitCodeProcess(handle, &exitCode)) {
            return exitCode == STILL_ACTIVE;
        }
        return false;
    }

    inline std::uintptr_t FetchDataModel() const {
        std::uintptr_t fakeDataModel = read_memory<std::uintptr_t>(RenderView + 0x118, handle);
        if (fakeDataModel == 0)
            std::cerr << "Could not fetch datamodel, expect a crash\n";
        return fakeDataModel + 0x190;
    }

    void execute(const std::string& source) const;
    bool loadstring(const std::string& source, const std::string& script_name, const std::string& chunk_name) const;

    void UnlockModule(const std::string_view objectval_name) const {
        std::uintptr_t scriptPtr = RBXClient::GetObjectValuePtr(objectval_name);
        if (scriptPtr == 0)
            return;

        return Instance(scriptPtr, handle).UnlockModule();
    }

    std::string GetBytecode(const std::string_view objectval_name) const {
        std::uintptr_t scriptPtr = RBXClient::GetObjectValuePtr(objectval_name);
        if (scriptPtr == 0)
            return "";

        return Instance(scriptPtr, handle).GetBytecode();
    }

    void SpoofInstance(const std::string_view objectval_name, std::uintptr_t new_address) const {
        std::uintptr_t instancePtr = RBXClient::GetObjectValuePtr(objectval_name);
        if (instancePtr == 0)
            return;

        write_memory<std::uintptr_t>(instancePtr + offsets::This, new_address, handle);
    }

    std::vector<std::string> GetProperties(const std::string_view objectval_name) const {
        std::uintptr_t instancePtr = RBXClient::GetObjectValuePtr(objectval_name);
        if (instancePtr == 0)
            return {};

        return Instance(instancePtr, handle).GetProperties();
    }

    std::uintptr_t GetObjectValuePtr(std::string_view objectval_name) const;
};

struct ClientInfo {
    const char* Version;
    const char* Username;
    int ProcessID;
};

class bytecode_encoder_t : public Luau::BytecodeEncoder {
    inline void encode(uint32_t* data, size_t count) override {
        for (auto i = 0u; i < count;) {
            auto& opcode = *reinterpret_cast<uint8_t*>(data + i);
            i += Luau::getOpLength(LuauOpcode(opcode));
            opcode *= 227;
        }
    }
};

std::vector<DWORD> GetProcessIDsByName(const std::wstring_view processName);
std::uintptr_t GetRV(HANDLE handle);

std::string compilable(const std::string& source, bool returnBytecode=false);
std::string Compile(const std::string& source);
std::string decompress(const std::string_view compressed);

HWND GetHWNDFromPID(DWORD process_id);