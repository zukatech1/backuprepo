﻿using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Net.Http;

namespace XenoUI
{
	public partial class ClientsWindow : Window
	{
		public string XenoVersion = "1.0.8";

		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
		public struct ClientInfo
		{
			public string version;
			public string name;
			public int id;
		}

		[DllImport("Xeno.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern void Initialize();

		[DllImport("Xeno.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern IntPtr GetClients();

		// Execute now takes (byte* source, int sourceLen, string[] users, int numUsers)
		// so C++ can construct std::string with an explicit length — no null terminator needed.
		[DllImport("Xeno.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
		private static extern void Execute(byte[] scriptSource, int scriptLen, string[] clientUsers, int numUsers);

		// Compilable also takes an explicit length now, and returns memory allocated with
		// CoTaskMemAlloc so Marshal.FreeCoTaskMem is the correct way to release it.
		[DllImport("Xeno.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
		private static extern IntPtr Compilable(byte[] scriptSource, int scriptLen);

		// Returns "attaching", "ready", "failed", or "unknown". Do NOT free this pointer.
		[DllImport("Xeno.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern IntPtr GetAttachStatus(int pid);

		private readonly DispatcherTimer _timer;
		public List<ClientInfo> ActiveClients { get; private set; } = new();

		public string SupportedVersion { get; private set; } = "";

		public ClientsWindow()
		{
			InitializeComponent();
			LoadSupportedVersion();
			Initialize();
			MouseLeftButtonDown += (_, _) => DragMove();

			_timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(100) };
			_timer.Tick += UpdateClientList;
			_timer.Start();
		}

		private async void LoadSupportedVersion()
		{
			try
			{
				using var client = new HttpClient();
				string latestVersion = await client.GetStringAsync("https://rizve.us.to/Xeno/LatestVersion");
				if (latestVersion != XenoVersion)
				{
					MessageBox.Show($"The current version {XenoVersion} is outdated.\n\nPlease download the latest version of Xeno ({latestVersion}) here: https://discord.gg/fQNzTw2JXn", "Outdated Xeno version", MessageBoxButton.OK, MessageBoxImage.Warning);
					Application.Current.Shutdown();
				}
				SupportedVersion = await client.GetStringAsync("https://rizve.us.to/Xeno/AcceptedVersion");
			}
			catch (HttpRequestException e)
			{
				MessageBox.Show($"Error fetching versions: {e.Message}");
			}
		}

		private string GetClientAttachStatus(int pid)
		{
			try
			{
				IntPtr ptr = GetAttachStatus(pid);
				return Marshal.PtrToStringAnsi(ptr) ?? "unknown";
				// Do NOT free — pointer is a C string literal
			}
			catch { return "unknown"; }
		}

		private static System.Windows.Media.Brush StatusToBrush(string status) => status switch
		{
			"ready"     => System.Windows.Media.Brushes.LightGreen,
			"attaching" => System.Windows.Media.Brushes.Yellow,
			"failed"    => System.Windows.Media.Brushes.OrangeRed,
			_           => System.Windows.Media.Brushes.Gray,
		};

		private void UpdateClientList(object sender, EventArgs e)
		{
			var newClients = GetClientsFromDll().ToDictionary(c => c.id);

			// Remove clients that are gone
			checkBoxContainer.Children.OfType<Grid>()
				.Where(g => {
					var tag = g.Tag as string;
					return tag != null && !newClients.ContainsKey(GetClientId(tag));
				})
				.ToList()
				.ForEach(g => checkBoxContainer.Children.Remove(g));

			foreach (var client in newClients.Values)
			{
				string label = $"{client.name}, PID: {client.id}";
				var existing = checkBoxContainer.Children.OfType<Grid>()
					.FirstOrDefault(g => g.Tag as string == label);

				if (existing == null)
				{
					if (!string.IsNullOrWhiteSpace(client.name))
						AddClientRow(client);
				}
				else
				{
					// Refresh the status dot on already-shown clients
					var dot = existing.Children.OfType<System.Windows.Shapes.Ellipse>().FirstOrDefault();
					if (dot != null)
					{
						string status = GetClientAttachStatus(client.id);
						dot.Fill = StatusToBrush(status);
						dot.ToolTip = status;
					}
				}
			}

			ActiveClients = checkBoxContainer.Children.OfType<Grid>()
				.Select(g => {
					var cb = g.Children.OfType<CheckBox>().FirstOrDefault();
					var tag = g.Tag as string;
					if (cb?.IsChecked == true && tag != null)
						return new ClientInfo { name = GetClientName(tag), id = GetClientId(tag) };
					return default;
				})
				.Where(c => c.name != null)
				.ToList();
		}

		private async Task AddClientRow(ClientInfo client)
		{
			if (client.name == "N/A") return;

			string label = $"{client.name}, PID: {client.id}";

			// Row grid: [status dot] [checkbox] 
			var row = new Grid { Tag = label, Margin = new Thickness(4, 2, 4, 2) };
			row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

			// Status dot
			var dot = new System.Windows.Shapes.Ellipse
			{
				Width = 10, Height = 10,
				Fill = StatusToBrush("attaching"),
				VerticalAlignment = VerticalAlignment.Center,
				Margin = new Thickness(0, 0, 6, 0),
				ToolTip = "attaching"
			};
			Grid.SetColumn(dot, 0);

			var cb = new CheckBox
			{
				Content = label,
				Foreground = System.Windows.Media.Brushes.White,
				FontFamily = new System.Windows.Media.FontFamily("Franklin Gothic Medium"),
				IsChecked = true,
				Background = System.Windows.Media.Brushes.Black,
				VerticalAlignment = VerticalAlignment.Center
			};
			Grid.SetColumn(cb, 1);

			row.Children.Add(dot);
			row.Children.Add(cb);
			checkBoxContainer.Children.Add(row);

			// Wait for supported version before warning about mismatches
			while (string.IsNullOrWhiteSpace(SupportedVersion))
				await Task.Delay(5);

			if (SupportedVersion != client.version)
				MessageBox.Show(
					$"Xeno might not be compatible on client {client.name} with {client.version}\n\nSupported: {SupportedVersion}\n\nClick OK to continue.",
					"Version Mismatch", MessageBoxButton.OK, MessageBoxImage.Warning);
		}

		public void ExecuteScript(string script)
		{
			var clientUsers = ActiveClients.Select(c => c.name).ToArray();
			byte[] scriptBytes = Encoding.UTF8.GetBytes(script);
			Execute(scriptBytes, scriptBytes.Length, clientUsers, clientUsers.Length);
		}

		public string GetCompilableStatus(string script)
		{
			byte[] scriptBytes = Encoding.UTF8.GetBytes(script);
			IntPtr resultPtr = Compilable(scriptBytes, scriptBytes.Length);
			if (resultPtr == IntPtr.Zero) return "error";
			string result = Marshal.PtrToStringAnsi(resultPtr) ?? "error";
			Marshal.FreeCoTaskMem(resultPtr);
			return result;
		}

		private List<ClientInfo> GetClientsFromDll()
		{
			var clients = new List<ClientInfo>();
			IntPtr currentPtr = GetClients();
			while (true)
			{
				var client = Marshal.PtrToStructure<ClientInfo>(currentPtr);
				if (client.name == null) break;
				clients.Add(client);
				currentPtr += Marshal.SizeOf<ClientInfo>();
			}
			return clients;
		}

		private static int GetClientId(string content) => int.Parse(content.Split(", PID: ")[1]);
		private static string GetClientName(string content) => content.Split(", PID: ")[0].Trim();

		private void buttonClose_Click(object sender, RoutedEventArgs e) => Hide();
	}
}
