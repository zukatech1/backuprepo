-- This Script is Part of the ZukaTech Obfuscator by Levno_710
--
-- pipeline.lua
--
-- This Script Provides some configuration presets

return {
    ["Minify"] = {
        -- The default LuaVersion is Lua51
        LuaVersion = "Lua51";
        -- For minifying no VarNamePrefix is applied
        VarNamePrefix = "";
        -- Name Generator for Variables
        NameGenerator = "MangledShuffled";
        -- No pretty printing
        PrettyPrint = false;
        -- Seed is generated based on current time
        Seed = 0;
        -- No obfuscation steps
        Steps = {

        }
    };
    ["Weak"] = {
        -- The default LuaVersion is Lua51
        LuaVersion = "Lua51";
        -- For minifying no VarNamePrefix is applied
        VarNamePrefix = "";
        -- Name Generator for Variables that look like this: IlI1lI1l
        NameGenerator = "MangledShuffled";
        -- No pretty printing
        PrettyPrint = false;
        -- Seed is generated based on current time
        Seed = 0;
        -- Obfuscation steps
        Steps = {
            {
                Name = "Vmify";
                Settings = {

                };
            },
            {
                Name = "ConstantArray";
                Settings = {
                    Treshold    = 1;
                    StringsOnly = true;
                }
            },
            {
                Name = "WrapInFunction";
                Settings = {

                }
            },
        }
    };
    ["Vmify"] = {
        -- The default LuaVersion is Lua51
        LuaVersion = "Lua51";
        -- For minifying no VarNamePrefix is applied
        VarNamePrefix = "";
        -- Name Generator for Variables that look like this: IlI1lI1l
        NameGenerator = "MangledShuffled";
        -- No pretty printing
        PrettyPrint = false;
        -- Seed is generated based on current time
        Seed = 0;
        -- Obfuscation steps
        Steps = {
            {
                Name = "Vmify";
                Settings = {

                };
            },
        }
    };
    ["Medium"] = {
        -- The default LuaVersion is Lua51
        LuaVersion = "Lua51";
        -- For minifying no VarNamePrefix is applied
        VarNamePrefix = "";
        -- Name Generator for Variables
        NameGenerator = "MangledShuffled";
        -- No pretty printing
        PrettyPrint = false;
        -- Seed is generated based on current time
        Seed = 0;
        -- Obfuscation steps
        Steps = {
            {
                Name = "EncryptStrings";
                Settings = {

                };
            },
            {
                Name = "AntiTamper";
                Settings = {
                    UseDebug = false;
                };
            },
            {
                Name = "Vmify";
                Settings = {

                };
            },
            {
                Name = "ConstantArray";
                Settings = {
                    Treshold    = 1;
                    StringsOnly = true;
                    Shuffle     = true;
                    Rotate      = true;
                    LocalWrapperTreshold = 0;
                }
            },
            {
                Name = "NumbersToExpressions";
                Settings = {

                }
            },
            {
                Name = "WrapInFunction";
                Settings = {

                }
            },
        }
    };
    ["Strong"] = {
        -- The default LuaVersion is Lua51
        LuaVersion = "Lua51";
        -- For minifying no VarNamePrefix is applied
        VarNamePrefix = "";
        -- Name Generator for Variables that look like this: IlI1lI1l
        NameGenerator = "MangledShuffled";
        -- No pretty printing
        PrettyPrint = false;
        -- Seed is generated based on current time
        Seed = 0;
        -- Obfuscation steps
        Steps = {
            {
                Name = "Vmify";
                Settings = {

                };
            },
            {
                Name = "EncryptStrings";
                Settings = {

                };
            },
            {
                Name = "AntiTamper";
                Settings = {

                };
            },
            {
                Name = "Vmify";
                Settings = {

                };
            },
            {
                Name = "ConstantArray";
                Settings = {
                    Treshold    = 1;
                    StringsOnly = true;
                    Shuffle     = true;
                    Rotate      = true;
                    LocalWrapperTreshold = 0;
                }
            },
            {
                Name = "NumbersToExpressions";
                Settings = {

                }
            },
            {
                Name = "WrapInFunction";
                Settings = {

                }
            },
        }
    },
    -- -------------------------------------------------------------------------
    -- LuarmorStyle – mirrors the three-layer obfuscation seen in Luarmor's
    -- highest-tier output (client_1.lua analysis):
    --   1. VM bytecode compilation          (Vmify x2 for double-lift)
    --   2. String encryption                (EncryptStrings)
    --   3. Anti-tamper hooks                (AntiTamper)
    --   4. Constant array + rotation        (ConstantArray)
    --   5. Number → expression splitting    (NumbersToExpressions)
    --   6. Dead local arithmetic chains     (JunkStatements)  <- NEW
    --   7. Fake while-true-break wrappers   (FakeLoopWrap)    <- NEW
    --   8. Script wrapped in anon function  (WrapInFunction)
    -- -------------------------------------------------------------------------
    ["LuarmorStyle"] = {
        LuaVersion    = "Lua51";
        VarNamePrefix = "";
        NameGenerator = "MangledShuffled";
        PrettyPrint   = false;
        Seed          = 0;
        Steps = {
            {
                Name     = "Vmify";
                Settings = {};
            },
            {
                Name     = "EncryptStrings";
                Settings = {};
            },
            {
                Name     = "AntiTamper";
                Settings = { UseDebug = false };
            },
            {
                Name     = "Vmify";
                Settings = {};
            },
            {
                Name = "ConstantArray";
                Settings = {
                    Treshold             = 1;
                    StringsOnly          = true;
                    Shuffle              = true;
                    Rotate               = true;
                    LocalWrapperTreshold = 0;
                };
            },
            {
                Name = "NumbersToExpressions";
                Settings = {
                    Treshold         = 1;
                    InternalTreshold = 0.2;
                };
            },
            {
                Name = "JunkStatements";
                Settings = {
                    InjectionCount  = 4;
                    Treshold        = 0.85;
                    TableWriteRatio = 0.5;
                    ChainLength     = 3;
                    TableWriteCount = 3;
                };
            },
            {
                Name = "FakeLoopWrap";
                Settings = {
                    Treshold = 0.30;
                };
            },
            {
                Name     = "WrapInFunction";
                Settings = {};
            },
        };
    };
}
