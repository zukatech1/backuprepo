-- Obfuscation Step: Opaque Predicates & Control-Flow Junk
--
-- Tier 1 Upgrade #3: Injects opaque predicates — conditions that are ALWAYS
-- true (or false) but are computationally difficult for a static analyser to
-- prove, forcing any analyst to symbolically evaluate complex math.
--
-- Predicate catalogue (always-true examples):
--   • sin(x)^2 + cos(x)^2 > 0.5          (Pythagorean identity ≡ 1)
--   • (n*(n+1)) % 2 == 0                  (product of consecutive ints)
--   • floor(sqrt(n*n)) == n               (perfect square)
--   • (a^3 + b^3) ~= (a+b)^3 - 3*a*b*(a+b)  (always FALSE for a,b≠0 → negated)
--   • (x % p) * (p - (x % p)) >= 0        (non-negative by def)
--
-- Each predicate is wrapped around dead blocks so decompilers see legitimate
-- if/else branches but can never simplify the tree without solving the math.

local Step     = require("ZukaTech.step")
local Ast      = require("ZukaTech.ast")
local Scope    = require("ZukaTech.scope")
local visitast = require("ZukaTech.visitast")
local Parser   = require("ZukaTech.parser")
local Enums    = require("ZukaTech.enums")

local AstKind    = Ast.AstKind
local LuaVersion = Enums.LuaVersion

local OpaquePredicates       = Step:extend()
OpaquePredicates.Description = "Injects always-true/false opaque predicates (trig identities, number theory) to prevent static control-flow analysis."
OpaquePredicates.Name        = "Opaque Predicates"

OpaquePredicates.SettingsDescriptor = {
    Treshold = {
        name    = "Treshold",
        description = "Probability that each function block gets a predicate injection",
        type    = "number",
        default = 0.75,
        min     = 0,
        max     = 1,
    },
    InjectionsPerBlock = {
        name    = "InjectionsPerBlock",
        description = "Max predicates injected per block",
        type    = "number",
        default = 2,
        min     = 1,
        max     = 6,
    },
}

function OpaquePredicates:init(settings) end

-- ── predicate generators (return Lua code string, always evaluates TRUE) ─────

local predicates = {
    -- sin²(x) + cos²(x) == 1, so > 0.5 is always true
    function()
        local x = math.random(1, 1000) + math.random() 
        return string.format(
            "(math.sin(%s)^2 + math.cos(%s)^2) > 0.5",
            tostring(x), tostring(x)
        )
    end,

    -- product of two consecutive integers is always even
    function()
        local n = math.random(2, 500)
        return string.format(
            "(%d * %d) %% 2 == 0",
            n, n + 1
        )
    end,

    -- floor(sqrt(n^2)) == n for positive n
    function()
        local n = math.random(3, 200)
        return string.format(
            "math.floor(math.sqrt(%d * %d)) == %d",
            n, n, n
        )
    end,

    -- x mod p is in [0, p-1], so x*(p-x) can be negative? No: p chosen > x_mod
    -- Instead: abs-like: (v - math.floor(v)) >= 0 (fractional part always ≥ 0)
    function()
        local v = math.random(10, 300) + 0.5
        return string.format(
            "(%s - math.floor(%s)) >= 0",
            tostring(v), tostring(v)
        )
    end,

    -- (2^n) mod 2 == 0 for n >= 1
    function()
        local n = math.random(1, 20)
        return string.format(
            "(2^%d) %% 2 == 0",
            n
        )
    end,

    -- a*0 == 0 but wrapped in complex expression
    function()
        local a = math.random(50, 9999)
        local b = math.random(1, 49)
        -- (a - a) * b == 0
        return string.format(
            "(%d - %d) * %d == 0",
            a, a, b
        )
    end,

    -- math.max(a,b) >= a always true
    function()
        local a = math.random(1, 500)
        local b = math.random(a + 1, a + 500)
        return string.format(
            "math.max(%d, %d) >= %d",
            a, b, a
        )
    end,

    -- n^2 >= 0 always (squares are non-negative)
    function()
        local n = math.random(-300, 300)
        return string.format(
            "(%d)^2 >= 0",
            n
        )
    end,
}

-- ── dead block content (realistic-looking but unreachable) ───────────────────

local function deadBlock(scope)
    -- A block that looks like it does work but is inside an always-false branch
    local innerScope = Scope:new(scope)
    local stmts = {}

    -- local _dX = random_number
    local dVar = innerScope:addVariable()
    table.insert(stmts, Ast.LocalVariableDeclaration(innerScope, {dVar},
        {Ast.NumberExpression(math.random(1, 65535))}))

    -- _dX = _dX * random + random
    table.insert(stmts, Ast.AssignmentStatement(
        {Ast.AssignmentVariable(innerScope, dVar)},
        {Ast.AddExpression(
            Ast.MulExpression(
                Ast.VariableExpression(innerScope, dVar),
                Ast.NumberExpression(math.random(2, 127))
            ),
            Ast.NumberExpression(math.random(1, 255))
        )}
    ))

    -- _dX = nil
    table.insert(stmts, Ast.AssignmentStatement(
        {Ast.AssignmentVariable(innerScope, dVar)},
        {Ast.NilExpression()}
    ))

    return Ast.Block(stmts, innerScope)
end

-- ── build an if statement with opaque predicate ──────────────────────────────

local function buildPredicateStatement(parentScope, parser)
    local pred = predicates[math.random(#predicates)]()

    -- Wrap: if <pred> then <real empty block> else <dead block> end
    -- The "real" branch is empty; the dead branch has junk.
    -- Analyst sees an if/else and must evaluate pred to know which runs.
    local code = string.format("if %s then end", pred)
    local ok, parsed = pcall(function()
        return parser:parse(code)
    end)
    if not ok then return nil end

    local ifStat = parsed.body.statements[1]
    if ifStat then
        ifStat.elseBody = deadBlock(parentScope)
        if ifStat.body then
            ifStat.body.scope:setParent(parentScope)
        end
    end
    return ifStat
end

-- ── apply ────────────────────────────────────────────────────────────────────

function OpaquePredicates:apply(ast, pipeline)
    local parser = Parser:new({ LuaVersion = LuaVersion.Lua51 })

    visitast(ast, nil, function(node, data)
        if node.kind ~= AstKind.Block then return end
        if not node.isFunctionBlock then return end
        if math.random() > self.Treshold then return end
        if #node.statements == 0 then return end

        local count = math.random(1, self.InjectionsPerBlock)
        for _ = 1, count do
            local stat = buildPredicateStatement(node.scope, parser)
            if stat then
                -- Insert at a random position that isn't after return/break
                local insertPos = math.random(1, #node.statements)
                -- Don't insert after a return
                local last = node.statements[#node.statements]
                if last and (last.kind == AstKind.ReturnStatement
                          or last.kind == AstKind.BreakStatement) then
                    insertPos = math.max(1, #node.statements - 1)
                end
                table.insert(node.statements, insertPos, stat)
            end
        end
    end)

    return ast
end

return OpaquePredicates
