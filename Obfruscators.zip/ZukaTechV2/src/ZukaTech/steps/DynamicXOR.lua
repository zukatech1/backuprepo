-- Obfuscation Step: Dynamic XOR Constant Decryption
--
-- Tier 1 Upgrade #1: Instead of decoding the constant pool once at startup,
-- each constant remains encrypted. At access time the cipher key is derived
-- from the current "program counter" (a runtime counter incremented each
-- opcode dispatch), so a hook that dumps after the init loop sees nothing.
--
-- Implementation strategy:
--   • Wraps every string literal in a DXOR(encBytes, idx) call where idx is
--     a per-call unique integer (the "instruction seed").
--   • The runtime DXOR function XORs each byte with:
--       key_byte = base_key XOR ((inst_seed * PRIME + byte_pos) % 251)
--     This is cheap, Lua-5.1-compatible, and changes per call-site.
--   • A global "vm_pc" counter (localised) is incremented on every DXOR call
--     so the effective key also shifts with execution order.

local Step       = require("ZukaTech.step")
local Ast        = require("ZukaTech.ast")
local Scope      = require("ZukaTech.scope")
local visitast   = require("ZukaTech.visitast")
local util       = require("ZukaTech.util")
local Parser     = require("ZukaTech.parser")
local Enums      = require("ZukaTech.enums")

local AstKind    = Ast.AstKind
local LuaVersion = Enums.LuaVersion

local DynamicXOR       = Step:extend()
DynamicXOR.Description = "Per-call-site dynamic XOR: constants stay encrypted; key changes each access via a VM program-counter state variable."
DynamicXOR.Name        = "Dynamic XOR"

DynamicXOR.SettingsDescriptor = {
    Treshold = {
        name        = "Treshold",
        description = "Fraction of string nodes to encrypt (0–1)",
        type        = "number",
        default     = 1,
        min         = 0,
        max         = 1,
    },
}

function DynamicXOR:init(settings) end

-- ── helpers ──────────────────────────────────────────────────────────────────

local function bxor51(a, b)
    -- Lua 5.1 compatible bitwise XOR (no bit32 / ~ operator)
    local r, m = 0, 1
    while a > 0 or b > 0 do
        local ra = a % 2
        local rb = b % 2
        if ra ~= rb then r = r + m end
        a = math.floor(a / 2)
        b = math.floor(b / 2)
        m = m * 2
    end
    return r
end

local PRIME = 16777619  -- FNV prime

local function encryptString(str, instSeed, baseKey)
    local out = {}
    for i = 1, #str do
        local b      = string.byte(str, i)
        local kbyte  = bxor51(baseKey, (instSeed * PRIME + i) % 251)
        out[i]       = string.char(bxor51(b, kbyte) % 256)
    end
    return table.concat(out)
end

-- ── runtime code template ────────────────────────────────────────────────────

local function buildRuntimeCode(baseKey, prime)
    return string.format([[
do
    local _floor  = math.floor
    local _byte   = string.byte
    local _char   = string.char
    local _concat = table.concat
    local _bkey   = %d
    local _prime  = %d
    local _vpc    = 0   -- vm program-counter; increments each decrypt call

    local function _bxor(a, b)
        local r, m = 0, 1
        while a > 0 or b > 0 do
            local ra = a %% 2
            local rb = b %% 2
            if ra ~= rb then r = r + m end
            a = _floor(a / 2)
            b = _floor(b / 2)
            m = m * 2
        end
        return r
    end

    -- _pc_shift: extra entropy from execution order
    local function _pc_shift()
        _vpc = (_vpc + 1) %% 65521   -- prime modulus keeps it bounded
        return _vpc
    end

    DXOR_CACHE = {}

    function DXOR(enc, inst)
        local cache = DXOR_CACHE
        local ckey  = inst * 1000003 + _pc_shift()
        if cache[inst] then
            return cache[inst]
        end
        local n    = #enc
        local out  = {}
        for i = 1, n do
            local eb   = _byte(enc, i)
            local kbyte = _bxor(_bkey, (inst * _prime + i) %% 251)
            out[i]     = _char(_bxor(eb, kbyte) %% 256)
        end
        local result    = _concat(out)
        cache[inst]     = result
        return result
    end
end
]], baseKey, prime)
end

-- ── apply ────────────────────────────────────────────────────────────────────

function DynamicXOR:apply(ast, pipeline)
    local baseKey  = math.random(1, 127)
    local instSeed = 0   -- monotonically increasing per string

    -- 1. Parse and inject runtime code
    local rtCode   = buildRuntimeCode(baseKey, PRIME)
    local parser   = Parser:new({ LuaVersion = LuaVersion.Lua51 })
    local rtAst    = parser:parse(rtCode)
    local doStat   = rtAst.body.statements[1]

    local rootScope  = ast.body.scope
    local dxorVar    = rootScope:addVariable()
    local cacheVar   = rootScope:addVariable()

    doStat.body.scope:setParent(rootScope)

    visitast(rtAst, nil, function(node, data)
        if node.kind == AstKind.FunctionDeclaration then
            if node.scope:getVariableName(node.id) == "DXOR" then
                data.scope:removeReferenceToHigherScope(node.scope, node.id)
                data.scope:addReferenceToHigherScope(rootScope, dxorVar)
                node.scope = rootScope
                node.id    = dxorVar
            end
        end
        if node.kind == AstKind.AssignmentVariable or node.kind == AstKind.VariableExpression then
            if node.scope:getVariableName(node.id) == "DXOR_CACHE" then
                data.scope:removeReferenceToHigherScope(node.scope, node.id)
                data.scope:addReferenceToHigherScope(rootScope, cacheVar)
                node.scope = rootScope
                node.id    = cacheVar
            end
        end
    end)

    table.insert(ast.body.statements, 1, doStat)
    table.insert(ast.body.statements, 1,
        Ast.LocalVariableDeclaration(rootScope, util.shuffle{dxorVar, cacheVar}, {}))

    -- 2. Walk AST and replace string literals with DXOR(enc, seed) calls
    visitast(ast, nil, function(node, data)
        if node.kind == AstKind.StringExpression and math.random() <= self.Treshold then
            instSeed = instSeed + math.random(1, 31)   -- non-sequential gaps look natural
            local enc = encryptString(node.value, instSeed, baseKey)
            local seed = instSeed

            data.scope:addReferenceToHigherScope(rootScope, dxorVar)
            return Ast.FunctionCallExpression(
                Ast.VariableExpression(rootScope, dxorVar),
                {
                    Ast.StringExpression(enc),
                    Ast.NumberExpression(seed),
                }
            )
        end
    end)

    return ast
end

return DynamicXOR
