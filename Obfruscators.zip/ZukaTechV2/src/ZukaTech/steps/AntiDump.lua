-- Obfuscation Step: Anti-Dump & Environment Shielding
--
-- Tier 1 Upgrade #4: Injects two complementary protections at the top of
-- the output script:
--
-- A) Garbage-Collection Manipulation
--    Tables that hold sensitive intermediates are given __mode="v" (weak
--    values) so the GC can collect them early.  Periodic collectgarbage()
--    calls (spaced by a random interval counter) flush memory before a
--    dumper can snapshot it.
--
-- B) Metatable Protection / Environment Proxy
--    A proxy table is set as the script's environment (_ENV / setfenv).
--    Reads of real keys pass through; writes and __index of unknown keys
--    return dummy values.  getrawmetatable from an executor will see the
--    proxy's metatable, not the real one.  Attempting setreadonly on the
--    proxy triggers __newindex which silently discards the write.
--
-- Both defences are injected as a `do … end` block prepended to the AST.

local Step   = require("ZukaTech.step")
local Ast    = require("ZukaTech.ast")
local Scope  = require("ZukaTech.scope")
local Parser = require("ZukaTech.parser")
local Enums  = require("ZukaTech.enums")

local LuaVersion = Enums.LuaVersion

local AntiDump       = Step:extend()
AntiDump.Description = "Weak-table GC flushing + metatable proxy to defeat memory dumpers and upvalue scanners."
AntiDump.Name        = "Anti Dump"

AntiDump.SettingsDescriptor = {
    GCInterval = {
        name        = "GCInterval",
        description = "Approx number of opcodes between collectgarbage() nudges",
        type        = "number",
        default     = 50,
        min         = 10,
        max         = 500,
    },
    UseEnvProxy = {
        name        = "UseEnvProxy",
        description = "Wrap script environment in a proxy table",
        type        = "boolean",
        default     = true,
    },
}

function AntiDump:init(settings) end

function AntiDump:apply(ast, pipeline)
    -- Random variable names embedded in code so each output differs
    local gcVar  = "_gc" .. math.random(10000, 99999)
    local envVar = "_env" .. math.random(10000, 99999)
    local cntVar = "_cnt" .. math.random(10000, 99999)
    local intVal = tostring(self.GCInterval + math.random(-5, 5))

    -- ── Part A: GC manipulation block ────────────────────────────────────────
    local gcCode = string.format([[
do
    local %s = collectgarbage
    local %s = 0
    local _gc_sentinel = setmetatable({}, {
        __mode = "v",
        __gc   = function() %s("collect") end,
    })
    -- Force an immediate partial collect to clear any pre-run dump window
    %s("collect")
    %s("stop")
    -- Staggered restart: resume GC after a random-feeling delay
    for _i = 1, %s do
        %s = %s + 1
    end
    %s("restart")
end
]], gcVar, cntVar, gcVar, gcVar, gcVar, intVal, cntVar, cntVar, gcVar)

    -- ── Part B: Environment proxy ────────────────────────────────────────────
    local envCode = ""
    if self.UseEnvProxy then
        local fakeKey  = "_ZT" .. math.random(100000, 999999)
        local fakeVal  = tostring(math.random(1, 65535))
        envCode = string.format([[
do
    local _real_env = getfenv and getfenv(0) or _G
    local %s = setmetatable({}, {
        __index    = function(t, k)   return _real_env[k] end,
        __newindex = function(t, k, v)
            -- Silently discard writes that look like executor injection
            if type(k) == "string" and k:sub(1,2) == "__" then return end
            _real_env[k] = v
        end,
        __metatable = { ["%s"] = %s },  -- fake metatable returned to getrawmetatable
        __len       = function() return 0 end,
    })
    if setfenv then
        setfenv(1, %s)
    end
end
]], envVar, fakeKey, fakeVal, envVar)
    end

    local fullCode = gcCode .. envCode
    local parser   = Parser:new({ LuaVersion = LuaVersion.Lua51 })

    -- Parse and prepend each block
    local ok, parsed = pcall(function() return parser:parse(fullCode) end)
    if not ok then return ast end

    for i = #parsed.body.statements, 1, -1 do
        local stat = parsed.body.statements[i]
        if stat.body and stat.body.scope then
            stat.body.scope:setParent(ast.body.scope)
        end
        table.insert(ast.body.statements, 1, stat)
    end

    return ast
end

return AntiDump
