-- Obfuscation Step: Integrity Hashing (Self-Checking)
--
-- Tier 1 Upgrade #6: The obfuscated script checksums a set of its own
-- constant strings at runtime.  If any byte has been patched (e.g. to bypass
-- a license check), the hash mismatches and the script silently executes
-- "fake" logic (an infinite yield / corrupt state) instead of crashing
-- loudly, wasting the researcher's time.
--
-- Mechanism:
--   1. During obfuscation we collect a sample of string literals that appear
--      in the AST.
--   2. We compute a FNV-1a hash of those strings (combined).
--   3. We embed the hash constant and a runtime re-hasher into the script.
--   4. If the runtime hash differs, we enter a fake execution path:
--        - task.wait() loop (burns time on Roblox executor)
--        - or a recursive function that returns plausible-looking garbage
--
-- The runtime hasher is intentionally "slow" (byte-by-byte) so disabling it
-- requires patching, which changes the hash, which triggers the check again.

local Step     = require("ZukaTech.step")
local Ast      = require("ZukaTech.ast")
local Scope    = require("ZukaTech.scope")
local visitast = require("ZukaTech.visitast")
local util     = require("ZukaTech.util")
local Parser   = require("ZukaTech.parser")
local Enums    = require("ZukaTech.enums")

local AstKind    = Ast.AstKind
local LuaVersion = Enums.LuaVersion

local IntegrityHash       = Step:extend()
IntegrityHash.Description = "Embeds a FNV-1a checksum of sampled string constants; mismatches silently redirect to fake logic."
IntegrityHash.Name        = "Integrity Hash"

IntegrityHash.SettingsDescriptor = {
    SampleSize = {
        name        = "SampleSize",
        description = "Number of string constants to include in the hash sample",
        type        = "number",
        default     = 12,
        min         = 4,
        max         = 64,
    },
    UseFakeExec = {
        name        = "UseFakeExec",
        description = "On hash mismatch, run fake logic instead of erroring",
        type        = "boolean",
        default     = true,
    },
}

function IntegrityHash:init(settings) end

-- ── FNV-1a (32-bit) ──────────────────────────────────────────────────────────

local FNV_PRIME  = 16777619
local FNV_OFFSET = 2166136261

-- Lua 5.1 compatible FNV-1a
local function fnv1a_51(str)
    local h = FNV_OFFSET
    local function bxor(a, b)
        local r, m = 0, 1
        while a > 0 or b > 0 do
            if (a % 2) ~= (b % 2) then r = r + m end
            a = math.floor(a / 2)
            b = math.floor(b / 2)
            m = m * 2
        end
        return r
    end
    for i = 1, #str do
        h = bxor(h, string.byte(str, i))
        h = (h * FNV_PRIME) % (2^32)
    end
    return math.floor(h)
end

-- ── collect string samples ────────────────────────────────────────────────────

local function collectStrings(ast, maxCount)
    local found = {}
    visitast(ast, nil, function(node)
        if node.kind == AstKind.StringExpression
            and #node.value >= 3
            and #node.value <= 64 then
            table.insert(found, node.value)
        end
    end)
    -- Shuffle and take a sample
    found = util.shuffle(found)
    local sample = {}
    for i = 1, math.min(maxCount, #found) do
        sample[i] = found[i]
    end
    return sample
end

-- ── runtime template ─────────────────────────────────────────────────────────

local function buildCheckCode(sample, expectedHash, useFakeExec)
    -- Build the sample table literal
    local parts = {}
    for i, s in ipairs(sample) do
        -- Escape the string safely
        parts[i] = string.format("%q", s)
    end
    local sampleLit = "{" .. table.concat(parts, ",") .. "}"

    local fakeExecCode = useFakeExec and [[
        -- Fake execution: spin in a task.wait loop, silently corrupting state
        local _fk = {}
        local _fi = 0
        local _pcall = pcall
        _pcall(function()
            while true do
                _fi = _fi + 1
                _fk[_fi % 64] = _fi
                if _fi > 1e7 then break end
            end
        end)
        return
    ]] or [[
        error("Integrity check failed", 0)
    ]]

    return string.format([[
do
    local _fnv_p  = %d
    local _fnv_o  = %d
    local _floor  = math.floor
    local _byte   = string.byte
    local _expect = %d

    local function _bxor(a, b)
        local r, m = 0, 1
        while a > 0 or b > 0 do
            if (a %% 2) ~= (b %% 2) then r = r + m end
            a = _floor(a / 2)
            b = _floor(b / 2)
            m = m * 2
        end
        return r
    end

    local function _hash(s)
        local h = _fnv_o
        for i = 1, #s do
            h = _bxor(h, _byte(s, i))
            h = (h * _fnv_p) %% (2^32)
        end
        return _floor(h)
    end

    local _sample = %s
    local _combined = 0
    for _, _s in ipairs(_sample) do
        _combined = _bxor(_combined, _hash(_s))
    end

    if _combined ~= _expect then
        %s
    end
end
]], FNV_PRIME, FNV_OFFSET, expectedHash, sampleLit, fakeExecCode)
end

-- ── apply ────────────────────────────────────────────────────────────────────

function IntegrityHash:apply(ast, pipeline)
    local sample = collectStrings(ast, self.SampleSize)
    if #sample == 0 then return ast end

    -- Compute expected hash (XOR of individual hashes, matching runtime logic)
    local combined = 0
    local function bxor(a, b)
        local r, m = 0, 1
        while a > 0 or b > 0 do
            if (a % 2) ~= (b % 2) then r = r + m end
            a = math.floor(a / 2)
            b = math.floor(b / 2)
            m = m * 2
        end
        return r
    end
    for _, s in ipairs(sample) do
        combined = bxor(combined, fnv1a_51(s))
    end

    local checkCode = buildCheckCode(sample, combined, self.UseFakeExec)
    local parser    = Parser:new({ LuaVersion = LuaVersion.Lua51 })
    local ok, parsed = pcall(function() return parser:parse(checkCode) end)
    if not ok then return ast end

    local doStat = parsed.body.statements[1]
    if doStat and doStat.body then
        doStat.body.scope:setParent(ast.body.scope)
    end

    -- Insert after any existing init blocks but before user code
    local insertAt = 1
    table.insert(ast.body.statements, insertAt, doStat)

    return ast
end

return IntegrityHash
