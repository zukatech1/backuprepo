-- This Script is Part of the ZukaTech Obfuscator by Levno_710
--
-- pipeline.lua
--
-- This Script Provides some configuration presets

return {
    ["Minify"] = {
        -- The default LuaVersion is Lua51
        LuaVersion = "Lua51";
        -- For minifying no VarNamePrefix is applied
        VarNamePrefix = "";
        -- Name Generator for Variables
        NameGenerator = "MangledShuffled";
        -- No pretty printing
        PrettyPrint = false;
        -- Seed is generated based on current time
        Seed = 0;
        -- No obfuscation steps
        Steps = {

        }
    };
    ["Weak"] = {
        -- The default LuaVersion is Lua51
        LuaVersion = "Lua51";
        -- For minifying no VarNamePrefix is applied
        VarNamePrefix = "";
        -- Name Generator for Variables that look like this: IlI1lI1l
        NameGenerator = "MangledShuffled";
        -- No pretty printing
        PrettyPrint = false;
        -- Seed is generated based on current time
        Seed = 0;
        -- Obfuscation steps
        Steps = {
            {
                Name = "Vmify";
                Settings = {

                };
            },
            {
                Name = "ConstantArray";
                Settings = {
                    Treshold    = 1;
                    StringsOnly = true;
                }
            },
            {
                Name = "WrapInFunction";
                Settings = {

                }
            },
        }
    };
    ["Vmify"] = {
        -- The default LuaVersion is Lua51
        LuaVersion = "Lua51";
        -- For minifying no VarNamePrefix is applied
        VarNamePrefix = "";
        -- Name Generator for Variables that look like this: IlI1lI1l
        NameGenerator = "MangledShuffled";
        -- No pretty printing
        PrettyPrint = false;
        -- Seed is generated based on current time
        Seed = 0;
        -- Obfuscation steps
        Steps = {
            {
                Name = "Vmify";
                Settings = {

                };
            },
        }
    };
    ["Medium"] = {
        -- The default LuaVersion is Lua51
        LuaVersion = "Lua51";
        -- For minifying no VarNamePrefix is applied
        VarNamePrefix = "";
        -- Name Generator for Variables
        NameGenerator = "MangledShuffled";
        -- No pretty printing
        PrettyPrint = false;
        -- Seed is generated based on current time
        Seed = 0;
        -- Obfuscation steps
        Steps = {
            {
                Name = "EncryptStrings";
                Settings = {

                };
            },
            {
                Name = "AntiTamper";
                Settings = {
                    UseDebug = false;
                };
            },
            {
                Name = "Vmify";
                Settings = {

                };
            },
            {
                Name = "ConstantArray";
                Settings = {
                    Treshold    = 1;
                    StringsOnly = true;
                    Shuffle     = true;
                    Rotate      = true;
                    LocalWrapperTreshold = 0;
                }
            },
            {
                Name = "NumbersToExpressions";
                Settings = {

                }
            },
            {
                Name = "WrapInFunction";
                Settings = {

                }
            },
        }
    };
    ["Strong"] = {
        -- The default LuaVersion is Lua51
        LuaVersion = "Lua51";
        -- For minifying no VarNamePrefix is applied
        VarNamePrefix = "";
        -- Name Generator for Variables that look like this: IlI1lI1l
        NameGenerator = "MangledShuffled";
        -- No pretty printing
        PrettyPrint = false;
        -- Seed is generated based on current time
        Seed = 0;
        -- Obfuscation steps
        Steps = {
            {
                Name = "Vmify";
                Settings = {

                };
            },
            {
                Name = "EncryptStrings";
                Settings = {

                };
            },
            {
                Name = "AntiTamper";
                Settings = {

                };
            },
            {
                Name = "Vmify";
                Settings = {

                };
            },
            {
                Name = "ConstantArray";
                Settings = {
                    Treshold    = 1;
                    StringsOnly = true;
                    Shuffle     = true;
                    Rotate      = true;
                    LocalWrapperTreshold = 0;
                }
            },
            {
                Name = "NumbersToExpressions";
                Settings = {

                }
            },
            {
                Name = "WrapInFunction";
                Settings = {

                }
            },
        }
    },
    -- -------------------------------------------------------------------------
    -- LuarmorStyle – mirrors the three-layer obfuscation seen in Luarmor's
    -- highest-tier output (client_1.lua analysis):
    --   1. VM bytecode compilation          (Vmify x2 for double-lift)
    --   2. String encryption                (EncryptStrings)
    --   3. Anti-tamper hooks                (AntiTamper)
    --   4. Constant array + rotation        (ConstantArray)
    --   5. Number → expression splitting    (NumbersToExpressions)
    --   6. Dead local arithmetic chains     (JunkStatements)  <- NEW
    --   7. Fake while-true-break wrappers   (FakeLoopWrap)    <- NEW
    --   8. Script wrapped in anon function  (WrapInFunction)
    -- -------------------------------------------------------------------------
    ["LuarmorStyle"] = {
        LuaVersion    = "Lua51";
        VarNamePrefix = "";
        NameGenerator = "MangledShuffled";
        PrettyPrint   = false;
        Seed          = 0;
        Steps = {
            {
                Name     = "Vmify";
                Settings = {};
            },
            {
                Name     = "EncryptStrings";
                Settings = {};
            },
            {
                Name     = "AntiTamper";
                Settings = { UseDebug = false };
            },
            {
                Name     = "Vmify";
                Settings = {};
            },
            {
                Name = "ConstantArray";
                Settings = {
                    Treshold             = 1;
                    StringsOnly          = true;
                    Shuffle              = true;
                    Rotate               = true;
                    LocalWrapperTreshold = 0;
                };
            },
            {
                Name = "NumbersToExpressions";
                Settings = {
                    Treshold         = 1;
                    InternalTreshold = 0.2;
                };
            },
            {
                Name = "JunkStatements";
                Settings = {
                    InjectionCount  = 4;
                    Treshold        = 0.85;
                    TableWriteRatio = 0.5;
                    ChainLength     = 3;
                    TableWriteCount = 3;
                };
            },
            {
                Name = "FakeLoopWrap";
                Settings = {
                    Treshold = 0.30;
                };
            },
            {
                Name     = "WrapInFunction";
                Settings = {};
            },
        };
    };

    -- =========================================================================
    -- Tier1 – Maximum-protection preset combining all Tier 1 upgrades.
    -- Pipeline order matters: VM compilation first, then crypto layers,
    -- then structural obfuscation, then control-flow noise at the end.
    -- =========================================================================
    ["Tier1"] = {
        LuaVersion    = "Lua51";
        VarNamePrefix = "";
        NameGenerator = "MangledShuffled";
        PrettyPrint   = false;
        Seed          = 0;
        Steps = {
            -- 1. VM compilation (produces unrecognisable bytecode format)
            { Name = "Vmify"; Settings = {}; },
            -- 2. Dynamic XOR encryption (per-call-site keys, VM-state dependent)
            {
                Name = "DynamicXOR";
                Settings = { Treshold = 1; };
            },
            -- 3. EncryptStrings (LCG + rolling XOR layer on top)
            { Name = "EncryptStrings"; Settings = {}; },
            -- 4. Anti-tamper hooks (debug hook + pcall integrity)
            { Name = "AntiTamper"; Settings = { UseDebug = false; }; },
            -- 5. Integrity hash self-check (FNV-1a constant checksum)
            {
                Name = "IntegrityHash";
                Settings = { SampleSize = 16; UseFakeExec = true; };
            },
            -- 6. Second VM pass (double-lifts the encrypted output)
            { Name = "Vmify"; Settings = {}; },
            -- 7. Constant array (base64, shuffled, rotated, local wrappers)
            {
                Name = "ConstantArray";
                Settings = {
                    Treshold             = 1;
                    StringsOnly          = true;
                    Shuffle              = true;
                    Rotate               = true;
                    LocalWrapperTreshold = 1;
                    LocalWrapperCount    = 3;
                    LocalWrapperArgCount = 12;
                };
            },
            -- 8. Number → expression splitting
            {
                Name = "NumbersToExpressions";
                Settings = { Treshold = 1; InternalTreshold = 0.3; };
            },
            -- 9. Opaque predicates (trig/number-theory always-true branches)
            {
                Name = "OpaquePredicates";
                Settings = { Treshold = 0.85; InjectionsPerBlock = 2; };
            },
            -- 10. Junk statement chains
            {
                Name = "JunkStatements";
                Settings = {
                    InjectionCount  = 5;
                    Treshold        = 0.9;
                    TableWriteRatio = 0.5;
                    ChainLength     = 4;
                    TableWriteCount = 3;
                };
            },
            -- 11. Anti-dump: GC manipulation + env proxy
            {
                Name = "AntiDump";
                Settings = { GCInterval = 50; UseEnvProxy = false; };
            },
            -- 12. Virtual globals (hides GetService / global call traces)
            {
                Name = "VirtualGlobals";
                Settings = { Treshold = 1; UseNumericKeys = true; };
            },
            -- 13. Fake loop wrappers (while true do ... break end noise)
            {
                Name = "FakeLoopWrap";
                Settings = { Treshold = 0.35; };
            },
            -- 14. Wrap entire output in anonymous function
            { Name = "WrapInFunction"; Settings = {}; },
        };
    };
}
