# Luminos Executor — Build Guide

## Project Structure

```
Luminos/
│
├── Zuki/                        ← Electron UI (the frontend)
│   ├── src/
│   │   ├── main/
│   │   │   ├── index.js         ← Main process + IPC handlers
│   │   │   ├── bridge.js        ← Named pipe client (talks to DLL)
│   │   │   └── injector.js      ← Launches injector.exe
│   │   ├── preload/
│   │   │   └── index.js         ← Exposes API to renderer
│   │   └── renderer/
│   │       └── src/App.jsx      ← UI (attach/execute wired up)
│   └── bin/                     ← PUT YOUR BUILT BINARIES HERE
│       ├── injector.exe
│       └── luminos.dll
│
├── injector/                    ← C++ manual map injector
│   ├── main.cpp
│   ├── CMakeLists.txt
│   └── build_injector.bat
│
└── dll/                         ← C++ DLL (runs inside Roblox)
    ├── dllmain.cpp
    ├── CMakeLists.txt
    └── build_dll.bat
```

---

## Build Order

### 1. Build the DLL

```bat
cd dll
build_dll.bat
```

Output: `dll\build_dll\Release\luminos.dll`

**Before this will actually execute scripts**, you need to open
Roblox in x64dbg or Ghidra and find the RVAs for:
- `luaL_loadstring`
- `lua_pcall`
- `lua_settop`

Then fill them in at `ResolveLuaFunctions()` in `dllmain.cpp`.
The scheduler hook pattern also needs updating per Roblox version.

### 2. Build the Injector

```bat
cd injector
build_injector.bat
```

Output: `injector\build_injector\Release\injector.exe`

### 3. Copy binaries to Electron bin folder

```
copy dll\build_dll\Release\luminos.dll     Zuki\bin\luminos.dll
copy injector\build_injector\Release\injector.exe  Zuki\bin\injector.exe
```

### 4. Run the Electron UI

```bat
cd Zuki
npm install
npm run dev
```

---

## How it works end-to-end

```
[Electron UI]
    |
    | click Attach
    v
[injector.js]  →  spawns injector.exe <roblox_pid> luminos.dll
                        |
                        | manual maps DLL into Roblox
                        v
                  [luminos.dll] (running inside Roblox)
                        |
                        | starts named pipe server
                        | hooks scheduler step function
                        v
[bridge.js]  ←──────── pipe: \\.\pipe\LuminosBridge ────────────►
    |
    | click Execute (sends Lua code through pipe)
    v
[luminos.dll task queue]  →  drained on Roblox scheduler thread
                          →  lua_pcall on Roblox's lua_State
                          →  result byte sent back through pipe
    |
    v
[Terminal log]  "Executed" or "Script errored"
```

---

## The hard part: finding offsets

Roblox statically links Luau so you can't use GetProcAddress.
You need a disassembler to find the RVAs.

**Recommended tools:**
- [x64dbg](https://x64dbg.com/) — attach to Roblox, search for patterns
- [Ghidra](https://ghidra-sre.org/) — static analysis, free

**What to look for in x64dbg:**
1. Attach to `RobloxPlayerBeta.exe`
2. Search → All Modules → String references → search `"attempt to call"`
   — this string is inside Luau's error handling, near `lua_pcall`
3. From there trace backwards to find `luaL_loadstring`

The lua_State pointer is typically found by:
1. Searching for the Luau task scheduler object
2. Following the pointer chain: `TaskScheduler → ScriptContext → lua_State`

---

## Notes

- Both binaries MUST be 64-bit (Roblox is x64)
- Run the Electron app as Administrator if injection fails with
  "OpenProcess failed" — Roblox may be running at higher integrity
- The DLL wipes its own PE headers after loading to avoid
  detection by module scanners
- Scripts are executed on Roblox's scheduler thread (not a foreign
  thread) to prevent the crash-after-few-seconds issue
