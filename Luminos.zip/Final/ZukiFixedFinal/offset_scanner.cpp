/*
 * Luminos — Offset Scanner
 *
 * Scans a running RobloxPlayerBeta.exe for all Luau function RVAs
 * and prints a ready-to-paste OFFSETS block for dllmain.cpp.
 *
 * Usage:
 *   offset_scanner.exe              (auto-finds Roblox PID)
 *   offset_scanner.exe <pid>        (use specific PID)
 *
 * Run as Administrator — requires PROCESS_VM_READ on Roblox.
 *
 * ── HOW PATTERNS WORK ────────────────────────────────────────────────────────
 * Each Luau function starts with a recognisable prologue.
 * We scan the .text section of RobloxPlayerBeta.exe for those bytes.
 * '?' in the mask means "any byte" (wildcard).
 *
 * If a pattern matches multiple locations we report all of them so you
 * can pick the right one in x64dbg.  If it matches exactly one, it's
 * almost certainly correct.
 *
 * ── UPDATING PATTERNS ────────────────────────────────────────────────────────
 * When Roblox updates and a pattern stops matching:
 *   1. Open x64dbg, attach to Roblox
 *   2. In the Symbols tab find the function by searching nearby strings
 *      or following known call chains
 *   3. Copy the first 10-14 bytes of the function prologue
 *   4. Replace the pattern below
 */

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <psapi.h>
#include <tlhelp32.h>
#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include <sstream>

#pragma comment(lib, "psapi.lib")

// ── Colour helpers ────────────────────────────────────────────────────────────
static HANDLE hCon = INVALID_HANDLE_VALUE;
static void setColor(WORD c) { if (hCon != INVALID_HANDLE_VALUE) SetConsoleTextAttribute(hCon, c); }
static void ok   (const std::string& s) { setColor(FOREGROUND_GREEN|FOREGROUND_INTENSITY);          std::cout << "  [+] " << s << "\n"; setColor(7); }
static void warn (const std::string& s) { setColor(FOREGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY); std::cout << "  [!] " << s << "\n"; setColor(7); }
static void info (const std::string& s) { setColor(FOREGROUND_BLUE|FOREGROUND_GREEN|FOREGROUND_INTENSITY); std::cout << "  [*] " << s << "\n"; setColor(7); }
static void fail (const std::string& s) { setColor(FOREGROUND_RED|FOREGROUND_INTENSITY);             std::cout << "  [-] " << s << "\n"; setColor(7); }
static void hdr  (const std::string& s) { setColor(FOREGROUND_RED|FOREGROUND_BLUE|FOREGROUND_INTENSITY); std::cout << "\n  " << s << "\n"; setColor(7); }

static std::string hex(uintptr_t v) {
    std::ostringstream ss;
    ss << "0x" << std::uppercase << std::hex << std::setfill('0') << std::setw(8) << v;
    return ss.str();
}

// ── Pattern definition ────────────────────────────────────────────────────────
struct SigEntry {
    const char* name;
    const char* bytes;   // raw bytes (use \x00 for zero bytes)
    const char* mask;    // 'x' = match, '?' = wildcard
    size_t      len;
    const char* note;    // hint for manual verification
};

// Patterns for Luau functions inside Roblox.
// These are based on common x64 MSVC-compiled Luau prologues.
// Format: first ~12 bytes of the function, wildcarding call targets and
// addresses that change per-build.
//
// Each entry may match 0, 1, or multiple locations.
// Exactly 1 match = almost certainly correct.
// 0 matches = pattern needs updating for this Roblox version.
// >1 matches = use x64dbg to pick the right one.

#define PAT(name, bytes, mask, note) \
    { name, bytes, mask, sizeof(bytes)-1, note }

static const SigEntry SIGNATURES[] = {

    // lua_newthread — allocates a new coroutine thread
    // 48 89 5C 24 08  mov [rsp+8], rbx
    // 48 89 74 24 10  mov [rsp+10], rsi
    // 57              push rdi
    // 48 83 EC 30     sub rsp, 30
    // 48 8B F9        mov rdi, rcx
    PAT("lua_newthread",
        "\x48\x89\x5C\x24\x08\x48\x89\x74\x24\x10\x57\x48\x83\xEC\x30\x48\x8B\xF9",
        "xxxxxxxxxxxxxxxxxx",
        "First alloc call after creates a new lstate"),

    // luaL_loadbuffer — compiles Lua source to bytecode
    // 48 89 5C 24 08  mov [rsp+8], rbx
    // 48 89 6C 24 10  mov [rsp+10], rbp
    // 48 89 74 24 18  mov [rsp+18], rsi
    // 57              push rdi
    // 41 56           push r14
    // 41 57           push r15
    // 48 83 EC 40     sub rsp, 40
    PAT("luaL_loadbuffer",
        "\x48\x89\x5C\x24\x08\x48\x89\x6C\x24\x10\x48\x89\x74\x24\x18\x57\x41\x56\x41\x57\x48\x83\xEC\x40",
        "xxxxxxxxxxxxxxxxxxxxxxxx",
        "Takes (L, buf, sz, chunkname) — look for string '@' pushed before call"),

    // lua_pcall — protected call
    // 48 83 EC 28     sub rsp, 28
    // 45 33 C0        xor r8d, r8d
    // 48 8B D1        mov rdx, rcx
    // ?? ?? ?? ??     call lua_pcallk or similar
    PAT("lua_pcall",
        "\x48\x83\xEC\x28\x45\x33\xC0\x48\x8B\xD1",
        "xxxxxxxxxx",
        "Short prologue, calls lua_pcallk internally"),

    // lua_settop
    // 48 63 41 ??     movsxd rax, dword ptr [rcx+??]  ; L->top
    // 85 D2           test edx, edx
    PAT("lua_settop",
        "\x48\x63\x41\x00\x85\xD2",
        "xxx?xx",
        "Sets stack top — look for negative index branch"),

    // lua_gettop
    // 48 8B 41 ??     mov rax, [rcx+??]   ; L->top
    // 48 2B 41 ??     sub rax, [rcx+??]   ; L->base
    // 48 C1 F8 03     sar rax, 3
    PAT("lua_gettop",
        "\x48\x8B\x41\x00\x48\x2B\x41\x00\x48\xC1\xF8\x03",
        "xxx?xxx?xxxx",
        "Returns (top - base) >> 3"),

    // lua_pushvalue
    // 48 63 C2        movsxd rax, edx
    // 48 8B 49 ??     mov rcx, [rcx+??]  ; L->top
    PAT("lua_pushvalue",
        "\x48\x63\xC2\x48\x8B\x49",
        "xxxxxx",
        "Simple index-to-address, copies TValue to top"),

    // lua_pushcclosure
    // 40 55           push rbp
    // 53              push rbx
    // 56              push rsi
    // 57              push rdi
    // 41 54           push r12
    PAT("lua_pushcclosure",
        "\x40\x55\x53\x56\x57\x41\x54",
        "xxxxxxx",
        "Creates CClosure, upvalue count in r8d"),

    // lua_pushboolean — very short function
    // 48 8B 41 ??     mov rax, [rcx+??]   ; L->top
    // C7 40 08 ??     mov [rax+8], ??     ; tt = LUA_TBOOLEAN
    PAT("lua_pushboolean",
        "\x48\x8B\x41\x00\xC7\x40\x08\x01\x00\x00\x00",
        "xxx?xxxxxxx",
        "Stores boolean tt+value then increments top"),

    // lua_pushinteger
    // 48 8B 41 ??     mov rax, [rcx+??]
    // 48 63 D2        movsxd rdx, edx
    PAT("lua_pushinteger",
        "\x48\x8B\x41\x00\x48\x63\xD2",
        "xxx?xxx",
        "Stores number as integer then increments top"),

    // lua_pushlstring
    // 48 89 5C 24 08  mov [rsp+8], rbx
    // 48 89 6C 24 10  mov [rsp+10], rbp
    // 48 89 74 24 18  mov [rsp+18], rsi
    // 57              push rdi
    // 48 83 EC 20     sub rsp, 20
    // 49 8B F0        mov rsi, r8
    PAT("lua_pushlstring",
        "\x48\x89\x5C\x24\x08\x48\x89\x6C\x24\x10\x48\x89\x74\x24\x18\x57\x48\x83\xEC\x20\x49\x8B\xF0",
        "xxxxxxxxxxxxxxxxxxxxxxx",
        "3rd arg is length (size_t)"),

    // lua_pushnil
    // 48 8B 41 ??     mov rax, [rcx+??]   ; L->top
    // C7 40 08 00     mov [rax+8], 0      ; tt = LUA_TNIL
    PAT("lua_pushnil",
        "\x48\x8B\x41\x00\xC7\x40\x08\x00\x00\x00\x00",
        "xxx?xxxxxxx",
        "Only sets type tag to 0, no value"),

    // lua_tolstring
    // 48 89 5C 24 ??  mov [rsp+?], rbx
    // 48 89 74 24 ??  mov [rsp+?], rsi
    // 57              push rdi
    // 48 83 EC 30     sub rsp, 30
    // 4C 8B C2        mov r8, rdx
    PAT("lua_tolstring",
        "\x48\x89\x5C\x24\x00\x48\x89\x74\x24\x00\x57\x48\x83\xEC\x30\x4C\x8B\xC2",
        "xxxx?xxxx?xxxxxxxx",
        "Returns const char*, optional length out-param"),

    // lua_toboolean — tiny
    // 48 63 C2        movsxd rax, edx
    // 48 8D 54 C1 ??  lea rdx, [rcx+rax*8+??]
    PAT("lua_toboolean",
        "\x48\x63\xC2\x48\x8D\x54\xC1",
        "xxxxxxx",
        "Returns 0 or 1, checks tt and value"),

    // lua_touserdata
    PAT("lua_touserdata",
        "\x48\x63\xC2\x48\x8B\x4C\xC1",
        "xxxxxxx",
        "Similar to toboolean prologue but returns pointer"),

    // lua_type
    // 48 63 C2        movsxd rax, edx
    // F7 C2 ??        test edx, ??
    PAT("lua_type",
        "\x48\x63\xC2\xF7\xC2",
        "xxxxx",
        "Returns LUA_T* constant, negative index handling"),

    // lua_setfield
    // 48 89 5C 24 08
    // 48 89 6C 24 10
    // 48 89 74 24 18
    // 57
    // 48 83 EC 40
    // 49 8B E8        mov rbp, r8
    PAT("lua_setfield",
        "\x48\x89\x5C\x24\x08\x48\x89\x6C\x24\x10\x48\x89\x74\x24\x18\x57\x48\x83\xEC\x40\x49\x8B\xE8",
        "xxxxxxxxxxxxxxxxxxxxxxx",
        "t[k] = v, triggers __newindex"),

    // lua_getfield
    // 48 89 5C 24 08
    // 48 89 6C 24 10
    // 48 89 74 24 18
    // 57
    // 48 83 EC 40
    // 4C 8B C2        mov r8, rdx   <-- differs from setfield here
    PAT("lua_getfield",
        "\x48\x89\x5C\x24\x08\x48\x89\x6C\x24\x10\x48\x89\x74\x24\x18\x57\x48\x83\xEC\x40\x4C\x8B\xC2",
        "xxxxxxxxxxxxxxxxxxxxxxx",
        "Pushes t[k], triggers __index"),

    // lua_rawget
    PAT("lua_rawget",
        "\x48\x89\x5C\x24\x08\x57\x48\x83\xEC\x20\x48\x8B\xD9\x48\x63\xFA",
        "xxxxxxxxxxxxxxxx",
        "No metamethods, direct table lookup"),

    // lua_rawset
    PAT("lua_rawset",
        "\x48\x89\x5C\x24\x08\x48\x89\x6C\x24\x10\x57\x48\x83\xEC\x20\x48\x8B\xD9\x48\x63\xEA",
        "xxxxxxxxxxxxxxxxxxx",
        "No metamethods, direct table write"),

    // lua_rawequal
    PAT("lua_rawequal",
        "\x48\x63\xC2\x4C\x63\xC9\x48\x8D\x54\xC1",
        "xxxxxxxxxx",
        "Returns 1 if rawly equal, no __eq"),

    // lua_createtable
    // 40 53           push rbx
    // 48 83 EC 20     sub rsp, 20
    // 41 8B D8        mov ebx, r8d
    PAT("lua_createtable",
        "\x40\x53\x48\x83\xEC\x20\x41\x8B\xD8",
        "xxxxxxxxx",
        "narr and nrec hints for pre-allocation"),

    // lua_setmetatable
    // 40 53
    // 48 83 EC 20
    // 48 8B D9        mov rbx, rcx
    // 48 63 CA        movsxd rcx, edx
    PAT("lua_setmetatable",
        "\x40\x53\x48\x83\xEC\x20\x48\x8B\xD9\x48\x63\xCA",
        "xxxxxxxxxxxx",
        "Respects __metatable protection unless identity >= 6"),

    // lua_getmetatable
    PAT("lua_getmetatable",
        "\x40\x53\x48\x83\xEC\x20\x48\x8B\xD9\x48\x63\xD2",
        "xxxxxxxxxxxx",
        "Returns 0 if no mt or mt has __metatable field"),

    // lua_getglobal — pushes _G[name]
    // 48 89 5C 24 08
    // 57
    // 48 83 EC 30
    // 48 8B FA        mov rdi, rdx
    PAT("lua_getglobal",
        "\x48\x89\x5C\x24\x08\x57\x48\x83\xEC\x30\x48\x8B\xFA",
        "xxxxxxxxxxxxx",
        "Internally calls lua_getfield(L, LUA_GLOBALSINDEX, name)"),

    // lua_setglobal
    PAT("lua_setglobal",
        "\x48\x89\x5C\x24\x08\x57\x48\x83\xEC\x30\x48\x8B\xDA",
        "xxxxxxxxxxxxx",
        "Internally calls lua_setfield(L, LUA_GLOBALSINDEX, name)"),

    // luaL_loadstring — wraps luaL_loadbuffer with strlen
    // 48 83 EC 28
    // 48 8B D2        mov rdx, rdx  (already there)
    // E8 ?? ?? ?? ??  call strlen
    PAT("luaL_loadstring",
        "\x48\x83\xEC\x28\x48\x8B\xD2\xE8",
        "xxxxxxxx",
        "Very short — just calls strlen then luaL_loadbuffer"),

    // luaL_ref
    PAT("luaL_ref",
        "\x40\x53\x48\x83\xEC\x20\x8B\xDA\x83\xFA\xFF",
        "xxxxxxxxxxx",
        "Stores value at integer key in registry table"),

    // luaL_unref
    PAT("luaL_unref",
        "\x83\xFA\xFF\x74\x00\x83\xFA\xFE\x74",
        "xxxx?xxxx",
        "Frees a registry ref"),

    // lua_rawgeti
    PAT("lua_rawgeti",
        "\x48\x89\x5C\x24\x08\x57\x48\x83\xEC\x20\x48\x8B\xD9\x48\x63\xFA\x48\x63\xCA",
        "xxxxxxxxxxxxxxxxxxx",
        "t[i] without metamethods, integer key"),

    // lua_next — table iteration
    // 40 53
    // 48 83 EC 20
    // 48 8B D9
    // 48 63 CA
    // E8 ?? ?? ?? ??   call luaH_next
    PAT("lua_next",
        "\x40\x53\x48\x83\xEC\x20\x48\x8B\xD9\x48\x63\xCA\xE8",
        "xxxxxxxxxxxxx",
        "Advances table iterator, returns 0 at end"),
};

static const size_t SIG_COUNT = sizeof(SIGNATURES) / sizeof(SIGNATURES[0]);

// ── Scanner ───────────────────────────────────────────────────────────────────

struct ScanResult {
    std::string   name;
    std::vector<uintptr_t> rvas;  // all matches (RVA from module base)
    const char*   note;
};

static bool matchPattern(const BYTE* mem, const SigEntry& s) {
    for (size_t i = 0; i < s.len; i++) {
        if (s.mask[i] == 'x' && mem[i] != (BYTE)s.bytes[i]) return false;
    }
    return true;
}

static std::vector<uintptr_t> scan(HANDLE hProc, uintptr_t base, size_t imageSize, const SigEntry& s) {
    std::vector<uintptr_t> hits;

    // Read the whole image in chunks to avoid single huge alloc
    const size_t CHUNK = 0x100000; // 1 MB
    std::vector<BYTE> buf(CHUNK + s.len);

    for (size_t offset = 0; offset < imageSize; offset += CHUNK) {
        size_t readSize = min(CHUNK, imageSize - offset);
        SIZE_T bytesRead = 0;
        if (!ReadProcessMemory(hProc, (LPCVOID)(base + offset), buf.data(), readSize + s.len, &bytesRead))
            continue;

        for (size_t i = 0; i + s.len <= bytesRead; i++) {
            if (matchPattern(buf.data() + i, s)) {
                hits.push_back(offset + i);
            }
        }
    }
    return hits;
}

// ── PID finder ────────────────────────────────────────────────────────────────

static DWORD findRobloxPid() {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return 0;
    PROCESSENTRY32 pe{ sizeof(pe) };
    DWORD pid = 0;
    if (Process32First(snap, &pe)) {
        do {
            if (_stricmp(pe.szExeFile, "RobloxPlayerBeta.exe") == 0) {
                pid = pe.th32ProcessID;
                break;
            }
        } while (Process32Next(snap, &pe));
    }
    CloseHandle(snap);
    return pid;
}

// ── Main ──────────────────────────────────────────────────────────────────────

int main(int argc, char* argv[]) {
    hCon = GetStdHandle(STD_OUTPUT_HANDLE);

    setColor(FOREGROUND_RED | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
    std::cout << "\n  ╔══════════════════════════════════════╗\n";
    std::cout <<   "  ║   Luminos Offset Scanner             ║\n";
    std::cout <<   "  ╚══════════════════════════════════════╝\n\n";
    setColor(7);

    // Get PID
    DWORD pid = 0;
    if (argc >= 2) {
        pid = static_cast<DWORD>(std::stoul(argv[1]));
        info("Using provided PID: " + std::to_string(pid));
    } else {
        info("Searching for RobloxPlayerBeta.exe...");
        pid = findRobloxPid();
    }

    if (!pid) {
        fail("Roblox not found. Open Roblox and get into a game first.");
        std::cin.get();
        return 1;
    }
    ok("Found Roblox PID: " + std::to_string(pid));

    // Open process
    HANDLE hProc = OpenProcess(PROCESS_VM_READ | PROCESS_QUERY_INFORMATION, FALSE, pid);
    if (!hProc) {
        fail("OpenProcess failed (error " + std::to_string(GetLastError()) + "). Run as Administrator.");
        std::cin.get();
        return 1;
    }
    ok("Opened process.");

    // Find RobloxPlayerBeta.exe module base + size
    HMODULE mods[512]{};
    DWORD needed = 0;
    EnumProcessModules(hProc, mods, sizeof(mods), &needed);

    uintptr_t robloxBase = 0;
    size_t    robloxSize = 0;
    char      modName[MAX_PATH]{};

    for (DWORD i = 0, n = needed / sizeof(HMODULE); i < n; i++) {
        GetModuleBaseNameA(hProc, mods[i], modName, sizeof(modName));
        if (_stricmp(modName, "RobloxPlayerBeta.exe") == 0) {
            MODULEINFO mi{};
            GetModuleInformation(hProc, mods[i], &mi, sizeof(mi));
            robloxBase = (uintptr_t)mi.lpBaseOfDll;
            robloxSize = mi.SizeOfImage;
            break;
        }
    }

    if (!robloxBase) {
        fail("Could not find RobloxPlayerBeta.exe module. Is Roblox fully loaded into a game?");
        CloseHandle(hProc);
        std::cin.get();
        return 1;
    }

    ok("Module base: " + hex(robloxBase) + "  size: " + hex((uintptr_t)robloxSize));
    std::cout << "\n";
    info("Scanning " + std::to_string(SIG_COUNT) + " patterns — this takes a few seconds...\n");

    // Scan all patterns
    std::vector<ScanResult> results;
    size_t found = 0, missing = 0, ambiguous = 0;

    for (size_t i = 0; i < SIG_COUNT; i++) {
        const auto& sig = SIGNATURES[i];
        auto rvas = scan(hProc, robloxBase, robloxSize, sig);

        ScanResult r;
        r.name = sig.name;
        r.rvas = rvas;
        r.note = sig.note;
        results.push_back(r);

        if (rvas.size() == 1) {
            ok(std::string(sig.name) + " -> " + hex(rvas[0]));
            found++;
        } else if (rvas.empty()) {
            warn(std::string(sig.name) + " -> NOT FOUND (pattern needs update)");
            missing++;
        } else {
            std::string s = std::string(sig.name) + " -> AMBIGUOUS (" + std::to_string(rvas.size()) + " matches):";
            for (auto rva : rvas) s += "  " + hex(rva);
            warn(s);
            ambiguous++;
        }
    }

    CloseHandle(hProc);

    // ── Summary ──────────────────────────────────────────────────────────────
    hdr("═══ SCAN COMPLETE ═══");
    ok("Found:     " + std::to_string(found));
    if (ambiguous) warn("Ambiguous: " + std::to_string(ambiguous) + " (pick the right one in x64dbg)");
    if (missing)   fail("Missing:   " + std::to_string(missing)   + " (patterns need updating)");

    // ── Output block ─────────────────────────────────────────────────────────
    hdr("═══ PASTE INTO dllmain.cpp (OFFSETS table) ═══");
    setColor(FOREGROUND_GREEN | FOREGROUND_INTENSITY);
    std::cout << "\nstatic const LuauOffsets OFFSETS = {\n";

    auto rvaFor = [&](const char* name) -> uintptr_t {
        for (auto& r : results)
            if (r.name == name && r.rvas.size() == 1)
                return r.rvas[0];
        return 0;
    };

    // Print in the same order as LuauOffsets struct in dllmain.cpp
    const char* ORDER[] = {
        "lua_newthread", "luaL_loadbuffer", "lua_pcall", "lua_settop", "lua_gettop",
        "lua_pushvalue", "lua_pushcclosure", "lua_pushboolean", "lua_pushinteger",
        "lua_pushlstring", "lua_pushnil", "lua_tolstring", "lua_toboolean",
        "lua_touserdata", "lua_type", "lua_setfield", "lua_getfield",
        "lua_rawget", "lua_rawset", "lua_rawequal", "lua_createtable",
        "lua_setmetatable", "lua_getmetatable", "lua_getglobal", "lua_setglobal",
        "luaL_loadstring", "luaL_ref", "luaL_unref", "lua_rawgeti", "lua_next",
    };

    for (const char* name : ORDER) {
        uintptr_t rva = rvaFor(name);
        std::cout << "    " << hex(rva) << ",  // " << name;
        if (rva == 0) std::cout << "  <-- NOT FOUND";
        // Find ambiguous note
        for (auto& r : results)
            if (r.name == name && r.rvas.size() > 1)
                std::cout << "  <-- AMBIGUOUS, options:";
        for (auto& r : results)
            if (r.name == name)
                for (size_t j = 1; j < r.rvas.size(); j++)
                    std::cout << " " << hex(r.rvas[j]);
        std::cout << "\n";
    }
    std::cout << "};\n";
    setColor(7);

    // ── Verification tips for any ambiguous/missing ───────────────────────────
    bool needsManual = false;
    for (auto& r : results) if (r.rvas.size() != 1) needsManual = true;

    if (needsManual) {
        hdr("═══ MANUAL VERIFICATION NEEDED ═══");
        for (auto& r : results) {
            if (r.rvas.empty()) {
                fail(r.name + " not found. Hint: " + r.note);
            } else if (r.rvas.size() > 1) {
                warn(r.name + " ambiguous. Hint: " + r.note);
                for (auto rva : r.rvas)
                    std::cout << "      " << hex(rva) << "  (abs: " << hex(robloxBase + rva) << ")\n";
            }
        }
    }

    std::cout << "\n  Press Enter to exit...\n";
    std::cin.get();
    return 0;
}
