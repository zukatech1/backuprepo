@echo off
REM ── Luminos Builder ───────────────────────────────────────────────────────────
setlocal

set BUILD_TYPE=%1
if "%BUILD_TYPE%"=="" set BUILD_TYPE=Release
set BUILD_DIR=build
set BIN_DIR=bin

echo.
echo   Luminos Builder
echo   Build type: %BUILD_TYPE%
echo.

where cmake >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo   [ERROR] cmake not found. Install Visual Studio with the C++ workload.
    exit /b 1
)

cmake -S . -B %BUILD_DIR% -A x64 -DCMAKE_BUILD_TYPE=%BUILD_TYPE%
if %ERRORLEVEL% NEQ 0 ( echo   [ERROR] CMake configure failed. & exit /b 1 )

cmake --build %BUILD_DIR% --config %BUILD_TYPE%
if %ERRORLEVEL% NEQ 0 ( echo   [ERROR] Build failed. & exit /b 1 )

REM Stage all three outputs to bin\
if not exist %BIN_DIR% mkdir %BIN_DIR%
copy /Y "%BUILD_DIR%\%BUILD_TYPE%\luminos.dll"         "%BIN_DIR%\luminos.dll"         >nul
copy /Y "%BUILD_DIR%\%BUILD_TYPE%\injector.exe"        "%BIN_DIR%\injector.exe"        >nul
copy /Y "%BUILD_DIR%\%BUILD_TYPE%\offset_scanner.exe"  "%BIN_DIR%\offset_scanner.exe"  >nul

echo.
echo   Done!
echo   bin\luminos.dll          ^<-- inject payload
echo   bin\injector.exe         ^<-- manual map injector
echo   bin\offset_scanner.exe   ^<-- run this to find offsets
echo.
echo   NEXT STEPS:
echo     1. Open Roblox and get into a game
echo     2. Run bin\offset_scanner.exe as Administrator
echo     3. Paste the output into dllmain.cpp OFFSETS table
echo     4. Re-run build.bat
echo     5. npm install ^&^& npm run dev
echo.
