import { contextBridge, ipcRenderer } from 'electron'
import { electronAPI } from '@electron-toolkit/preload'

const api = {
  minimize:     () => ipcRenderer.send('minimize-window'),
  maximize:     () => ipcRenderer.send('maximize-window'),
  close:        () => ipcRenderer.send('close-window'),
  setTopMost:   (isTop) => ipcRenderer.send('set-top-most', isTop),
  openFile:     () => ipcRenderer.invoke('dialog:openFile'),
  fetchScripts: (mode, query, page) => ipcRenderer.invoke('api:fetchScripts', { mode, query, page }),

  // Executor
  attach:   ()     => ipcRenderer.invoke('executor:attach'),
  detach:   ()     => ipcRenderer.invoke('executor:detach'),
  execute:  (code) => ipcRenderer.invoke('executor:execute', code),
}

if (process.contextIsolated) {
  try {
    contextBridge.exposeInMainWorld('electron', electronAPI)
    contextBridge.exposeInMainWorld('api', api)
  } catch (error) {
    console.error(error)
  }
} else {
  window.electron = electronAPI
  window.api = api
}
