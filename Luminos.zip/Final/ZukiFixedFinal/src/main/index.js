import { app, shell, BrowserWindow, ipcMain, dialog } from 'electron'
import { join } from 'path'
import { electronApp, optimizer, is } from '@electron-toolkit/utils'
import icon from '../../resources/icon.png?asset'
import fs from 'fs'
import path from 'path'
import { exec, execFile } from 'child_process'
import { createRequire } from 'module'

const require2 = createRequire(import.meta.url)
const bridge = require2('../../bridge.js')

// In dev, electron-vite sets app.getAppPath() to out/main, so ../../ = project root
// In prod, resourcesPath is next to the exe
const PROJECT_ROOT = is.dev
  ? join(app.getAppPath(), '../..')
  : process.resourcesPath

const BIN_DIR = join(PROJECT_ROOT, 'bin')

function getRobloxPid() {
  return new Promise((resolve) => {
    exec('tasklist /FI "IMAGENAME eq RobloxPlayerBeta.exe" /FO CSV /NH', (err, stdout) => {
      if (err || !stdout) return resolve(null)
      const match = stdout.match(/"RobloxPlayerBeta\.exe","(\d+)"/)
      resolve(match ? parseInt(match[1]) : null)
    })
  })
}

function createWindow() {
  const mainWindow = new BrowserWindow({
    width: 950,
    height: 650,
    minWidth: 600,
    minHeight: 400,
    show: false,
    frame: false,
    autoHideMenuBar: true,
    transparent: false,
    backgroundColor: '#09090b',
    resizable: true,
    ...(process.platform === 'linux' ? { icon } : {}),
    webPreferences: {
      preload: join(__dirname, '../preload/index.js'),
      sandbox: false,
      webSecurity: false
    }
  })

  mainWindow.webContents.session.webRequest.onHeadersReceived((details, callback) => {
    callback({
      responseHeaders: {
        ...details.responseHeaders,
        'Content-Security-Policy': ["default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https: http:; font-src 'self' data:; connect-src 'self' https: http:;"]
      }
    })
  })

  mainWindow.on('ready-to-show', () => mainWindow.show())

  mainWindow.webContents.setWindowOpenHandler((details) => {
    shell.openExternal(details.url)
    return { action: 'deny' }
  })

  if (is.dev && process.env['ELECTRON_RENDERER_URL']) {
    mainWindow.loadURL(process.env['ELECTRON_RENDERER_URL'])
  } else {
    mainWindow.loadFile(join(__dirname, '../renderer/index.html'))
  }

  ipcMain.on('minimize-window', () => mainWindow.minimize())
  ipcMain.on('maximize-window', () => {
    if (mainWindow.isMaximized()) mainWindow.unmaximize()
    else mainWindow.maximize()
  })
  ipcMain.on('close-window', () => mainWindow.close())
  ipcMain.on('set-top-most', (_, isTop) => { mainWindow.setAlwaysOnTop(isTop) })
}

// --- ATTACH ---
ipcMain.handle('executor:attach', async () => {
  try {
    // 1. Find Roblox
    const pid = await getRobloxPid()
    if (!pid) return { ok: false, msg: 'Roblox not found — make sure you are in a game.' }

    // 2. Check bin files exist
    const injectorPath = join(BIN_DIR, 'injector.exe')
    const dllPath = join(BIN_DIR, 'luminos.dll')
    if (!fs.existsSync(injectorPath)) return { ok: false, msg: `injector.exe not found. Expected: ${injectorPath}` }
    if (!fs.existsSync(dllPath))      return { ok: false, msg: `luminos.dll not found. Expected: ${dllPath}` }

    // 3. Run injector
    const injectorOutput = await new Promise((resolve, reject) => {
      execFile(injectorPath, [String(pid), dllPath], { timeout: 15000 }, (err, stdout, stderr) => {
        if (err) reject(new Error(`Injector failed: ${stderr || stdout || err.message}`))
        else resolve(stdout)
      })
    })

    console.log('[attach] injector output:', injectorOutput)

    // 4. Wait for DLL pipe server to come up
    await new Promise(r => setTimeout(r, 3500))

    // 5. Connect to pipe
    await bridge.connect()
    return { ok: true, msg: `Attached to PID ${pid}` }

  } catch (e) {
    console.error('[attach] error:', e)
    return { ok: false, msg: e.message }
  }
})

// --- DETACH ---
ipcMain.handle('executor:detach', async () => {
  try { bridge.disconnect() } catch {}
  return { ok: true }
})

// --- EXECUTE ---
ipcMain.handle('executor:execute', async (_, code) => {
  if (!bridge.isConnected()) return { ok: false, msg: 'Not attached.' }
  try {
    const result = await bridge.execute(code)
    return { ok: result.success, msg: result.message || '' }
  } catch (e) {
    return { ok: false, msg: e.message }
  }
})

// --- FILE OPEN ---
ipcMain.handle('dialog:openFile', async () => {
  const { canceled, filePaths } = await dialog.showOpenDialog({
    properties: ['openFile'],
    filters: [{ name: 'Scripts', extensions: ['lua', 'txt', 'json', 'md'] }, { name: 'All Files', extensions: ['*'] }]
  })
  if (canceled) return null
  const content = fs.readFileSync(filePaths[0], 'utf-8')
  return { name: path.basename(filePaths[0]), content, path: filePaths[0] }
})

// --- SCRIPT HUB ---
ipcMain.handle('api:fetchScripts', async (_, { mode, query, page }) => {
  try {
    let url = `https://scriptblox.com/api/script/${mode}?page=${page}`
    if (mode === 'search') url = `https://scriptblox.com/api/script/search?q=${encodeURIComponent(query)}&page=${page}`
    const response = await fetch(url, {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36' }
    })
    if (!response.ok) return { scripts: [], totalPages: 1 }
    const data = await response.json()
    if (data.result && data.result.scripts) {
      return { scripts: data.result.scripts, totalPages: data.result.totalPages || 1 }
    }
    return { scripts: [], totalPages: 1 }
  } catch {
    return { scripts: [], totalPages: 1 }
  }
})

app.whenReady().then(() => {
  electronApp.setAppUserModelId('com.electron')
  app.on('browser-window-created', (_, window) => { optimizer.watchWindowShortcuts(window) })
  createWindow()
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow() })
})

app.on('window-all-closed', () => {
  try { bridge.disconnect() } catch {}
  if (process.platform !== 'darwin') app.quit()
})
