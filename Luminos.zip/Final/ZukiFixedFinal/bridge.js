/**
 * Luminos — DLL Bridge (bridge.js)
 * 
 * Handles all communication between Electron and the injected DLL
 * via the named pipe \\.\pipe\LuminosBridge
 * 
 * Usage:
 *   const bridge = require('./bridge')
 *   await bridge.connect()
 *   const ok = await bridge.execute('print("hello")')
 *   bridge.disconnect()
 */

'use strict'

const net  = require('net')
const path = require('path')

const PIPE_NAME    = '\\\\.\\pipe\\LuminosBridge'
const CONNECT_TIMEOUT = 5000   // ms to wait for pipe connection
const EXECUTE_TIMEOUT = 12000  // ms to wait for script execution result

// ── State ─────────────────────────────────────────────────────────────────────

/** @type {net.Socket|null} */
let socket         = null
let connected      = false
let pendingResolve = null   // resolves when we get a response byte back
let pendingReject  = null
let pendingTimer   = null

// ── Helpers ───────────────────────────────────────────────────────────────────

function clearPending(reason) {
  if (pendingTimer)   { clearTimeout(pendingTimer); pendingTimer = null }
  if (pendingReject)  { pendingReject(new Error(reason)); pendingReject = null }
  pendingResolve = null
}

// ── Connect ───────────────────────────────────────────────────────────────────

/**
 * Attempt to connect to the DLL pipe.
 * Resolves true on success, rejects on timeout/error.
 */
function connect() {
  return new Promise((resolve, reject) => {
    if (connected && socket) { resolve(true); return }

    const timeoutHandle = setTimeout(() => {
      if (socket) socket.destroy()
      reject(new Error('Pipe connection timed out — is the DLL injected?'))
    }, CONNECT_TIMEOUT)

    socket = net.connect(PIPE_NAME)

    socket.once('connect', () => {
      clearTimeout(timeoutHandle)
      connected = true
      resolve(true)
    })

    socket.once('error', (err) => {
      clearTimeout(timeoutHandle)
      connected = false
      socket = null
      reject(new Error(`Pipe error: ${err.message}`))
    })

    socket.on('close', () => {
      connected = false
      socket    = null
      clearPending('Pipe closed unexpectedly')
    })

    socket.on('data', (data) => {
      // DLL response format:
      //   [0]      1 byte  — 0x01 success, 0x00 failure
      //   [1..4]   4 bytes — message length (little-endian uint32)
      //   [5..N]   N bytes — error message string (empty on success)
      if (!pendingResolve) return
      const success = data[0] === 1
      let message   = ''
      if (data.length >= 5) {
        const msgLen = data.readUInt32LE(1)
        if (msgLen > 0 && data.length >= 5 + msgLen)
          message = data.slice(5, 5 + msgLen).toString('utf8')
      }
      // Capture and clear pending state atomically before resolving
      const resolveFn = pendingResolve
      if (pendingTimer) { clearTimeout(pendingTimer); pendingTimer = null }
      pendingResolve = null
      pendingReject  = null
      resolveFn({ success, message })
    })
  })
}

// ── Disconnect ────────────────────────────────────────────────────────────────

function disconnect() {
  clearPending('Disconnected')
  if (socket) {
    socket.destroy()
    socket    = null
    connected = false
  }
}

// ── Execute ───────────────────────────────────────────────────────────────────

/**
 * Send a Lua script to the DLL for execution.
 * Returns a Promise<{success: boolean, message: string}>
 */
function execute(luaCode) {
  return new Promise((resolve, reject) => {
    if (!connected || !socket) {
      reject(new Error('Not connected — attach first'))
      return
    }

    if (pendingResolve) {
      reject(new Error('Another script is already executing'))
      return
    }

    pendingResolve = resolve
    pendingReject  = reject
    pendingTimer   = setTimeout(() => {
      pendingResolve = null
      pendingReject  = null
      pendingTimer   = null
      reject(new Error('Script execution timed out (12s)'))
    }, EXECUTE_TIMEOUT)

    const buf = Buffer.from(luaCode, 'utf8')
    socket.write(buf, (err) => {
      if (err) {
        clearPending('Write failed')
        pendingReject  = null
        reject(new Error(`Failed to send script: ${err.message}`))
      }
    })
  })
}

// ── Status ────────────────────────────────────────────────────────────────────

function isConnected() {
  return connected && socket !== null
}

// ── Exports ───────────────────────────────────────────────────────────────────

module.exports = { connect, disconnect, execute, isConnected }
