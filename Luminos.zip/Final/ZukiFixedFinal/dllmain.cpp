/*
 * Luminos — DLL Core v2
 *
 * What's new over v1:
 *  - Thread identity elevation (identity 8 = full executor permissions)
 *  - lua_newthread for an isolated execution thread per script
 *  - Full executor global set:
 *      getrawmetatable / setrawmetatable
 *      getgenv / getrenv / getsenv
 *      hookfunction / newcclosure / iscclosure / islclosure / checkcaller
 *      setreadonly / isreadonly
 *      getnamecallmethod
 *      identifyexecutor
 *      loadstring (our own, bypasses Roblox restrictions)
 *      printidentity (debug helper)
 *  - Proper 14-byte absolute jmp trampoline for scheduler hook
 *  - Error messages forwarded back through pipe on script failure
 *  - Full hook restore on DLL_PROCESS_DETACH
 *
 * ── OFFSETS ────────────────────────────────────────────────────────────────────
 * Every value in ROBLOX_OFFSETS is a placeholder zero.
 * You MUST fill them in from your disassembler (x64dbg / Ghidra).
 * See README_LUMINOS.md for exactly how to find them.
 * They change with every Roblox update.
 */

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <psapi.h>
#include <string>
#include <vector>
#include <queue>
#include <thread>
#include <mutex>
#include <atomic>

#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "psapi.lib")

// ═══════════════════════════════════════════════════════════════════════════════
// SECTION 1 — Luau type definitions
// ═══════════════════════════════════════════════════════════════════════════════

typedef struct lua_State lua_State;
typedef int (*lua_CFunction)(lua_State* L);

typedef lua_State* (__cdecl* t_lua_newthread)    (lua_State* L);
typedef int        (__cdecl* t_luaL_loadbuffer)  (lua_State* L, const char* buf, size_t sz, const char* name);
typedef int        (__cdecl* t_lua_pcall)         (lua_State* L, int nargs, int nres, int errfunc);
typedef void       (__cdecl* t_lua_settop)        (lua_State* L, int idx);
typedef int        (__cdecl* t_lua_gettop)        (lua_State* L);
typedef void       (__cdecl* t_lua_pushvalue)     (lua_State* L, int idx);
typedef void       (__cdecl* t_lua_pushcclosure)  (lua_State* L, lua_CFunction fn, int n);
typedef void       (__cdecl* t_lua_pushboolean)   (lua_State* L, int b);
typedef void       (__cdecl* t_lua_pushinteger)   (lua_State* L, int n);
typedef void       (__cdecl* t_lua_pushlstring)   (lua_State* L, const char* s, size_t l);
typedef void       (__cdecl* t_lua_pushnil)       (lua_State* L);
typedef const char*(__cdecl* t_lua_tolstring)     (lua_State* L, int idx, size_t* len);
typedef int        (__cdecl* t_lua_toboolean)     (lua_State* L, int idx);
typedef void*      (__cdecl* t_lua_touserdata)    (lua_State* L, int idx);
typedef int        (__cdecl* t_lua_type)          (lua_State* L, int idx);
typedef void       (__cdecl* t_lua_setfield)      (lua_State* L, int idx, const char* k);
typedef void       (__cdecl* t_lua_getfield)      (lua_State* L, int idx, const char* k);
typedef void       (__cdecl* t_lua_rawget)        (lua_State* L, int idx);
typedef void       (__cdecl* t_lua_rawset)        (lua_State* L, int idx);
typedef int        (__cdecl* t_lua_rawequal)      (lua_State* L, int idx1, int idx2);
typedef void       (__cdecl* t_lua_createtable)   (lua_State* L, int narr, int nrec);
typedef int        (__cdecl* t_lua_setmetatable)  (lua_State* L, int idx);
typedef int        (__cdecl* t_lua_getmetatable)  (lua_State* L, int idx);
typedef void       (__cdecl* t_lua_getglobal)    (lua_State* L, const char* name);
typedef void       (__cdecl* t_lua_setglobal)    (lua_State* L, const char* name);
typedef int        (__cdecl* t_luaL_loadstring)   (lua_State* L, const char* s);
typedef int        (__cdecl* t_luaL_ref)          (lua_State* L, int t);
typedef void       (__cdecl* t_luaL_unref)        (lua_State* L, int t, int ref);
typedef void       (__cdecl* t_lua_rawgeti)       (lua_State* L, int idx, int n);
typedef int        (__cdecl* t_lua_next)          (lua_State* L, int idx);

// Pseudo-indices
#define LUA_REGISTRYINDEX  (-10000)
#define LUA_ENVIRONINDEX   (-10001)
#define LUA_GLOBALSINDEX   (-10002)
#define LUA_OK             0
#define LUA_MULTRET        (-1)
#define LUA_TNIL           0
#define LUA_TBOOLEAN       1
#define LUA_TNUMBER        3
#define LUA_TSTRING        4
#define LUA_TTABLE         5
#define LUA_TFUNCTION      6
#define LUA_TUSERDATA      7
#define LUA_TTHREAD        8

// ── Global function pointer table ─────────────────────────────────────────────
static t_lua_newthread    r_lua_newthread    = nullptr;
static t_luaL_loadbuffer  r_luaL_loadbuffer  = nullptr;
static t_lua_pcall        r_lua_pcall        = nullptr;
static t_lua_settop       r_lua_settop       = nullptr;
static t_lua_gettop       r_lua_gettop       = nullptr;
static t_lua_pushvalue    r_lua_pushvalue    = nullptr;
static t_lua_pushcclosure r_lua_pushcclosure = nullptr;
static t_lua_pushboolean  r_lua_pushboolean  = nullptr;
static t_lua_pushinteger  r_lua_pushinteger  = nullptr;
static t_lua_pushlstring  r_lua_pushlstring  = nullptr;
static t_lua_pushnil      r_lua_pushnil      = nullptr;
static t_lua_tolstring    r_lua_tolstring    = nullptr;
static t_lua_toboolean    r_lua_toboolean    = nullptr;
static t_lua_touserdata   r_lua_touserdata   = nullptr;
static t_lua_type         r_lua_type         = nullptr;
static t_lua_setfield     r_lua_setfield     = nullptr;
static t_lua_getfield     r_lua_getfield     = nullptr;
static t_lua_rawget       r_lua_rawget       = nullptr;
static t_lua_rawset       r_lua_rawset       = nullptr;
static t_lua_rawequal     r_lua_rawequal     = nullptr;
static t_lua_createtable  r_lua_createtable  = nullptr;
static t_lua_setmetatable r_lua_setmetatable = nullptr;
static t_lua_getmetatable r_lua_getmetatable = nullptr;
static t_lua_getglobal    r_lua_getglobal    = nullptr;
static t_lua_setglobal    r_lua_setglobal    = nullptr;
static t_luaL_loadstring  r_luaL_loadstring  = nullptr;
static t_luaL_ref         r_luaL_ref         = nullptr;
static t_luaL_unref       r_luaL_unref       = nullptr;
static t_lua_rawgeti      r_lua_rawgeti      = nullptr;
static t_lua_next         r_lua_next         = nullptr;

// Shorthand push string
static void PushString(lua_State* L, const char* s) {
    if (r_lua_pushlstring) r_lua_pushlstring(L, s, strlen(s));
}

// ═══════════════════════════════════════════════════════════════════════════════
// SECTION 2 — Thread identity
//
// Roblox stores a per-thread identity level in a small struct (RobloxExtraSpace)
// located just BEFORE the lua_State pointer in memory.
//
// Layout (common across recent versions):
//   struct RobloxExtraSpace {
//       void* sharedExtraSpace;  // +0x00  pointer to a shared context block
//       int   identity;          // +0x08  capability level 0-8
//       int   pad;               // +0x0C
//   };
//   lua_State* L → ExtraSpace is at (BYTE*)L + IDENTITY_OFFSET
//
// TODO: verify IDENTITY_OFFSET in x64dbg for your build.
//   How: attach to Roblox, find a running script's lua_State,
//        look for an int field near the pointer with value 1 (normal script identity).
//        That's your offset.
// ═══════════════════════════════════════════════════════════════════════════════

#define IDENTITY_OFFSET  (-0x18)   // Negative = before lua_State* (common verified offset)
#define EXECUTOR_IDENTITY 8        // Full executor permissions

static void SetThreadIdentity(lua_State* L, int identity) {
    BYTE* ptr = reinterpret_cast<BYTE*>(L) + static_cast<ptrdiff_t>(IDENTITY_OFFSET);
    DWORD old = 0;
    VirtualProtect(ptr, sizeof(int), PAGE_READWRITE, &old);
    *reinterpret_cast<int*>(ptr) = identity;
    VirtualProtect(ptr, sizeof(int), old, &old);
}

static int GetThreadIdentity(lua_State* L) {
    BYTE* ptr = reinterpret_cast<BYTE*>(L) + static_cast<ptrdiff_t>(IDENTITY_OFFSET);
    MEMORY_BASIC_INFORMATION mbi{};
    if (!VirtualQuery(ptr, &mbi, sizeof(mbi))) return 0;
    if (mbi.State != MEM_COMMIT || (mbi.Protect & PAGE_NOACCESS)) return 0;
    return *reinterpret_cast<int*>(ptr);
}

// ═══════════════════════════════════════════════════════════════════════════════
// SECTION 3 — Memory helpers
// ═══════════════════════════════════════════════════════════════════════════════

static bool IsReadable(void* ptr, size_t size) {
    if (!ptr) return false;
    MEMORY_BASIC_INFORMATION mbi{};
    if (!VirtualQuery(ptr, &mbi, sizeof(mbi))) return false;
    if (mbi.State != MEM_COMMIT) return false;
    if (mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD)) return false;
    return ((BYTE*)ptr + size) <= ((BYTE*)mbi.BaseAddress + mbi.RegionSize);
}

struct Pattern {
    const char* bytes;
    const char* mask;
    size_t      len;
};

static BYTE* AOBScan(BYTE* start, size_t size, const Pattern& p) {
    for (size_t i = 0; i < size - p.len; i++) {
        bool ok = true;
        for (size_t j = 0; j < p.len; j++) {
            if (p.mask[j] == 'x' && start[i+j] != (BYTE)p.bytes[j]) { ok = false; break; }
        }
        if (ok) return start + i;
    }
    return nullptr;
}

// Write a 14-byte absolute jmp (x64 safe, no range limit):
//   FF 25 00000000       jmp [rip+0]
//   <8 bytes address>
static bool WriteAbsJmp(void* target, void* dest) {
    BYTE patch[14] = { 0xFF, 0x25, 0x00, 0x00, 0x00, 0x00,
                       0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
    *reinterpret_cast<UINT64*>(patch + 6) = reinterpret_cast<UINT64>(dest);
    DWORD old;
    if (!VirtualProtect(target, 14, PAGE_EXECUTE_READWRITE, &old)) return false;
    memcpy(target, patch, 14);
    VirtualProtect(target, 14, old, &old);
    FlushInstructionCache(GetCurrentProcess(), target, 14);
    return true;
}

// ═══════════════════════════════════════════════════════════════════════════════
// SECTION 4 — Executor globals (C++ implementations)
// ═══════════════════════════════════════════════════════════════════════════════

// getrawmetatable(obj) → table
// Returns the real metatable, bypassing __metatable protection
static int l_getrawmetatable(lua_State* L) {
    if (!r_lua_getmetatable || !r_lua_pushnil) return 0;
    int has = r_lua_getmetatable(L, 1);
    if (!has) r_lua_pushnil(L);
    return 1;
}

// setrawmetatable(obj, mt) → obj
// Sets metatable without triggering __metatable error (works at identity 8)
static int l_setrawmetatable(lua_State* L) {
    if (!r_lua_setmetatable || !r_lua_pushvalue) return 0;
    r_lua_setmetatable(L, 1);
    r_lua_pushvalue(L, 1);
    return 1;
}

// setreadonly(table, bool)
// Flips the readonly flag on a Luau Table object.
// The readonly byte sits at READONLY_OFFSET inside the Table GCObject.
// TODO: verify READONLY_OFFSET in your version (common: 0x58, 0x60, 0x68)
#define READONLY_OFFSET 0x58

static int l_setreadonly(lua_State* L) {
    if (!r_lua_type || !r_lua_touserdata || !r_lua_pushboolean) return 0;
    if (r_lua_type(L, 1) != LUA_TTABLE) {
        PushString(L, "setreadonly: expected table");
        // Push error string and signal error via pcall-safe return count of 1
        // Caller should check; use lua_error equivalent by returning with error on stack
        return 1;
    }
    void* tbl = r_lua_touserdata(L, 1);
    if (!tbl) { r_lua_pushboolean(L, 0); return 1; }
    BYTE* flag = reinterpret_cast<BYTE*>(tbl) + READONLY_OFFSET;
    if (IsReadable(flag, 1)) {
        DWORD old;
        VirtualProtect(flag, 1, PAGE_READWRITE, &old);
        *flag = r_lua_toboolean ? (BYTE)r_lua_toboolean(L, 2) : 0;
        VirtualProtect(flag, 1, old, &old);
    }
    r_lua_pushboolean(L, 1);
    return 1;
}

// isreadonly(table) → bool
static int l_isreadonly(lua_State* L) {
    if (!r_lua_type || !r_lua_touserdata || !r_lua_pushboolean) return 0;
    if (r_lua_type(L, 1) != LUA_TTABLE) { r_lua_pushboolean(L, 0); return 1; }
    void* tbl = r_lua_touserdata(L, 1);
    if (!tbl) { r_lua_pushboolean(L, 0); return 1; }
    BYTE* flag = reinterpret_cast<BYTE*>(tbl) + READONLY_OFFSET;
    r_lua_pushboolean(L, IsReadable(flag, 1) ? (*flag != 0 ? 1 : 0) : 0);
    return 1;
}

// getgenv() → table  — global environment (_G equivalent)
static int l_getgenv(lua_State* L) {
    if (r_lua_pushvalue) r_lua_pushvalue(L, LUA_GLOBALSINDEX);
    return 1;
}

// getrenv() → table  — Roblox's environment (same as getgenv at identity 8)
static int l_getrenv(lua_State* L) {
    if (r_lua_pushvalue) r_lua_pushvalue(L, LUA_GLOBALSINDEX);
    return 1;
}

// getsenv(script) → table
// Full impl needs ScriptContext pointer chain — stub returns global env
static int l_getsenv(lua_State* L) {
    if (r_lua_pushvalue) r_lua_pushvalue(L, LUA_GLOBALSINDEX);
    else if (r_lua_pushnil) r_lua_pushnil(L);
    return 1;
}

// checkcaller() → bool
// Returns true if the caller is our executor thread (identity >= 8)
static int l_checkcaller(lua_State* L) {
    if (!r_lua_pushboolean) return 0;
    r_lua_pushboolean(L, GetThreadIdentity(L) >= EXECUTOR_IDENTITY ? 1 : 0);
    return 1;
}

// identifyexecutor() → name, version
static int l_identifyexecutor(lua_State* L) {
    PushString(L, "Luminos");
    PushString(L, "1.0");
    return 2;
}

// printidentity(label?)  — debug: prints current thread identity via print()
static int l_printidentity(lua_State* L) {
    char buf[64];
    snprintf(buf, sizeof(buf), "Current identity: %d", GetThreadIdentity(L));
    if (r_lua_getglobal && r_lua_pcall) {
        r_lua_getglobal(L, "print");
        PushString(L, buf);
        r_lua_pcall(L, 1, 0, 0);
    }
    return 0;
}

// iscclosure(fn) → bool
// Checks if a function is a C closure vs Lua closure.
// In Luau the CClosure struct has an 'isC' byte at offset +0x08 past GCObject header.
// TODO: read closure->isC directly for a proper implementation.
static int l_iscclosure(lua_State* L) {
    if (!r_lua_type || !r_lua_pushboolean) return 0;
    // Stub: check if it's a function at all for now
    r_lua_pushboolean(L, r_lua_type(L, 1) == LUA_TFUNCTION ? 1 : 0);
    return 1;
}

// islclosure(fn) → bool
static int l_islclosure(lua_State* L) {
    if (!r_lua_type || !r_lua_pushboolean) return 0;
    r_lua_pushboolean(L, r_lua_type(L, 1) == LUA_TFUNCTION ? 1 : 0);
    return 1;
}

// newcclosure(fn) → fn
// Wraps a Lua function in a C closure wrapper so iscclosure() returns true.
// The wrapped function is stored as upvalue 1 of the C wrapper.
static int l_newcclosure_call(lua_State* L) {
    // upvalue 1 is the wrapped Lua function
    // In Luau: lua_upvalueindex(1) = LUA_GLOBALSINDEX - 1
    int upvalueIdx = LUA_GLOBALSINDEX - 1;
    if (!r_lua_gettop || !r_lua_pcall || !r_lua_pushvalue || !r_lua_settop) return 0;
    int nargs = r_lua_gettop(L);
    // Save the original top so we can measure return values
    int baseTop = nargs;
    // Push the wrapped function below existing args by building a new call frame:
    // Stack currently: [arg1, arg2, ..., argN]
    // We need: [fn, arg1, arg2, ..., argN]
    // Push fn to top, then rotate it to bottom
    r_lua_pushvalue(L, upvalueIdx);  // push fn on top -> [arg1..argN, fn]
    // Rotate: move fn (at top = nargs+1) to position 1
    // Simplest: push each arg again, call with nargs, pop old copies
    for (int i = 1; i <= nargs; i++) r_lua_pushvalue(L, i);  // re-push args above fn
    // Stack: [arg1..argN, fn, arg1..argN]
    // Call fn with nargs args, getting multi-return
    int status = r_lua_pcall(L, nargs, LUA_MULTRET, 0);
    // Stack: [arg1..argN, results...]
    // Remove the original args from the bottom
    int newTop = r_lua_gettop(L);
    int nresults = newTop - baseTop;
    // Shift results down over original args
    for (int i = 1; i <= nresults; i++) {
        r_lua_pushvalue(L, baseTop + i);  // copy result to top
    }
    r_lua_settop(L, nresults);
    return nresults;
}

static int l_newcclosure(lua_State* L) {
    if (!r_lua_type || !r_lua_pushcclosure) return 0;
    if (r_lua_type(L, 1) != LUA_TFUNCTION) {
        PushString(L, "newcclosure: expected function");
        return 1;
    }
    r_lua_pushvalue(L, 1);  // push original as upvalue
    r_lua_pushcclosure(L, l_newcclosure_call, 1);
    return 1;
}

// hookfunction(original, hook) → original_callable
// Replaces original function with hook, returns a callable that runs the original.
// For Luau closures (not native C): swap the function pointer inside the closure struct.
// For C closures: patch the native code with an abs jmp and build a trampoline.
//
// This is a simplified version — the CClosure function pointer swap:
//   CClosure* cc = (CClosure*)getGCObject(original);
//   cc->f = hookFn;
// The full native-code trampoline approach is in the hookfunction infrastructure above.
// TODO: implement full proto swap for LClosures (bytecode functions)

struct HookEntry { void* target; BYTE orig[16]; size_t sz; };
static std::vector<HookEntry> g_hooks;
static std::mutex              g_hooksMutex;

static int l_hookfunction(lua_State* L) {
    if (!r_lua_type || !r_lua_pushvalue) return 0;
    if (r_lua_type(L, 1) != LUA_TFUNCTION || r_lua_type(L, 2) != LUA_TFUNCTION) {
        PushString(L, "hookfunction: expected function, function");
        return 1;
    }
    // Return a copy of the original as the "trampoline" for now
    // TODO: implement real closure function pointer swap
    r_lua_pushvalue(L, 1);
    return 1;
}

// getnamecallmethod() → string
// Returns the method name being called via : syntax when inside __namecall.
// Stored as a TString* at NAMECALL_OFFSET inside lua_State.
// TODO: verify NAMECALL_OFFSET for your version (common: 0xA0, 0xA8, 0xB0)
#define NAMECALL_OFFSET 0xA8

static int l_getnamecallmethod(lua_State* L) {
    BYTE* ptr = reinterpret_cast<BYTE*>(L) + NAMECALL_OFFSET;
    if (!IsReadable(ptr, sizeof(void*))) { if (r_lua_pushnil) r_lua_pushnil(L); return 1; }
    void* tstr = *reinterpret_cast<void**>(ptr);
    if (!tstr || !IsReadable(tstr, 0x20)) { if (r_lua_pushnil) r_lua_pushnil(L); return 1; }
    // TString header in Luau is 0x18 bytes, string data follows immediately
    const char* str = reinterpret_cast<const char*>(
        reinterpret_cast<BYTE*>(tstr) + 0x18);
    PushString(L, str);
    return 1;
}

// loadstring(code, chunkname?) → fn | nil, errmsg
// Our own loadstring running at executor identity — bypasses Roblox's restrictions
static int l_loadstring(lua_State* L) {
    if (!r_luaL_loadbuffer || !r_lua_tolstring || !r_lua_pushnil) return 0;
    size_t len = 0;
    const char* code = r_lua_tolstring(L, 1, &len);
    if (!code) { r_lua_pushnil(L); PushString(L, "loadstring: expected string"); return 2; }
    const char* chunkname = "@luminos";
    if (r_lua_type && r_lua_type(L, 2) == LUA_TSTRING) {
        size_t nl; chunkname = r_lua_tolstring(L, 2, &nl);
    }
    int status = r_luaL_loadbuffer(L, code, len, chunkname);
    if (status != LUA_OK) { r_lua_pushnil(L); return 2; }
    return 1;
}

// ═══════════════════════════════════════════════════════════════════════════════
// SECTION 5 — Register all globals + create executor thread
// ═══════════════════════════════════════════════════════════════════════════════

static void RegisterExecutorGlobals(lua_State* L) {
    if (!r_lua_pushcclosure || !r_lua_setglobal) return;

    struct { const char* name; lua_CFunction fn; } G[] = {
        { "getrawmetatable",    l_getrawmetatable   },
        { "setrawmetatable",    l_setrawmetatable   },
        { "setreadonly",        l_setreadonly       },
        { "isreadonly",         l_isreadonly        },
        { "getgenv",            l_getgenv           },
        { "getrenv",            l_getrenv           },
        { "getsenv",            l_getsenv           },
        { "checkcaller",        l_checkcaller       },
        { "identifyexecutor",   l_identifyexecutor  },
        { "printidentity",      l_printidentity     },
        { "iscclosure",         l_iscclosure        },
        { "islclosure",         l_islclosure        },
        { "newcclosure",        l_newcclosure       },
        { "hookfunction",       l_hookfunction      },
        { "getnamecallmethod",  l_getnamecallmethod },
        { "loadstring",         l_loadstring        },
    };
    for (auto& g : G) {
        r_lua_pushcclosure(L, g.fn, 0);
        r_lua_setglobal(L, g.name);
    }
}

static lua_State* CreateExecutorThread(lua_State* mainL) {
    if (!r_lua_newthread) return mainL;
    lua_State* T = r_lua_newthread(mainL);
    if (!T) return mainL;
    SetThreadIdentity(T, EXECUTOR_IDENTITY);
    RegisterExecutorGlobals(T);
    return T;
}

// ═══════════════════════════════════════════════════════════════════════════════
// SECTION 6 — Offset table
//
// Replace every 0x00000000 with the real RVA from your disassembler.
// RVA = address_in_x64dbg - RobloxPlayerBeta.exe_base_address
// ═══════════════════════════════════════════════════════════════════════════════

struct LuauOffsets {
    DWORD lua_newthread, luaL_loadbuffer, lua_pcall, lua_settop, lua_gettop;
    DWORD lua_pushvalue, lua_pushcclosure, lua_pushboolean, lua_pushinteger;
    DWORD lua_pushlstring, lua_pushnil, lua_tolstring, lua_toboolean;
    DWORD lua_touserdata, lua_type, lua_setfield, lua_getfield;
    DWORD lua_rawget, lua_rawset, lua_rawequal, lua_createtable;
    DWORD lua_setmetatable, lua_getmetatable, lua_getglobal, lua_setglobal;
    DWORD luaL_loadstring, luaL_ref, luaL_unref, lua_rawgeti, lua_next;
};

// !! FILL IN YOUR RVAs BELOW — every 0x00000000 is a TODO !!
static const LuauOffsets OFFSETS = {
    0x00000000,  // lua_newthread
    0x00000000,  // luaL_loadbuffer
    0x00000000,  // lua_pcall
    0x00000000,  // lua_settop
    0x00000000,  // lua_gettop
    0x00000000,  // lua_pushvalue
    0x00000000,  // lua_pushcclosure
    0x00000000,  // lua_pushboolean
    0x00000000,  // lua_pushinteger
    0x00000000,  // lua_pushlstring
    0x00000000,  // lua_pushnil
    0x00000000,  // lua_tolstring
    0x00000000,  // lua_toboolean
    0x00000000,  // lua_touserdata
    0x00000000,  // lua_type
    0x00000000,  // lua_setfield
    0x00000000,  // lua_getfield
    0x00000000,  // lua_rawget
    0x00000000,  // lua_rawset
    0x00000000,  // lua_rawequal
    0x00000000,  // lua_createtable
    0x00000000,  // lua_setmetatable
    0x00000000,  // lua_getmetatable
    0x00000000,  // lua_getglobal
    0x00000000,  // lua_setglobal
    0x00000000,  // luaL_loadstring
    0x00000000,  // luaL_ref
    0x00000000,  // luaL_unref
    0x00000000,  // lua_rawgeti
    0x00000000,  // lua_next
};

#define RESOLVE(fn) \
    if (OFFSETS.fn) r_##fn = reinterpret_cast<t_##fn>((BYTE*)hRoblox + OFFSETS.fn)

static bool ResolveLuaFunctions(HMODULE hRoblox) {
    RESOLVE(lua_newthread);    RESOLVE(luaL_loadbuffer); RESOLVE(lua_pcall);
    RESOLVE(lua_settop);       RESOLVE(lua_gettop);      RESOLVE(lua_pushvalue);
    RESOLVE(lua_pushcclosure); RESOLVE(lua_pushboolean); RESOLVE(lua_pushinteger);
    RESOLVE(lua_pushlstring);  RESOLVE(lua_pushnil);     RESOLVE(lua_tolstring);
    RESOLVE(lua_toboolean);    RESOLVE(lua_touserdata);  RESOLVE(lua_type);
    RESOLVE(lua_setfield);     RESOLVE(lua_getfield);    RESOLVE(lua_rawget);
    RESOLVE(lua_rawset);       RESOLVE(lua_rawequal);    RESOLVE(lua_createtable);
    RESOLVE(lua_setmetatable); RESOLVE(lua_getmetatable);RESOLVE(lua_getglobal);
    RESOLVE(lua_setglobal);    RESOLVE(luaL_loadstring); RESOLVE(luaL_ref);
    RESOLVE(luaL_unref);       RESOLVE(lua_rawgeti);     RESOLVE(lua_next);
    // Minimum viable: need at least loadbuffer + pcall + settop
    return r_luaL_loadbuffer && r_lua_pcall && r_lua_settop;
}

// ═══════════════════════════════════════════════════════════════════════════════
// SECTION 7 — lua_State finder + AOB patterns
// ═══════════════════════════════════════════════════════════════════════════════

static const Pattern LUA_STATE_PATTERN = {
    "\x48\x89\x5C\x24\x08\x48\x89\x6C\x24\x10\x48\x89\x74\x24\x18\x57\x48\x83\xEC\x20\x48\x8B\xF9",
    "xxxxxxxxxxxxxxxxxxxxxxx", 23
};
static const Pattern SCHEDULER_PATTERN = {
    "\x48\x83\xEC\x28\x48\x8B\x0D\x00\x00\x00\x00\x48\x85\xC9",
    "xxxxxxx????xxx", 14
};

static lua_State* FindLuaState(HMODULE hMod) {
    MODULEINFO mi{};
    if (!GetModuleInformation(GetCurrentProcess(), hMod, &mi, sizeof(mi))) return nullptr;
    BYTE* base = (BYTE*)mi.lpBaseOfDll;
    BYTE* hit  = AOBScan(base, mi.SizeOfImage, LUA_STATE_PATTERN);
    if (!hit) return nullptr;
    const size_t OFF = 0x28; // TODO: verify
    if (!IsReadable(hit + OFF, sizeof(void*))) return nullptr;
    lua_State* L = *reinterpret_cast<lua_State**>(hit + OFF);
    if (!IsReadable(L, 0x80)) return nullptr;
    // Basic sanity: lua_State starts with a GCObject* (next), which in a 64-bit
    // process will be either NULL or a heap pointer. The tt (type tag) byte follows
    // at offset 8 and should be LUA_TTHREAD (8).
    BYTE ttByte = *reinterpret_cast<BYTE*>(reinterpret_cast<BYTE*>(L) + 8);
    if (ttByte != LUA_TTHREAD) return nullptr;
    return L;
}

static lua_State* FindLuaStateAny() {
    HMODULE mods[256]{}; DWORD needed = 0;
    if (!EnumProcessModules(GetCurrentProcess(), mods, sizeof(mods), &needed)) return nullptr;
    for (DWORD i = 0, n = needed / sizeof(HMODULE); i < n; i++) {
        char name[MAX_PATH]{};
        GetModuleBaseNameA(GetCurrentProcess(), mods[i], name, sizeof(name));
        if (!strstr(name, "RobloxPlayerBeta") && name[0] != '\0') continue;
        lua_State* L = FindLuaState(mods[i]);
        if (L) return L;
    }
    return nullptr;
}

// ═══════════════════════════════════════════════════════════════════════════════
// SECTION 8 — Task queue & scheduler hook
// ═══════════════════════════════════════════════════════════════════════════════

struct ScriptTask {
    std::string code;
    HANDLE      doneEvent;
    bool        success  = false;
    std::string errorMsg;
};

static std::queue<ScriptTask*> g_taskQueue;
static std::mutex              g_queueMutex;
static std::atomic<bool>       g_running{ true };
static lua_State*              g_mainL      = nullptr;
static lua_State*              g_execThread = nullptr;

typedef void(__fastcall* t_SchedulerStep)(void* sched, float dt);
static t_SchedulerStep g_originalStep  = nullptr;
static BYTE            g_originalBytes[14]{};
static void*           g_hookTarget    = nullptr;

static void __fastcall HookedSchedulerStep(void* sched, float dt) {
    // Recreate executor thread if it was lost (e.g. VM restart)
    if (!g_execThread && g_mainL && r_lua_newthread)
        g_execThread = CreateExecutorThread(g_mainL);

    while (true) {
        ScriptTask* task = nullptr;
        {
            std::lock_guard<std::mutex> lk(g_queueMutex);
            if (g_taskQueue.empty()) break;
            task = g_taskQueue.front();
            g_taskQueue.pop();
        }
        if (!task) continue;

        lua_State* L = g_execThread ? g_execThread : g_mainL;
        if (L && r_luaL_loadbuffer && r_lua_pcall && r_lua_settop && r_lua_gettop) {
            int top = r_lua_gettop(L);
            int status = r_luaL_loadbuffer(L, task->code.c_str(), task->code.size(), "@luminos");
            if (status == LUA_OK)
                status = r_lua_pcall(L, 0, LUA_MULTRET, 0);
            task->success = (status == LUA_OK);
            if (status != LUA_OK && r_lua_tolstring) {
                size_t el = 0;
                const char* em = r_lua_tolstring(L, -1, &el);
                if (em) task->errorMsg = std::string(em, el);
            }
            r_lua_settop(L, top);
        }
        SetEvent(task->doneEvent);
    }

    if (g_originalStep) g_originalStep(sched, dt);
}

// ═══════════════════════════════════════════════════════════════════════════════
// SECTION 9 — Pipe server
// ═══════════════════════════════════════════════════════════════════════════════

static const char  PIPE_NAME[] = "\\\\.\\pipe\\LuminosBridge";
static const DWORD PIPE_BUF    = 65536;

// Response format: [1 byte status] [4 byte msg length LE] [N bytes message]
static void SendResponse(HANDLE hPipe, bool success, const std::string& msg) {
    std::vector<BYTE> pkt;
    pkt.push_back(success ? 1 : 0);
    DWORD len = (DWORD)msg.size();
    for (int i = 0; i < 4; i++) pkt.push_back((len >> (i*8)) & 0xFF);
    pkt.insert(pkt.end(), msg.begin(), msg.end());
    OVERLAPPED ov{}; ov.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
    DWORD w = 0;
    WriteFile(hPipe, pkt.data(), (DWORD)pkt.size(), &w, &ov);
    WaitForSingleObject(ov.hEvent, 3000);
    CloseHandle(ov.hEvent);
}

static void PipeServer() {
    while (g_running) {
        HANDLE hPipe = CreateNamedPipeA(PIPE_NAME,
            PIPE_ACCESS_DUPLEX | FILE_FLAG_OVERLAPPED,
            PIPE_TYPE_MESSAGE | PIPE_READMODE_MESSAGE | PIPE_WAIT,
            1, PIPE_BUF, PIPE_BUF, 0, NULL);
        if (hPipe == INVALID_HANDLE_VALUE) { Sleep(500); continue; }

        OVERLAPPED ovConn{}; ovConn.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
        ConnectNamedPipe(hPipe, &ovConn);
        if (WaitForSingleObject(ovConn.hEvent, 5000) == WAIT_TIMEOUT || !g_running) {
            CloseHandle(ovConn.hEvent); DisconnectNamedPipe(hPipe); CloseHandle(hPipe); continue;
        }
        CloseHandle(ovConn.hEvent);

        std::vector<char> buf(PIPE_BUF);
        while (g_running) {
            OVERLAPPED ovR{}; ovR.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
            DWORD br = 0;
            BOOL ok = ReadFile(hPipe, buf.data(), (DWORD)buf.size()-1, &br, &ovR);
            if (!ok && GetLastError() == ERROR_IO_PENDING) {
                if (WaitForSingleObject(ovR.hEvent, 30000) == WAIT_OBJECT_0) {
                    GetOverlappedResult(hPipe, &ovR, &br, FALSE); ok = TRUE;
                }
            }
            CloseHandle(ovR.hEvent);
            if (!ok || br == 0) break;

            ScriptTask task;
            task.code      = std::string(buf.data(), br);
            task.doneEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
            { std::lock_guard<std::mutex> lk(g_queueMutex); g_taskQueue.push(&task); }

            DWORD xw = WaitForSingleObject(task.doneEvent, 12000);
            CloseHandle(task.doneEvent);

            if (xw == WAIT_TIMEOUT) SendResponse(hPipe, false, "Script timed out");
            else                    SendResponse(hPipe, task.success, task.errorMsg);
        }
        DisconnectNamedPipe(hPipe); CloseHandle(hPipe);
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// SECTION 10 — Init thread & DllMain
// ═══════════════════════════════════════════════════════════════════════════════

static DWORD WINAPI InitThread(LPVOID) {
    Sleep(3000);

    // Find Roblox module
    HMODULE hRoblox = NULL;
    for (int i = 0; i < 20 && !hRoblox; i++) {
        hRoblox = GetModuleHandleA("RobloxPlayerBeta.exe");
        if (!hRoblox) Sleep(500);
    }
    if (!hRoblox) return 1;

    // Resolve Luau function pointers
    ResolveLuaFunctions(hRoblox);

    // Find main lua_State
    g_mainL = FindLuaStateAny();

    // Create elevated executor thread
    if (g_mainL) g_execThread = CreateExecutorThread(g_mainL);

    // Hook the scheduler step function
    MODULEINFO mi{};
    GetModuleInformation(GetCurrentProcess(), hRoblox, &mi, sizeof(mi));
    BYTE* schedHit = AOBScan((BYTE*)mi.lpBaseOfDll, mi.SizeOfImage, SCHEDULER_PATTERN);

    if (schedHit) {
        g_hookTarget = schedHit;
        memcpy(g_originalBytes, schedHit, 14);

        // Build a proper trampoline in executable memory:
        //   [14 bytes original instructions] + [14 byte abs jmp back to schedHit+14]
        BYTE* tramp = reinterpret_cast<BYTE*>(
            VirtualAlloc(nullptr, 32, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE));
        if (tramp) {
            memcpy(tramp, g_originalBytes, 14);
            // Write jmp back: FF 25 00 00 00 00 <addr>
            BYTE jmpBack[14] = { 0xFF, 0x25, 0x00, 0x00, 0x00, 0x00 };
            UINT64 ret = reinterpret_cast<UINT64>(schedHit + 14);
            memcpy(jmpBack + 6, &ret, 8);
            memcpy(tramp + 14, jmpBack, 14);
            FlushInstructionCache(GetCurrentProcess(), tramp, 32);
            g_originalStep = reinterpret_cast<t_SchedulerStep>(tramp);
        }

        WriteAbsJmp(schedHit, reinterpret_cast<void*>(HookedSchedulerStep));
    }

    std::thread(PipeServer).detach();
    return 0;
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD dwReason, LPVOID) {
    switch (dwReason) {
    case DLL_PROCESS_ATTACH:
        DisableThreadLibraryCalls(hModule);
        CreateThread(NULL, 0, InitThread, NULL, 0, NULL);
        break;
    case DLL_PROCESS_DETACH:
        g_running = false;
        if (g_hookTarget) {
            DWORD old;
            VirtualProtect(g_hookTarget, 14, PAGE_EXECUTE_READWRITE, &old);
            memcpy(g_hookTarget, g_originalBytes, 14);
            VirtualProtect(g_hookTarget, 14, old, &old);
            FlushInstructionCache(GetCurrentProcess(), g_hookTarget, 14);
        }
        { std::lock_guard<std::mutex> lk(g_hooksMutex);
          for (auto& h : g_hooks) {
              DWORD old;
              VirtualProtect(h.target, h.sz, PAGE_EXECUTE_READWRITE, &old);
              memcpy(h.target, h.orig, h.sz);
              VirtualProtect(h.target, h.sz, old, &old);
          }
        }
        break;
    }
    return TRUE;
}
