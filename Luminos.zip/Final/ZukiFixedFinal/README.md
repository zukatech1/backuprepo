# Luminos

## Setup after building

1. Run `build.bat` — outputs `build/Release/luminos.dll` and `build/Release/injector.exe`
2. Create a `bin/` folder in the project root
3. Copy both files there:
   ```
   ZukiFixed/
     bin/
       luminos.dll
       injector.exe
   ```
4. Run `npm install` then `npm run dev` (or `npm run build` for a packaged app)
5. Open Roblox, then click the **Attach** button in the GUI

## How attach works
- GUI calls `executor:attach` via IPC
- Main process runs `tasklist` to find `RobloxPlayerBeta.exe` PID
- Runs `injector.exe <pid> luminos.dll` to manual-map the DLL
- Waits 3.5s for the DLL pipe server to start
- Connects to `\\.\pipe\LuminosBridge`
- Execute button sends Lua code through the pipe

## Before it'll actually run scripts
Fill in the `OFFSETS` table in `dllmain.cpp` with real RVAs from x64dbg/Cheat Engine.
At minimum you need: `luaL_loadbuffer`, `lua_pcall`, `lua_settop`, `lua_gettop`.
