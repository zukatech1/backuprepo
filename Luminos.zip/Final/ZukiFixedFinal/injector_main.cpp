/*
 * Luminos — Manual Map Injector
 * injector.exe <pid> <path-to-dll>
 *
 * Manually maps luminos.dll into the target process without
 * using LoadLibrary, so the module never appears in the module list.
 *
 * Steps:
 *  1. Open target process
 *  2. Allocate memory in target for the DLL image
 *  3. Write PE headers + sections
 *  4. Fix relocations
 *  5. Resolve imports
 *  6. Execute DllMain via a remote shellcode stub
 *  7. Clean up PE headers in target memory (anti-detection)
 */

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <psapi.h>
#include <tlhelp32.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <stdexcept>

#pragma comment(lib, "psapi.lib")

// ── Console output helpers ────────────────────────────────────────────────────

static void ok  (const std::string& s) { std::cout << "  [+] " << s << "\n"; }
static void info(const std::string& s) { std::cout << "  [*] " << s << "\n"; }
static void fail(const std::string& s) { std::cerr << "  [-] " << s << "\n"; }

// ── Read DLL from disk ────────────────────────────────────────────────────────

static std::vector<BYTE> readFile(const std::string& path) {
    std::ifstream f(path, std::ios::binary | std::ios::ate);
    if (!f) throw std::runtime_error("Cannot open DLL: " + path);
    std::streamsize sz = f.tellg();
    f.seekg(0);
    std::vector<BYTE> buf(sz);
    f.read(reinterpret_cast<char*>(buf.data()), sz);
    return buf;
}

// ── PE helpers ────────────────────────────────────────────────────────────────

static IMAGE_NT_HEADERS* getNtHeaders(BYTE* base) {
    auto* dos = reinterpret_cast<IMAGE_DOS_HEADER*>(base);
    if (dos->e_magic != IMAGE_DOS_SIGNATURE)
        throw std::runtime_error("Not a valid PE file");
    auto* nt = reinterpret_cast<IMAGE_NT_HEADERS*>(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE)
        throw std::runtime_error("Invalid NT signature");
    return nt;
}

// ── Shellcode that runs in the target process ─────────────────────────────────
//
// This stub is written into the target, calls DllMain, then signals
// an event so we know it's done.
//
// Parameters are passed via a struct written into the target at a
// known address right before the shellcode.

#pragma pack(push, 1)
struct LoaderParams {
    BYTE*          imageBase;       // where the DLL was mapped
    DWORD          entryPointRva;   // RVA of DllMain
    HANDLE         hEvent;          // event we signal when done
    // We need these function pointers because we can't call them by name
    // from shellcode — we resolve them in the host process and write them here
    decltype(&FlushInstructionCache) pFlushInstructionCache;
    decltype(&VirtualProtect)        pVirtualProtect;
};
#pragma pack(pop)

// x64 shellcode:
//   - loads param struct (RCX = pointer to LoaderParams)
//   - calls DllMain(imageBase, DLL_PROCESS_ATTACH, NULL)
//   - calls SetEvent(hEvent)
//   - returns / exits thread
//
// We can't hardcode SetEvent's address so we pass it in LoaderParams too.
struct LoaderParamsFull {
    BYTE*          imageBase;
    DWORD          entryPointRva;
    HANDLE         hEvent;
    decltype(&FlushInstructionCache) pFlushInstructionCache;
    decltype(&SetEvent)              pSetEvent;
};

// shellcode bytes (position-independent x64)
// equivalent to:
//   typedef BOOL(WINAPI* DllEntryProc)(HINSTANCE, DWORD, LPVOID);
//   DllEntryProc entry = (DllEntryProc)(params->imageBase + params->entryPointRva);
//   entry(params->imageBase, DLL_PROCESS_ATTACH, NULL);
//   params->pSetEvent(params->hEvent);
static const BYTE g_loaderShellcode[] = {
    // RCX = pointer to LoaderParamsFull
    0x55,                               // push rbp
    0x48, 0x89, 0xE5,                   // mov rbp, rsp
    0x48, 0x83, 0xEC, 0x30,             // sub rsp, 0x30  (shadow space + align)
    0x48, 0x89, 0x4D, 0x10,             // mov [rbp+10], rcx  ; save params ptr

    // Flush instruction cache for the mapped image
    // FlushInstructionCache(GetCurrentProcess(), imageBase, sizeOfImage)
    // We skip this for simplicity and just call DllMain directly

    // Load imageBase (params->imageBase = [rcx+0])
    0x48, 0x8B, 0x01,                   // mov rax, [rcx]       ; imageBase
    // Load entryPointRva (params->entryPointRva = [rcx+8])
    0x8B, 0x51, 0x08,                   // mov edx, [rcx+8]     ; entryPointRva
    // entry = imageBase + entryPointRva
    0x48, 0x01, 0xD0,                   // add rax, rdx         ; entry point

    // Call entry(imageBase, DLL_PROCESS_ATTACH=1, NULL)
    0x48, 0x8B, 0x4D, 0x10,             // mov rcx, [rbp+10]    ; reload params
    0x48, 0x8B, 0x09,                   // mov rcx, [rcx]       ; imageBase (arg1)
    0xBA, 0x01, 0x00, 0x00, 0x00,       // mov edx, 1           ; DLL_PROCESS_ATTACH (arg2)
    0x4D, 0x31, 0xC0,                   // xor r8, r8           ; NULL (arg3)
    0xFF, 0xD0,                         // call rax             ; call DllMain

    // SetEvent(params->hEvent)
    0x48, 0x8B, 0x4D, 0x10,             // mov rcx, [rbp+10]    ; params
    0x48, 0x8B, 0x41, 0x18,             // mov rax, [rcx+0x18]  ; pSetEvent
    0x48, 0x8B, 0x49, 0x10,             // mov rcx, [rcx+0x10]  ; hEvent (arg1)
    0xFF, 0xD0,                         // call rax

    // Return
    0x48, 0x83, 0xC4, 0x30,             // add rsp, 0x30
    0x5D,                               // pop rbp
    0xC3                                // ret
};

// ── Manual map implementation ─────────────────────────────────────────────────

class ManualMapper {
public:
    ManualMapper(DWORD pid, const std::string& dllPath)
        : m_pid(pid), m_dllPath(dllPath) {}

    bool run() {
        try {
            loadDll();
            openProcess();
            allocateImage();
            writeHeaders();
            writeSections();
            fixRelocations();
            resolveImports();
            mapAndExecute();
            wipeHeaders();   // scrub PE header from target memory
            ok("Injection complete");
            return true;
        } catch (const std::exception& e) {
            fail(e.what());
            cleanup();
            return false;
        }
    }

private:
    DWORD              m_pid;
    std::string        m_dllPath;
    std::vector<BYTE>  m_dllData;
    HANDLE             m_hProc     = NULL;
    BYTE*              m_localBase = nullptr;  // local copy of mapped image
    BYTE*              m_remoteBase= nullptr;  // address in target process
    IMAGE_NT_HEADERS*  m_nt        = nullptr;

    // ── Step 1: Load DLL ──────────────────────────────────────────────────
    void loadDll() {
        m_dllData = readFile(m_dllPath);
        m_nt      = getNtHeaders(m_dllData.data());

        if (m_nt->FileHeader.Machine != IMAGE_FILE_MACHINE_AMD64)
            throw std::runtime_error("DLL must be 64-bit (x64)");

        // Allocate a local buffer sized to the virtual image
        SIZE_T imageSize = m_nt->OptionalHeader.SizeOfImage;
        m_localBase = reinterpret_cast<BYTE*>(
            VirtualAlloc(nullptr, imageSize, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE));
        if (!m_localBase)
            throw std::runtime_error("Local VirtualAlloc failed");

        info("DLL loaded: " + std::to_string(m_dllData.size()) + " bytes, image size: " + std::to_string(imageSize));
    }

    // ── Step 2: Open process ──────────────────────────────────────────────
    void openProcess() {
        m_hProc = OpenProcess(
            PROCESS_VM_READ | PROCESS_VM_WRITE | PROCESS_VM_OPERATION |
            PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION,
            FALSE, m_pid);
        if (!m_hProc)
            throw std::runtime_error("OpenProcess failed (PID " + std::to_string(m_pid) +
                                     ") — error " + std::to_string(GetLastError()) +
                                     ". Try running as Administrator.");
        ok("Opened process PID " + std::to_string(m_pid));
    }

    // ── Step 3: Allocate image memory in target ───────────────────────────
    void allocateImage() {
        SIZE_T imageSize = m_nt->OptionalHeader.SizeOfImage;

        // Try preferred base first
        m_remoteBase = reinterpret_cast<BYTE*>(
            VirtualAllocEx(m_hProc,
                reinterpret_cast<LPVOID>(m_nt->OptionalHeader.ImageBase),
                imageSize, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE));

        if (!m_remoteBase) {
            // Preferred base taken — allocate anywhere
            m_remoteBase = reinterpret_cast<BYTE*>(
                VirtualAllocEx(m_hProc, nullptr, imageSize,
                    MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE));
        }

        if (!m_remoteBase)
            throw std::runtime_error("Remote VirtualAllocEx failed: " +
                                     std::to_string(GetLastError()));

        ok("Remote image allocated at 0x" + hexStr((uintptr_t)m_remoteBase));
    }

    // ── Step 4: Write PE headers to local buffer ──────────────────────────
    void writeHeaders() {
        memcpy(m_localBase, m_dllData.data(), m_nt->OptionalHeader.SizeOfHeaders);
    }

    // ── Step 5: Write sections to local buffer ────────────────────────────
    void writeSections() {
        BYTE* secPtr = reinterpret_cast<BYTE*>(IMAGE_FIRST_SECTION(m_nt));
        for (WORD i = 0; i < m_nt->FileHeader.NumberOfSections; i++) {
            auto* sec = reinterpret_cast<IMAGE_SECTION_HEADER*>(secPtr + i * sizeof(IMAGE_SECTION_HEADER));
            if (sec->SizeOfRawData == 0) continue;
            memcpy(
                m_localBase + sec->VirtualAddress,
                m_dllData.data() + sec->PointerToRawData,
                sec->SizeOfRawData
            );
        }
        info("Sections written: " + std::to_string(m_nt->FileHeader.NumberOfSections));
    }

    // ── Step 6: Fix relocations ───────────────────────────────────────────
    void fixRelocations() {
        ULONGLONG delta = (ULONGLONG)m_remoteBase - m_nt->OptionalHeader.ImageBase;
        if (delta == 0) { info("No relocation needed (preferred base available)"); return; }

        auto& relocDir = m_nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC];
        if (relocDir.VirtualAddress == 0) {
            // DLL has no reloc table — it must load at preferred base or fail
            if (delta != 0)
                throw std::runtime_error("DLL has no relocation table but couldn't load at preferred base");
            return;
        }

        BYTE* relocBase = m_localBase + relocDir.VirtualAddress;
        BYTE* relocEnd  = relocBase + relocDir.Size;

        while (relocBase < relocEnd) {
            auto* block = reinterpret_cast<IMAGE_BASE_RELOCATION*>(relocBase);
            if (block->SizeOfBlock == 0) break;

            DWORD entryCount = (block->SizeOfBlock - sizeof(IMAGE_BASE_RELOCATION)) / sizeof(WORD);
            WORD* entries    = reinterpret_cast<WORD*>(relocBase + sizeof(IMAGE_BASE_RELOCATION));

            for (DWORD i = 0; i < entryCount; i++) {
                int type   = entries[i] >> 12;
                int offset = entries[i] & 0xFFF;
                if (type == IMAGE_REL_BASED_DIR64) {
                    ULONGLONG* pAddr = reinterpret_cast<ULONGLONG*>(
                        m_localBase + block->VirtualAddress + offset);
                    *pAddr += delta;
                }
            }

            relocBase += block->SizeOfBlock;
        }
        ok("Relocations fixed (delta: 0x" + hexStr(delta) + ")");
    }

    // ── Step 7: Resolve imports ───────────────────────────────────────────
    void resolveImports() {
        auto& importDir = m_nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
        if (importDir.VirtualAddress == 0) { info("No imports"); return; }

        auto* desc = reinterpret_cast<IMAGE_IMPORT_DESCRIPTOR*>(
            m_localBase + importDir.VirtualAddress);

        for (; desc->Name; desc++) {
            const char* modName = reinterpret_cast<const char*>(m_localBase + desc->Name);
            HMODULE hMod = LoadLibraryA(modName);
            if (!hMod)
                throw std::runtime_error(std::string("Failed to load import DLL: ") + modName);

            auto* thunk    = reinterpret_cast<IMAGE_THUNK_DATA*>(m_localBase + desc->FirstThunk);
            auto* origThunk= desc->OriginalFirstThunk
                           ? reinterpret_cast<IMAGE_THUNK_DATA*>(m_localBase + desc->OriginalFirstThunk)
                           : thunk;

            for (; origThunk->u1.AddressOfData; origThunk++, thunk++) {
                FARPROC fn = nullptr;
                if (IMAGE_SNAP_BY_ORDINAL(origThunk->u1.Ordinal)) {
                    fn = GetProcAddress(hMod, MAKEINTRESOURCEA(IMAGE_ORDINAL(origThunk->u1.Ordinal)));
                } else {
                    auto* ibn = reinterpret_cast<IMAGE_IMPORT_BY_NAME*>(
                        m_localBase + origThunk->u1.AddressOfData);
                    fn = GetProcAddress(hMod, ibn->Name);
                    if (!fn)
                        throw std::runtime_error(std::string("Unresolved import: ") +
                                                 modName + "!" + ibn->Name);
                }
                thunk->u1.Function = reinterpret_cast<ULONGLONG>(fn);
            }
        }
        ok("Imports resolved");
    }

    // ── Step 8: Write local buffer to target, run DllMain via shellcode ───
    void mapAndExecute() {
        SIZE_T imageSize = m_nt->OptionalHeader.SizeOfImage;

        // Write the fully prepared image into the target process
        SIZE_T written = 0;
        if (!WriteProcessMemory(m_hProc, m_remoteBase, m_localBase, imageSize, &written))
            throw std::runtime_error("WriteProcessMemory (image) failed: " +
                                     std::to_string(GetLastError()));
        ok("Image written to target (" + std::to_string(written) + " bytes)");

        // Create a named event so we can wait for DllMain to finish
        // Use a random suffix to avoid name collisions
        std::string evtName = "LuminosLoaderEvent_" + std::to_string(GetCurrentProcessId());
        HANDLE hLocalEvent = CreateEventA(NULL, TRUE, FALSE, evtName.c_str());
        if (!hLocalEvent)
            throw std::runtime_error("CreateEvent failed");

        // Duplicate event handle into target process so shellcode can signal it
        HANDLE hRemoteEvent = NULL;
        if (!DuplicateHandle(GetCurrentProcess(), hLocalEvent,
                             m_hProc, &hRemoteEvent, 0, FALSE, DUPLICATE_SAME_ACCESS))
            throw std::runtime_error("DuplicateHandle failed");

        // Build loader params
        LoaderParamsFull params{};
        params.imageBase      = m_remoteBase;
        params.entryPointRva  = m_nt->OptionalHeader.AddressOfEntryPoint;
        params.hEvent         = hRemoteEvent;
        params.pSetEvent      = SetEvent;  // same address in all processes (kernel32)

        // Allocate space for params + shellcode in target
        SIZE_T stubSize   = sizeof(params) + sizeof(g_loaderShellcode);
        BYTE*  remoteStub = reinterpret_cast<BYTE*>(
            VirtualAllocEx(m_hProc, nullptr, stubSize,
                MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE));
        if (!remoteStub)
            throw std::runtime_error("VirtualAllocEx (stub) failed");

        BYTE*  remoteShellcode = remoteStub + sizeof(params);

        // Write params then shellcode
        WriteProcessMemory(m_hProc, remoteStub,        &params,              sizeof(params),             nullptr);
        WriteProcessMemory(m_hProc, remoteShellcode,    g_loaderShellcode,   sizeof(g_loaderShellcode),  nullptr);

        // Create remote thread starting at shellcode, passing params pointer as arg
        HANDLE hThread = CreateRemoteThread(
            m_hProc, nullptr, 0,
            reinterpret_cast<LPTHREAD_START_ROUTINE>(remoteShellcode),
            remoteStub,   // RCX = &params
            0, nullptr);

        if (!hThread)
            throw std::runtime_error("CreateRemoteThread failed: " +
                                     std::to_string(GetLastError()));

        ok("Remote loader thread started");

        // Wait up to 10 seconds for DllMain to return
        DWORD waitResult = WaitForSingleObject(hLocalEvent, 10000);
        CloseHandle(hLocalEvent);
        CloseHandle(hThread);

        // Free the stub memory
        VirtualFreeEx(m_hProc, remoteStub, 0, MEM_RELEASE);

        if (waitResult == WAIT_TIMEOUT)
            throw std::runtime_error("DllMain timed out (10s) — possible crash in DLL init");

        ok("DllMain returned successfully");
    }

    // ── Step 9: Wipe PE headers in target (anti-detection) ───────────────
    void wipeHeaders() {
        SIZE_T headerSize = m_nt->OptionalHeader.SizeOfHeaders;
        std::vector<BYTE> zeros(headerSize, 0);
        DWORD oldProtect = 0;
        VirtualProtectEx(m_hProc, m_remoteBase, headerSize, PAGE_READWRITE, &oldProtect);
        WriteProcessMemory(m_hProc, m_remoteBase, zeros.data(), headerSize, nullptr);
        VirtualProtectEx(m_hProc, m_remoteBase, headerSize, oldProtect, &oldProtect);
        ok("PE headers wiped from target memory");
    }

    // ── Cleanup ───────────────────────────────────────────────────────────
    void cleanup() {
        if (m_localBase)  VirtualFree(m_localBase, 0, MEM_RELEASE);
        if (m_hProc)      CloseHandle(m_hProc);
        // Do NOT free remote memory on failure — partial maps cause instability
    }

    static std::string hexStr(uintptr_t v) {
        char buf[32];
        snprintf(buf, sizeof(buf), "%llX", (unsigned long long)v);
        return buf;
    }
};

// ── Entry point ───────────────────────────────────────────────────────────────

int main(int argc, char* argv[]) {
    std::cout << "\n  Luminos Injector\n  ----------------\n";

    if (argc < 3) {
        fail("Usage: injector.exe <pid> <dll-path>");
        return 1;
    }

    DWORD pid = static_cast<DWORD>(std::stoul(argv[1]));
    std::string dllPath = argv[2];

    info("Target PID: " + std::to_string(pid));
    info("DLL path:   " + dllPath);
    std::cout << "\n";

    ManualMapper mapper(pid, dllPath);
    bool ok = mapper.run();

    std::cout << "\n";
    return ok ? 0 : 1;
}
