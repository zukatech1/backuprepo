@echo off
:: XenoOffsetScanner build script
:: Run this from a Visual Studio Developer Command Prompt, OR
:: it will try to find and call vcvars64.bat automatically.

echo === XenoOffsetScanner Build ===

:: Try to find VS automatically
if exist "%ProgramFiles%\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" (
    call "%ProgramFiles%\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" >nul 2>&1
    goto build
)
if exist "%ProgramFiles%\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvars64.bat" (
    call "%ProgramFiles%\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvars64.bat" >nul 2>&1
    goto build
)
if exist "%ProgramFiles%\Microsoft Visual Studio\2022\Enterprise\VC\Auxiliary\Build\vcvars64.bat" (
    call "%ProgramFiles%\Microsoft Visual Studio\2022\Enterprise\VC\Auxiliary\Build\vcvars64.bat" >nul 2>&1
    goto build
)
if exist "%ProgramFiles(x86)%\Microsoft Visual Studio\2019\Community\VC\Auxiliary\Build\vcvars64.bat" (
    call "%ProgramFiles(x86)%\Microsoft Visual Studio\2019\Community\VC\Auxiliary\Build\vcvars64.bat" >nul 2>&1
    goto build
)

echo Could not find Visual Studio automatically.
echo Please run this from a "Developer Command Prompt for VS 2019/2022".
pause
exit /b 1

:build
echo Building...
cl /EHsc /O2 /std:c++17 /W3 ^
   XenoOffsetScanner.cpp ^
   /Fe:XenoOffsetScanner.exe ^
   /link psapi.lib >build_log.txt 2>&1

if %errorlevel% == 0 (
    echo.
    echo Build successful! Run XenoOffsetScanner.exe while Roblox is open IN-GAME.
    echo Output will show you exactly which offsets need updating in worker.hpp.
    echo.
    del *.obj >nul 2>&1
) else (
    echo.
    echo Build FAILED. See build_log.txt for details.
    type build_log.txt
)
pause
