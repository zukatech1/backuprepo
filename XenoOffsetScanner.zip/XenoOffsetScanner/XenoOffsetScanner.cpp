/*
 * XenoOffsetScanner.cpp
 * ---------------------
 * Standalone Roblox offset scanner for Xeno executor.
 * No debugger, no injection — just OpenProcess(PROCESS_VM_READ) which
 * Hyperion does not flag. Run this while Roblox is open in-game.
 *
 * Strategy:
 *   1. Find RobloxPlayerBeta.exe PID
 *   2. Find RenderView from the log file (same method Xeno uses)
 *   3. Walk from RenderView to DataModel using a candidate offset scan
 *   4. From DataModel walk known Roblox instance tree (CoreGui -> RobloxGui -> ...)
 *      using EVERY candidate offset for Children/Name until we find the right ones
 *   5. For script offsets, find a known ModuleScript via the tree then
 *      brute-scan its struct for the embedded bytecode pointer
 *   6. Print confirmed offsets in a format you can paste directly into worker.hpp
 *
 * Compile (MSVC, from Developer Command Prompt):
 *   cl /EHsc /O2 /std:c++17 XenoOffsetScanner.cpp /link psapi.lib
 *
 * Run:
 *   XenoOffsetScanner.exe
 */

#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <Psapi.h>
#include <TlHelp32.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <regex>
#include <algorithm>
#include <filesystem>
#include <iomanip>
#include <unordered_map>
#include <cassert>

#pragma comment(lib, "psapi.lib")

// ============================================================
//  Safe memory read helpers
// ============================================================

template<typename T>
T rmem(HANDLE h, uintptr_t addr) {
    T val{};
    SIZE_T n = 0;
    ReadProcessMemory(h, reinterpret_cast<LPCVOID>(addr), &val, sizeof(T), &n);
    return (n == sizeof(T)) ? val : T{};
}

bool is_readable(HANDLE h, uintptr_t addr, SIZE_T len = 8) {
    if (addr == 0 || addr > 0x7FFFFFFFFFFF) return false;
    MEMORY_BASIC_INFORMATION mbi{};
    if (!VirtualQueryEx(h, reinterpret_cast<LPCVOID>(addr), &mbi, sizeof(mbi))) return false;
    return (mbi.State == MEM_COMMIT) &&
           !(mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD)) &&
           (mbi.RegionSize >= len);
}

std::string read_roblox_string(HANDLE h, uintptr_t strAddr) {
    if (!is_readable(h, strAddr, 0x18)) return "";
    uint64_t len = rmem<uint64_t>(h, strAddr + 0x10);
    if (len == 0 || len > 2048) return "";
    uintptr_t dataPtr = (len > 15) ? rmem<uintptr_t>(h, strAddr) : strAddr;
    if (!is_readable(h, dataPtr, len)) return "";
    std::string s(len, '\0');
    SIZE_T n = 0;
    ReadProcessMemory(h, reinterpret_cast<LPCVOID>(dataPtr), s.data(), len, &n);
    if (n != len) return "";
    // Sanity: all printable ASCII
    for (char c : s) if ((unsigned char)c > 127 || (unsigned char)c < 9) return "";
    return s;
}

// ============================================================
//  Process / log helpers (same as Xeno's GetRV, non-destructive)
// ============================================================

DWORD find_roblox_pid() {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return 0;
    PROCESSENTRY32W pe{ sizeof(pe) };
    DWORD pid = 0;
    if (Process32FirstW(snap, &pe)) {
        do {
            if (_wcsicmp(pe.szExeFile, L"RobloxPlayerBeta.exe") == 0) {
                pid = pe.th32ProcessID;
                break;
            }
        } while (Process32NextW(snap, &pe));
    }
    CloseHandle(snap);
    return pid;
}

uintptr_t find_render_view(HANDLE h) {
    std::filesystem::path localAppData =
        std::filesystem::temp_directory_path().parent_path().parent_path();
    std::filesystem::path logs = localAppData / "Roblox" / "logs";

    if (!std::filesystem::is_directory(logs)) {
        std::cerr << "[-] Roblox logs directory not found at " << logs << "\n";
        return 0;
    }

    std::vector<std::filesystem::path> logFiles;
    for (auto& e : std::filesystem::directory_iterator(logs))
        if (e.is_regular_file() && e.path().extension() == ".log")
            logFiles.push_back(e.path());

    std::sort(logFiles.begin(), logFiles.end(), [](auto& a, auto& b) {
        return std::filesystem::last_write_time(a) > std::filesystem::last_write_time(b);
    });

    static const std::regex rgx(R"(\bSurfaceController\[_:1\]::initialize view\((.*?)\))");

    for (auto& logPath : logFiles) {
        // Try exclusive open to find the locked (live) log first
        HANDLE hTest = CreateFileW(logPath.wstring().c_str(), GENERIC_READ,
                                   0, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
        bool locked = (hTest == INVALID_HANDLE_VALUE);
        if (!locked) { CloseHandle(hTest); }

        // Read with share flags regardless
        HANDLE hLog = CreateFileW(logPath.wstring().c_str(), GENERIC_READ,
                                  FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                                  nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
        if (hLog == INVALID_HANDLE_VALUE) continue;

        LARGE_INTEGER sz{};
        GetFileSizeEx(hLog, &sz);
        if (sz.QuadPart == 0 || sz.QuadPart > 32 * 1024 * 1024) { CloseHandle(hLog); continue; }

        std::string content(static_cast<size_t>(sz.QuadPart), '\0');
        DWORD bytesRead = 0;
        ReadFile(hLog, content.data(), static_cast<DWORD>(sz.QuadPart), &bytesRead, nullptr);
        CloseHandle(hLog);
        content.resize(bytesRead);

        std::smatch m;
        if (!std::regex_search(content, m, rgx) || m.size() <= 1) continue;

        uintptr_t rv = std::strtoull(m[1].str().c_str(), nullptr, 16);
        if (rv == 0) continue;

        uintptr_t probe = rmem<uintptr_t>(h, rv + 0x118);
        if (probe != 0) {
            std::cout << "[+] RenderView found at: 0x" << std::hex << rv << std::dec << "\n";
            return rv;
        }
    }
    return 0;
}

// ============================================================
//  Candidate offset scanner
// ============================================================

struct OffsetResult {
    uint64_t Name            = 0;
    uint64_t Children        = 0;
    uint64_t Parent          = 0;
    uint64_t ClassDescriptor = 0;
    uint64_t ClassName       = 0;   // relative to ClassDescriptor
    uint64_t LocalPlayer     = 0;
    uint64_t ModuleEmbedded  = 0;
    uint64_t LocalEmbedded   = 0;
    uint64_t IsCoreScript    = 0;
    uint64_t ModuleFlags     = 0;
    uint64_t Bytecode        = 0;
    uint64_t BytecodeSize    = 0;
    uint64_t RVtoFakeDM      = 0;   // RenderView + X = fakeDataModel
    uint64_t FakeDMtoRealDM  = 0;   // fakeDataModel + Y = DataModel
};

// Try to read a Roblox string at address[offset] and return it if valid
std::string try_name_at(HANDLE h, uintptr_t base, uint64_t off) {
    uintptr_t namePtr = rmem<uintptr_t>(h, base + off);
    if (!is_readable(h, namePtr, 0x18)) return "";
    return read_roblox_string(h, namePtr);
}

// Given a base address and a candidate Children offset, try to read children
// Returns child pointers (up to maxChildren) or empty on failure
std::vector<uintptr_t> try_children_at(HANDLE h, uintptr_t base, uint64_t off, int maxChildren = 64) {
    std::vector<uintptr_t> result;
    uintptr_t childrenContainer = rmem<uintptr_t>(h, base + off);
    if (!is_readable(h, childrenContainer, 0x10)) return result;

    uintptr_t start = rmem<uintptr_t>(h, childrenContainer);
    uintptr_t end   = rmem<uintptr_t>(h, childrenContainer + 0x8);
    if (start == 0 || end == 0 || end < start) return result;

    size_t count = (end - start) / 0x10;
    if (count > (size_t)maxChildren || count == 0) return result;

    for (uintptr_t p = start; p < end; p += 0x10) {
        uintptr_t child = rmem<uintptr_t>(h, p);
        if (child != 0 && is_readable(h, child, 0x80))
            result.push_back(child);
    }
    return result;
}

// ============================================================
//  Main scanning logic
// ============================================================

int main() {
    std::cout << "=== XenoOffsetScanner ===\n";
    std::cout << "Make sure Roblox is open and IN-GAME (not on the home screen).\n\n";

    DWORD pid = find_roblox_pid();
    if (!pid) {
        std::cerr << "[-] RobloxPlayerBeta.exe not found. Is Roblox running?\n";
        return 1;
    }
    std::cout << "[+] Roblox PID: " << pid << "\n";

    HANDLE h = OpenProcess(PROCESS_VM_READ | PROCESS_QUERY_INFORMATION, FALSE, pid);
    if (!h) {
        std::cerr << "[-] OpenProcess failed: " << GetLastError() << "\n";
        return 1;
    }

    // ---- Step 1: Find RenderView ----
    uintptr_t rv = find_render_view(h);
    if (!rv) {
        std::cerr << "[-] Could not find RenderView in log files.\n";
        CloseHandle(h);
        return 1;
    }

    // ---- Step 2: Find RenderView -> DataModel offsets ----
    // Xeno uses: fakeDataModel = *(rv + 0x118), dataModel = fakeDataModel + 0x190
    // Scan nearby offsets to confirm or correct these
    uintptr_t fakeDataModel = 0;
    uint64_t  rvOffset      = 0;
    uint64_t  dmOffset      = 0;

    std::cout << "\n[*] Scanning RenderView -> DataModel offsets...\n";
    for (uint64_t rvo = 0x100; rvo <= 0x180; rvo += 8) {
        uintptr_t candidate = rmem<uintptr_t>(h, rv + rvo);
        if (!is_readable(h, candidate, 0x200)) continue;

        for (uint64_t dmo = 0x180; dmo <= 0x220; dmo += 8) {
            uintptr_t dmCandidate = candidate + dmo;
            if (!is_readable(h, dmCandidate, 0x100)) continue;

            // DataModel should have a readable name that is "LuaApp", "App", or a game name
            // Try a few plausible Name offsets
            for (uint64_t nameOff : {(uint64_t)0x48, 0x50ULL, 0x58ULL}) {
                std::string name = try_name_at(h, dmCandidate, nameOff);
                if (name == "LuaApp" || name == "App" ||
                    (name.size() >= 3 && name.size() < 64 &&
                     std::all_of(name.begin(), name.end(), [](char c){
                         return isalnum((unsigned char)c) || c == ' ' || c == '_' || c == '-';
                     })))
                {
                    fakeDataModel = candidate;
                    rvOffset      = rvo;
                    dmOffset      = dmo;
                    std::cout << "[+] RenderView + 0x" << std::hex << rvo
                              << " = fakeDataModel (0x" << candidate << ")\n";
                    std::cout << "[+] fakeDataModel + 0x" << std::hex << dmo
                              << " = DataModel (0x" << dmCandidate << ")\n";
                    std::cout << "[+] DataModel.Name (offset 0x" << nameOff << "): \""
                              << name << "\"\n" << std::dec;
                    goto found_dm;
                }
            }
        }
    }
    std::cerr << "[-] Could not locate DataModel. Offsets may have shifted significantly.\n";
    CloseHandle(h);
    return 1;
found_dm:;

    uintptr_t dataModel = fakeDataModel + dmOffset;

    // ---- Step 3: Find Name / Children / ClassDescriptor offsets ----
    std::cout << "\n[*] Scanning Instance field offsets from DataModel...\n";

    uint64_t nameOff = 0, childrenOff = 0, classDescOff = 0, classNameOff = 0;

    // Scan Name offset: read DataModel name - we know it's "LuaApp", "App", or similar
    std::string knownDMName;
    for (uint64_t off = 0x40; off <= 0x80; off += 8) {
        std::string n = try_name_at(h, dataModel, off);
        if (!n.empty() && n.size() < 64) {
            knownDMName = n;
            nameOff     = off;
            std::cout << "[+] Name offset: 0x" << std::hex << off
                      << " (DataModel.Name = \"" << n << "\")\n" << std::dec;
            break;
        }
    }
    if (nameOff == 0) {
        std::cerr << "[-] Could not find Name offset.\n";
        CloseHandle(h); return 1;
    }

    // Scan ClassDescriptor and ClassName
    // ClassDescriptor is a pointer to a struct whose first field (at +0x8) is the class name string ptr
    for (uint64_t cdOff = 0x10; cdOff <= 0x40; cdOff += 8) {
        uintptr_t cd = rmem<uintptr_t>(h, dataModel + cdOff);
        if (!is_readable(h, cd, 0x20)) continue;
        for (uint64_t cnOff : {(uint64_t)0x8, 0x10ULL}) {
            std::string cn = try_name_at(h, cd, cnOff);
            if (cn == "DataModel") {
                classDescOff = cdOff;
                classNameOff = cnOff;
                std::cout << "[+] ClassDescriptor offset: 0x" << std::hex << cdOff << "\n";
                std::cout << "[+] ClassName offset (from ClassDescriptor): 0x" << cnOff << "\n" << std::dec;
                goto found_class;
            }
        }
    }
    std::cerr << "[-] Could not find ClassDescriptor/ClassName offsets.\n";
    CloseHandle(h); return 1;
found_class:;

    // Scan Children offset: look for a vector-like structure that yields readable child instances
    for (uint64_t off = 0x48; off <= 0x80; off += 8) {
        auto children = try_children_at(h, dataModel, off, 20);
        if (children.size() >= 3 && children.size() <= 30) {
            // Verify first child looks like an Instance by reading its ClassName
            uintptr_t cd  = rmem<uintptr_t>(h, children[0] + classDescOff);
            std::string cn = try_name_at(h, cd, classNameOff);
            if (!cn.empty() && cn.size() < 64) {
                childrenOff = off;
                std::cout << "[+] Children offset: 0x" << std::hex << off
                          << " (" << children.size() << " children, first child class: \""
                          << cn << "\")\n" << std::dec;
                break;
            }
        }
    }
    if (childrenOff == 0) {
        std::cerr << "[-] Could not find Children offset.\n";
        CloseHandle(h); return 1;
    }

    // ---- Helper: find child by name using confirmed offsets ----
    auto getChildren = [&](uintptr_t inst) -> std::vector<uintptr_t> {
        return try_children_at(h, inst, childrenOff, 256);
    };

    auto findChild = [&](uintptr_t inst, const std::string& name) -> uintptr_t {
        for (uintptr_t child : getChildren(inst)) {
            std::string n = try_name_at(h, child, nameOff);
            if (n == name) return child;
        }
        return 0;
    };

    auto findChildOfClass = [&](uintptr_t inst, const std::string& className) -> uintptr_t {
        for (uintptr_t child : getChildren(inst)) {
            uintptr_t cd = rmem<uintptr_t>(h, child + classDescOff);
            std::string cn = try_name_at(h, cd, classNameOff);
            if (cn == className) return child;
        }
        return 0;
    };

    // ---- Step 4: Find Parent offset ----
    uint64_t parentOff = 0;
    {
        auto dmChildren = getChildren(dataModel);
        if (!dmChildren.empty()) {
            uintptr_t firstChild = dmChildren[0];
            // Parent of firstChild should be dataModel
            for (uint64_t off = 0x20; off <= 0x70; off += 8) {
                uintptr_t parentCandidate = rmem<uintptr_t>(h, firstChild + off);
                if (parentCandidate == dataModel) {
                    parentOff = off;
                    std::cout << "[+] Parent offset: 0x" << std::hex << off << "\n" << std::dec;
                    break;
                }
            }
        }
        if (parentOff == 0)
            std::cout << "[!] Parent offset not confirmed (non-critical)\n";
    }

    // ---- Step 5: Navigate to CoreGui -> RobloxGui -> Modules -> PlayerList -> PlayerListManager ----
    std::cout << "\n[*] Navigating instance tree to find script offsets...\n";

    uintptr_t coreGui = findChild(dataModel, "CoreGui");
    if (!coreGui) { std::cerr << "[-] CoreGui not found - are you in-game?\n"; CloseHandle(h); return 1; }
    std::cout << "[+] CoreGui: 0x" << std::hex << coreGui << std::dec << "\n";

    uintptr_t robloxGui = findChild(coreGui, "RobloxGui");
    if (!robloxGui) { std::cerr << "[-] RobloxGui not found\n"; CloseHandle(h); return 1; }

    uintptr_t modules = findChild(robloxGui, "Modules");
    if (!modules) { std::cerr << "[-] Modules not found\n"; CloseHandle(h); return 1; }

    // Find a ModuleScript we know exists: Common/Url
    uintptr_t common = findChild(modules, "Common");
    uintptr_t urlScript = common ? findChild(common, "Url") : 0;

    // Also try PlayerList/PlayerListManager
    uintptr_t playerList = findChild(modules, "PlayerList");
    uintptr_t plm = playerList ? findChild(playerList, "PlayerListManager") : 0;

    // Also try StarterPlayer path for VRNavigation
    uintptr_t starterPlayer = findChildOfClass(dataModel, "StarterPlayer");
    uintptr_t sps           = starterPlayer ? findChild(starterPlayer, "StarterPlayerScripts") : 0;
    uintptr_t playerModule  = sps ? findChild(sps, "PlayerModule") : 0;
    uintptr_t controlModule = playerModule ? findChild(playerModule, "ControlModule") : 0;
    uintptr_t vrNav         = controlModule ? findChild(controlModule, "VRNavigation") : 0;

    uintptr_t knownModule = urlScript ? urlScript : (plm ? plm : vrNav);
    if (!knownModule) {
        std::cerr << "[-] Could not find any known ModuleScript to probe.\n";
        CloseHandle(h); return 1;
    }

    std::string moduleName = try_name_at(h, knownModule, nameOff);
    std::cout << "[+] Using module \"" << moduleName << "\" at 0x"
              << std::hex << knownModule << std::dec << " for script offset scan\n";

    // ---- Step 6: Find ModuleScriptEmbedded, IsCoreScript, Bytecode, BytecodeSize ----
    std::cout << "\n[*] Scanning ModuleScript struct for embedded source pointer...\n";

    uint64_t moduleEmbeddedOff = 0;
    uint64_t bytecodeOff       = 0;
    uint64_t bytecodeSizeOff   = 0;
    uint64_t isCoreScriptOff   = 0;
    uint64_t moduleFlagsOff    = 0;

    // The embedded struct pointer sits somewhere between 0x100 and 0x200.
    // The embedded struct itself contains: [something][something][bytecodePtr (uintptr)][...][bytecodeSize (uint64)]
    // We identify it because: bytecodePtr is a readable region, bytecodeSize is reasonable (> 4, < 1MB typically)
    for (uint64_t embOff = 0x100; embOff <= 0x220; embOff += 8) {
        uintptr_t embPtr = rmem<uintptr_t>(h, knownModule + embOff);
        if (!is_readable(h, embPtr, 0x40)) continue;

        // Scan inside the embedded struct for bytecode pointer + size
        for (uint64_t bcOff = 0x08; bcOff <= 0x30; bcOff += 8) {
            uintptr_t bcPtr = rmem<uintptr_t>(h, embPtr + bcOff);
            if (!is_readable(h, bcPtr, 8)) continue;

            // Size should be at bcOff + 0x10 (based on Xeno's current layout)
            for (uint64_t szOff = bcOff + 0x08; szOff <= bcOff + 0x20; szOff += 8) {
                uint64_t bcSize = rmem<uint64_t>(h, embPtr + szOff);
                if (bcSize < 4 || bcSize > 512 * 1024) continue;

                // Read what should be bytecode and check for Roblox bytecode signature RSB1
                char sig[4] = {};
                SIZE_T nr = 0;
                ReadProcessMemory(h, reinterpret_cast<LPCVOID>(bcPtr), sig, 4, &nr);
                // After XOR decoding RSB1 becomes something specific but we can't easily
                // check it here. Instead verify the memory region looks like bytecode:
                // it should be MEM_PRIVATE (our allocation) OR it should be a mapped region
                // with a reasonable size.
                MEMORY_BASIC_INFORMATION mbi{};
                VirtualQueryEx(h, reinterpret_cast<LPCVOID>(bcPtr), &mbi, sizeof(mbi));
                if (mbi.State != MEM_COMMIT) continue;
                if (mbi.RegionSize < bcSize) continue;

                // Plausible! Record these.
                if (moduleEmbeddedOff == 0) {
                    moduleEmbeddedOff = embOff;
                    bytecodeOff       = bcOff;
                    bytecodeSizeOff   = szOff;
                    std::cout << "[+] ModuleScriptEmbedded offset: 0x" << std::hex << embOff << "\n";
                    std::cout << "[+] Bytecode pointer offset (in embedded): 0x" << bcOff << "\n";
                    std::cout << "[+] BytecodeSize offset (in embedded): 0x" << szOff << "\n";
                    std::cout << std::dec;
                }
                goto found_bytecode;
            }
        }
    }
    std::cout << "[!] Could not definitively locate bytecode offsets via RSB1 signature.\n";
    std::cout << "    Falling back to Xeno's current values (Bytecode=0x10, BytecodeSize=0x20)\n";
    bytecodeOff     = 0x10;
    bytecodeSizeOff = 0x20;
found_bytecode:;

    // ---- Step 7: Find IsCoreScript / ModuleFlags ----
    // IsCoreScript: somewhere in 0x180-0x220, value is 0 for a normal non-core module
    // or 1 for a core module. We look for the pattern where two adjacent qwords
    // could be ModuleFlags and IsCoreScript. For a non-core module, IsCoreScript = 0.
    // We scan for what looks like flag fields (value 0 or 1).
    std::cout << "\n[*] Scanning for IsCoreScript / ModuleFlags...\n";
    {
        // Try the known module - it's a CoreScript so IsCoreScript should be 1
        // and a nearby field should have flags
        std::vector<uint64_t> oneFields;
        for (uint64_t off = 0x150; off <= 0x240; off += 4) {
            uint64_t v = rmem<uint64_t>(h, knownModule + off);
            if (v == 1) oneFields.push_back(off);
        }
        // IsCoreScript is 1, the field 4 bytes before it is ModuleFlags
        // Try to confirm by checking if the field at -0x4 is 0 or a flag value
        for (uint64_t off : oneFields) {
            if (off < 4) continue;
            uint64_t flagsVal = rmem<uint64_t>(h, knownModule + off - 4);
            if (flagsVal == 0 || flagsVal == 0x100000000ULL || (flagsVal & 0xFFFF) == 0) {
                isCoreScriptOff = off;
                moduleFlagsOff  = off - 4;
                std::cout << "[+] IsCoreScript offset: 0x" << std::hex << off << "\n";
                std::cout << "[+] ModuleFlags offset: 0x" << (off - 4) << "\n" << std::dec;
                break;
            }
        }
        if (isCoreScriptOff == 0) {
            std::cout << "[!] Could not confirm IsCoreScript offset.\n";
            std::cout << "    Using Xeno's current values (IsCoreScript=0x1a8, ModuleFlags=0x1a4)\n";
            isCoreScriptOff = 0x1a8;
            moduleFlagsOff  = 0x1a4;
        }
    }

    // ---- Step 8: Find LocalPlayer offset ----
    std::cout << "\n[*] Scanning for LocalPlayer offset...\n";
    uint64_t localPlayerOff = 0;
    {
        uintptr_t players = findChildOfClass(dataModel, "Players");
        if (players) {
            // LocalPlayer is a pointer stored at Players + offset
            // Walk players children to find it, then scan Players struct for a pointer to it
            auto playerChildren = getChildren(players);
            // Find a child that is a Player (ClassName == "Player")
            uintptr_t localPlayerInst = 0;
            for (uintptr_t child : playerChildren) {
                uintptr_t cd = rmem<uintptr_t>(h, child + classDescOff);
                std::string cn = try_name_at(h, cd, classNameOff);
                if (cn == "Player") { localPlayerInst = child; break; }
            }
            if (localPlayerInst) {
                // Scan Players struct for a pointer matching localPlayerInst
                for (uint64_t off = 0xF0; off <= 0x140; off += 8) {
                    if (rmem<uintptr_t>(h, players + off) == localPlayerInst) {
                        localPlayerOff = off;
                        std::cout << "[+] LocalPlayer offset: 0x" << std::hex << off << "\n" << std::dec;
                        break;
                    }
                }
            }
        }
        if (localPlayerOff == 0) {
            std::cout << "[!] Could not confirm LocalPlayer offset.\n";
            std::cout << "    Using Xeno's current value (0x110)\n";
            localPlayerOff = 0x110;
        }
    }

    // ---- Step 9: Cross-check with LocalScript (if we can find one) ----
    uint64_t localEmbeddedOff = 0;
    {
        // Try to find a LocalScript to probe LocalScriptEmbedded
        uintptr_t coreScriptLocal = 0;
        // Walk CoreGui children looking for a LocalScript
        std::function<uintptr_t(uintptr_t, int)> findLocalScript = [&](uintptr_t root, int depth) -> uintptr_t {
            if (depth <= 0) return 0;
            for (uintptr_t child : getChildren(root)) {
                uintptr_t cd = rmem<uintptr_t>(h, child + classDescOff);
                std::string cn = try_name_at(h, cd, classNameOff);
                if (cn == "LocalScript") return child;
                uintptr_t found = findLocalScript(child, depth - 1);
                if (found) return found;
            }
            return 0;
        };
        coreScriptLocal = findLocalScript(coreGui, 4);
        if (coreScriptLocal) {
            std::cout << "\n[*] Found LocalScript at 0x" << std::hex << coreScriptLocal << std::dec << "\n";
            // Probe same way as module
            for (uint64_t embOff = 0x100; embOff <= 0x220; embOff += 8) {
                uintptr_t embPtr = rmem<uintptr_t>(h, coreScriptLocal + embOff);
                if (!is_readable(h, embPtr, 0x40)) continue;
                uintptr_t bcPtr  = rmem<uintptr_t>(h, embPtr + bytecodeOff);
                uint64_t  bcSize = rmem<uint64_t>(h, embPtr + bytecodeSizeOff);
                if (bcSize > 4 && bcSize < 512*1024 && is_readable(h, bcPtr, 8)) {
                    localEmbeddedOff = embOff;
                    std::cout << "[+] LocalScriptEmbedded offset: 0x" << std::hex << embOff << "\n" << std::dec;
                    break;
                }
            }
        }
        if (localEmbeddedOff == 0) {
            std::cout << "[!] LocalScriptEmbedded not confirmed, using Xeno's value (0x1c0)\n";
            localEmbeddedOff = 0x1c0;
        }
    }

    // ---- Print results ----
    std::cout << "\n";
    std::cout << "============================================================\n";
    std::cout << "  CONFIRMED OFFSETS — paste into Xeno/include/worker.hpp\n";
    std::cout << "============================================================\n\n";
    std::cout << "namespace offsets {\n";
    std::cout << "    // Instance\n";
    std::cout << "    constexpr std::uint64_t This            = 0x8;\n";
    std::cout << "    constexpr std::uint64_t Name            = 0x" << std::hex << nameOff << ";\n";
    std::cout << "    constexpr std::uint64_t Children        = 0x" << childrenOff << ";\n";
    std::cout << "    constexpr std::uint64_t Parent          = 0x" << (parentOff ? parentOff : 0x28) << ";\n";
    std::cout << "\n";
    std::cout << "    constexpr std::uint64_t ClassDescriptor = 0x" << classDescOff << ";\n";
    std::cout << "    constexpr std::uint64_t ClassName       = 0x" << classNameOff << ";\n";
    std::cout << "\n";
    std::cout << "    // Scripts\n";
    std::cout << "    constexpr std::uint64_t ModuleScriptEmbedded = 0x" << moduleEmbeddedOff << ";\n";
    std::cout << "    constexpr std::uint64_t IsCoreScript         = 0x" << isCoreScriptOff << ";\n";
    std::cout << "    constexpr std::uint64_t ModuleFlags          = IsCoreScript - 0x4;\n";
    std::cout << "    constexpr std::uint64_t LocalScriptEmbedded  = 0x" << localEmbeddedOff << ";\n";
    std::cout << "\n";
    std::cout << "    constexpr std::uint64_t Bytecode     = 0x" << bytecodeOff << ";\n";
    std::cout << "    constexpr std::uint64_t BytecodeSize = 0x" << bytecodeSizeOff << ";\n";
    std::cout << "\n";
    std::cout << "    // Other\n";
    std::cout << "    constexpr std::uint64_t LocalPlayer = 0x" << localPlayerOff << ";\n";
    std::cout << "    constexpr std::uint64_t ObjectValue = 0xc0; // unchanged, verify if needed\n";
    std::cout << "}\n\n";

    // Also print FetchDataModel fix if offsets differ
    std::cout << "// FetchDataModel (in worker.hpp RBXClient):\n";
    std::cout << "// std::uintptr_t fakeDataModel = read_memory<std::uintptr_t>(RenderView + 0x"
              << rvOffset << ", handle);\n";
    std::cout << "// return fakeDataModel + 0x" << dmOffset << ";\n";

    std::cout << std::dec;
    std::cout << "\n============================================================\n";

    // Confidence summary
    std::cout << "\nConfidence summary:\n";
    auto check = [](const char* name, uint64_t val, uint64_t xenoVal) {
        std::string status = (val == xenoVal) ? "MATCHES Xeno" : "DIFFERS from Xeno";
        std::cout << "  " << name << ": 0x" << std::hex << val
                  << " [" << status << " (Xeno=0x" << xenoVal << ")]\n" << std::dec;
    };
    check("Name",                nameOff,           0x50);
    check("Children",            childrenOff,        0x58);
    check("Parent",              parentOff,          0x28);
    check("ClassDescriptor",     classDescOff,       0x18);
    check("ClassName",           classNameOff,       0x8);
    check("ModuleScriptEmbedded",moduleEmbeddedOff,  0x160);
    check("IsCoreScript",        isCoreScriptOff,    0x1a8);
    check("LocalScriptEmbedded", localEmbeddedOff,   0x1c0);
    check("Bytecode",            bytecodeOff,        0x10);
    check("BytecodeSize",        bytecodeSizeOff,    0x20);
    check("LocalPlayer",         localPlayerOff,     0x110);
    check("RV->FakeDM",          rvOffset,           0x118);
    check("FakeDM->DM",          dmOffset,           0x190);

    std::cout << "\nDone. If any offsets DIFFER, update worker.hpp and recompile Xeno.\n";
    CloseHandle(h);
    return 0;
}
