# XenoOffsetScanner

Standalone Roblox offset scanner for Xeno executor. No debugger, no injection — 
Hyperion doesn't detect it because it only uses `OpenProcess(PROCESS_VM_READ)`, 
the same read-only handle Xeno itself uses.

## What it scans for

| Offset | What it is |
|--------|-----------|
| `Name` | Instance name string pointer |
| `Children` | Instance children vector pointer |
| `Parent` | Instance parent pointer |
| `ClassDescriptor` | Pointer to class descriptor struct |
| `ClassName` | Name string offset inside ClassDescriptor |
| `ModuleScriptEmbedded` | Pointer to the embedded source struct in a ModuleScript |
| `LocalScriptEmbedded` | Same but for LocalScript |
| `IsCoreScript` | CoreScript flag inside the embedded struct |
| `ModuleFlags` | Flags field immediately before IsCoreScript |
| `Bytecode` | Bytecode pointer inside the embedded struct |
| `BytecodeSize` | Bytecode size inside the embedded struct |
| `LocalPlayer` | LocalPlayer pointer inside the Players service |
| `RenderView → FakeDataModel` | Offset from RenderView to the fake DataModel pointer |
| `FakeDataModel → DataModel` | Offset from fake DataModel to the real DataModel |

## How to use

1. Open Roblox and **join a game** (not just the home screen — you need CoreGui loaded)
2. Build the scanner:
   - Open a **Developer Command Prompt for VS 2022** (or 2019)
   - `cd` to this folder and run `build.bat`, OR just run:
     ```
     cl /EHsc /O2 /std:c++17 XenoOffsetScanner.cpp /link psapi.lib
     ```
3. Run `XenoOffsetScanner.exe`
4. It prints a ready-to-paste `namespace offsets { ... }` block
5. Paste that block into `Xeno/include/worker.hpp`, replacing the existing one
6. Also update `FetchDataModel()` in the `RBXClient` class if those offsets differ
7. Recompile Xeno

## Example output

```
=== XenoOffsetScanner ===
[+] Roblox PID: 18432
[+] RenderView found at: 0x1a2b3c4d5e6f
[+] RenderView + 0x118 = fakeDataModel
[+] fakeDataModel + 0x190 = DataModel
[+] DataModel.Name: "Jailbreak"
[+] Name offset: 0x50
[+] Children offset: 0x58
...

============================================================
  CONFIRMED OFFSETS — paste into Xeno/include/worker.hpp
============================================================

namespace offsets {
    constexpr std::uint64_t This            = 0x8;
    constexpr std::uint64_t Name            = 0x50;
    ...
}

Confidence summary:
  Name:                 0x50  [MATCHES Xeno]
  Children:             0x58  [MATCHES Xeno]
  ModuleScriptEmbedded: 0x168 [DIFFERS from Xeno (Xeno=0x160)]  <-- update this
  ...
```

## If a scan fails

- **"RobloxPlayerBeta.exe not found"** — Roblox isn't running or is named differently on your install
- **"Could not find RenderView"** — Roblox hasn't written the log line yet; wait a few seconds and try again
- **"CoreGui not found"** — You're on the home screen, not in a game
- **"Could not locate DataModel"** — The RV→DM offsets shifted significantly; this is rare but means Roblox had a major internal update. Open an issue.

## Notes

- Run **as administrator** if you get `OpenProcess` errors
- The scanner is completely passive — it never writes a single byte to Roblox's memory
- Safe to run repeatedly; each run takes about 2-3 seconds
